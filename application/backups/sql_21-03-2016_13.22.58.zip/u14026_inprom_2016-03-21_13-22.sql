#
# TABLE STRUCTURE FOR: answer_notifications
#

DROP TABLE IF EXISTS answer_notifications;

CREATE TABLE `answer_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `locale` varchar(5) CHARACTER SET utf8 NOT NULL,
  `name` varchar(25) CHARACTER SET utf8 NOT NULL,
  `message` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO answer_notifications (`id`, `locale`, `name`, `message`) VALUES (1, 'ua', 'incoming', '<h1>Дякуємо</h1>\n<div>В короткий час наші менеджери звяжуться з Вами</div>\n<div id=\"dc_vk_code\" style=\"display: none;\">&nbsp;</div>');
INSERT INTO answer_notifications (`id`, `locale`, `name`, `message`) VALUES (2, 'ua', 'callback', '<h1>Дякуємо</h1>\n<div>В короткий час наші менеджери звяжуться з Вами</div>\n<div id=\"dc_vk_code\" style=\"display: none;\">&nbsp;</div>');
INSERT INTO answer_notifications (`id`, `locale`, `name`, `message`) VALUES (3, 'ua', 'order', '<h1>Дякуємо</h1>\n<div>В короткий час наші менеджери звяжуться з Вами</div>\n<div id=\"dc_vk_code\" style=\"display: none;\">&nbsp;</div>');
INSERT INTO answer_notifications (`id`, `locale`, `name`, `message`) VALUES (4, 'ru', 'incoming', '<h1>Спасибо</h1>\n<div>В ближайшее время наши менеджеры свяжутся с Вами</div>');
INSERT INTO answer_notifications (`id`, `locale`, `name`, `message`) VALUES (5, 'ru', 'callback', '<h1>Спасибо</h1>\n<div>В ближайшее время наши менеджеры свяжутся с Вами</div>');
INSERT INTO answer_notifications (`id`, `locale`, `name`, `message`) VALUES (6, 'ru', 'order', '<h1>Спасибо</h1>\n<div>В ближайшее время наши менеджеры свяжутся с Вами</div>');


#
# TABLE STRUCTURE FOR: category
#

DROP TABLE IF EXISTS category;

CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `position` mediumint(5) NOT NULL DEFAULT '0',
  `name` varchar(160) NOT NULL,
  `title` varchar(250) DEFAULT NULL,
  `short_desc` text NOT NULL,
  `url` varchar(300) NOT NULL,
  `image` varchar(250) DEFAULT NULL,
  `keywords` text,
  `description` text,
  `fetch_pages` text NOT NULL,
  `main_tpl` varchar(50) NOT NULL,
  `tpl` varchar(50) DEFAULT NULL,
  `page_tpl` varchar(50) DEFAULT NULL,
  `per_page` smallint(5) NOT NULL,
  `order_by` varchar(25) NOT NULL,
  `sort_order` varchar(25) NOT NULL,
  `comments_default` tinyint(1) NOT NULL DEFAULT '0',
  `field_group` int(11) NOT NULL,
  `category_field_group` int(11) NOT NULL,
  `settings` varchar(10000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=utf8;

INSERT INTO category (`id`, `parent_id`, `position`, `name`, `title`, `short_desc`, `url`, `image`, `keywords`, `description`, `fetch_pages`, `main_tpl`, `tpl`, `page_tpl`, `per_page`, `order_by`, `sort_order`, `comments_default`, `field_group`, `category_field_group`, `settings`) VALUES (69, 0, 1, 'Новини', '', '', 'novosti', '', '', '', 'a:3:{i:0;s:2:\"69\";i:1;s:2:\"70\";i:2;s:2:\"71\";}', '', '', '', 15, 'publish_date', 'desc', 0, -1, -1, 'a:2:{s:26:\"category_apply_for_subcats\";b:0;s:17:\"apply_for_subcats\";b:0;}');
INSERT INTO category (`id`, `parent_id`, `position`, `name`, `title`, `short_desc`, `url`, `image`, `keywords`, `description`, `fetch_pages`, `main_tpl`, `tpl`, `page_tpl`, `per_page`, `order_by`, `sort_order`, `comments_default`, `field_group`, `category_field_group`, `settings`) VALUES (70, 69, 2, 'Останні новини', '', '', 'poslednie-novosti', '', '', '', 'b:0;', '', '', '', 15, 'publish_date', 'desc', 0, -1, -1, 'a:2:{s:26:\"category_apply_for_subcats\";b:0;s:17:\"apply_for_subcats\";b:0;}');
INSERT INTO category (`id`, `parent_id`, `position`, `name`, `title`, `short_desc`, `url`, `image`, `keywords`, `description`, `fetch_pages`, `main_tpl`, `tpl`, `page_tpl`, `per_page`, `order_by`, `sort_order`, `comments_default`, `field_group`, `category_field_group`, `settings`) VALUES (71, 69, 3, 'Архів', '', '', 'arhiv', '', '', '', 'b:0;', '', '', '', 15, 'publish_date', 'desc', 0, -1, -1, 'a:2:{s:26:\"category_apply_for_subcats\";b:0;s:17:\"apply_for_subcats\";b:0;}');


#
# TABLE STRUCTURE FOR: category_translate
#

DROP TABLE IF EXISTS category_translate;

CREATE TABLE `category_translate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alias` int(11) NOT NULL,
  `name` varchar(160) NOT NULL,
  `title` varchar(250) DEFAULT NULL,
  `short_desc` text,
  `image` varchar(250) DEFAULT NULL,
  `keywords` text,
  `description` text,
  `lang` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`,`lang`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: comments
#

DROP TABLE IF EXISTS comments;

CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(25) NOT NULL DEFAULT 'core',
  `user_id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_mail` varchar(50) NOT NULL,
  `user_site` varchar(250) NOT NULL,
  `item_id` bigint(11) NOT NULL,
  `text` text,
  `date` int(11) NOT NULL,
  `status` smallint(1) NOT NULL,
  `agent` varchar(250) NOT NULL,
  `user_ip` varchar(64) NOT NULL,
  `rate` int(11) NOT NULL,
  `text_plus` varchar(500) DEFAULT NULL,
  `text_minus` varchar(500) DEFAULT NULL,
  `like` int(11) NOT NULL,
  `disslike` int(11) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `module` (`module`),
  KEY `item_id` (`item_id`),
  KEY `date` (`date`)
) ENGINE=MyISAM AUTO_INCREMENT=83 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: components
#

DROP TABLE IF EXISTS components;

CREATE TABLE `components` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `identif` varchar(25) NOT NULL,
  `enabled` int(1) NOT NULL,
  `autoload` int(1) NOT NULL,
  `in_menu` int(1) NOT NULL DEFAULT '0',
  `settings` text,
  `position` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `identif` (`identif`),
  KEY `enabled` (`enabled`),
  KEY `autoload` (`autoload`)
) ENGINE=MyISAM AUTO_INCREMENT=348 DEFAULT CHARSET=utf8;

INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (1, 'user_manager', 'user_manager', 0, 0, 0, NULL, 11);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (2, 'auth', 'auth', 1, 0, 0, NULL, 20);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (4, 'comments', 'comments', 1, 1, 0, NULL, 9);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (7, 'navigation', 'navigation', 0, 0, 0, NULL, 21);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (30, 'tags', 'tags', 1, 1, 0, NULL, 22);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (92, 'gallery', 'gallery', 1, 1, 1, 'a:26:{s:13:\"max_file_size\";s:1:\"5\";s:9:\"max_width\";s:1:\"0\";s:10:\"max_height\";s:1:\"0\";s:7:\"quality\";s:2:\"95\";s:14:\"maintain_ratio\";b:1;s:19:\"maintain_ratio_prev\";b:1;s:19:\"maintain_ratio_icon\";b:1;s:4:\"crop\";b:0;s:9:\"crop_prev\";b:0;s:9:\"crop_icon\";b:0;s:14:\"prev_img_width\";s:3:\"500\";s:15:\"prev_img_height\";s:3:\"500\";s:11:\"thumb_width\";s:3:\"100\";s:12:\"thumb_height\";s:3:\"100\";s:14:\"watermark_text\";s:0:\"\";s:16:\"wm_vrt_alignment\";s:6:\"bottom\";s:16:\"wm_hor_alignment\";s:4:\"left\";s:19:\"watermark_font_size\";s:2:\"14\";s:15:\"watermark_color\";s:6:\"ffffff\";s:17:\"watermark_padding\";s:2:\"-5\";s:19:\"watermark_font_path\";s:20:\"./system/fonts/1.ttf\";s:15:\"watermark_image\";s:0:\"\";s:23:\"watermark_image_opacity\";s:2:\"50\";s:14:\"watermark_type\";s:4:\"text\";s:8:\"order_by\";s:4:\"date\";s:10:\"sort_order\";s:4:\"desc\";}', 10);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (55, 'rss', 'rss', 1, 0, 0, 'a:5:{s:5:\"title\";s:9:\"Image CMS\";s:11:\"description\";s:35:\"Тестируем модуль RSS\";s:10:\"categories\";a:1:{i:0;s:1:\"3\";}s:9:\"cache_ttl\";i:60;s:11:\"pages_count\";i:10;}', 14);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (60, 'menu', 'menu', 0, 1, 1, NULL, 3);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (58, 'sitemap', 'sitemap', 1, 1, 0, 'a:8:{s:18:\"main_page_priority\";s:1:\"1\";s:13:\"cats_priority\";s:1:\"1\";s:14:\"pages_priority\";s:1:\"1\";s:20:\"main_page_changefreq\";s:6:\"always\";s:21:\"categories_changefreq\";s:6:\"always\";s:16:\"pages_changefreq\";s:6:\"always\";s:7:\"sendXML\";s:4:\"true\";s:8:\"lastSend\";i:1458125896;}', 15);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (80, 'search', 'search', 1, 0, 0, NULL, 24);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (84, 'feedback', 'feedback', 1, 0, 0, 'a:2:{s:5:\"email\";s:19:\"admin@localhost.loc\";s:15:\"message_max_len\";i:550;}', 12);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (117, 'template_editor', 'template_editor', 1, 1, 1, NULL, 16);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (86, 'group_mailer', 'group_mailer', 0, 0, 0, NULL, 13);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (95, 'filter', 'filter', 1, 0, 0, NULL, 25);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (96, 'cfcm', 'cfcm', 0, 0, 0, NULL, 17);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (121, 'shop', 'shop', 1, 0, 0, NULL, 17);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (137, 'mailer', 'mailer', 1, 0, 1, NULL, 2);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (181, 'shop_news', 'shop_news', 1, 1, 0, NULL, 18);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (153, 'share', 'share', 1, 1, 1, 'a:16:{s:4:\"yaru\";s:1:\"1\";s:5:\"vkcom\";s:1:\"1\";s:8:\"facebook\";s:1:\"1\";s:7:\"twitter\";s:1:\"1\";s:9:\"odnoclass\";s:1:\"1\";s:7:\"myworld\";s:1:\"1\";s:2:\"lj\";s:1:\"1\";s:2:\"ff\";s:1:\"1\";s:2:\"mc\";s:1:\"1\";s:2:\"gg\";s:1:\"1\";s:4:\"type\";s:6:\"button\";s:13:\"facebook_like\";s:1:\"1\";s:7:\"vk_like\";s:1:\"1\";s:8:\"vk_apiid\";s:5:\"ghfgh\";s:7:\"gg_like\";s:1:\"1\";s:12:\"twitter_like\";s:1:\"1\";}', 8);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (177, 'banners', 'banners', 1, 1, 1, 'a:1:{s:8:\"show_tpl\";i:1;}', 1);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (205, 'mod_discount', 'mod_discount', 1, 1, 1, NULL, 0);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (253, 'smart_filter', 'smart_filter', 1, 1, 0, NULL, 23);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (185, 'exchange', 'exchange', 1, 0, 1, 'a:13:{s:3:\"zip\";s:2:\"no\";s:8:\"filesize\";s:7:\"2048000\";s:7:\"validIP\";s:9:\"127.0.0.1\";s:5:\"login\";s:0:\"\";s:8:\"password\";s:0:\"\";s:11:\"usepassword\";N;s:12:\"userstatuses\";a:1:{i:0;s:1:\"1\";}s:10:\"autoresize\";s:2:\"on\";s:5:\"debug\";s:2:\"on\";s:5:\"email\";s:24:\"office@artexgroup.com.ua\";s:5:\"brand\";s:0:\"\";s:18:\"userstatuses_after\";s:1:\"1\";s:6:\"backup\";s:1:\"1\";}', 5);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (344, 'wishlist', 'wishlist', 1, 1, 1, 'a:10:{s:11:\"maxUserName\";s:3:\"256\";s:11:\"maxListName\";s:3:\"254\";s:13:\"maxListsCount\";s:2:\"10\";s:13:\"maxItemsCount\";s:3:\"100\";s:16:\"maxCommentLenght\";s:3:\"500\";s:13:\"maxDescLenght\";s:4:\"1000\";s:15:\"maxWLDescLenght\";s:4:\"1000\";s:13:\"maxImageWidth\";s:3:\"150\";s:14:\"maxImageHeight\";s:3:\"150\";s:12:\"maxImageSize\";s:7:\"2000000\";}\" }', 2);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (188, 'cmsemail', 'cmsemail', 1, 0, 1, 'a:9:{s:4:\"from\";s:12:\"Default From\";s:10:\"from_email\";s:15:\"default@from.ua\";s:11:\"admin_email\";s:13:\"admin@from.ua\";s:5:\"theme\";s:13:\"Default Theme\";s:12:\"wraper_activ\";s:2:\"on\";s:6:\"wraper\";s:30:\"<p>$content</p>\";s:8:\"mailpath\";s:18:\"/usr/sbin/sendmail\";s:8:\"protocol\";s:4:\"SMTP\";s:4:\"port\";s:2:\"80\";}', 7);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (216, 'new_level', 'new_level', 1, 1, 1, 'a:3:{s:15:\"propertiesTypes\";a:3:{i:0;s:6:\"scroll\";i:1;s:4:\"full\";i:2;s:8:\"dropDown\";}s:7:\"columns\";a:4:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"3\";i:3;s:1:\"4\";}s:5:\"thema\";s:18:\"css/color_scheme_1\";}', 4);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (261, 'trash', 'trash', 0, 1, 0, NULL, 7);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (204, 'mobile', 'mobile', 1, 1, 1, NULL, 6);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (264, 'language_switch', 'language_switch', 0, 0, 0, NULL, 19);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (265, 'star_rating', 'star_rating', 1, 1, 1, NULL, 26);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (266, 'imagebox', 'imagebox', 0, 1, 0, NULL, 27);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (345, 'translator', 'translator', 1, 1, 1, 'a:3:{s:11:\"originsLang\";s:2:\"ru\";s:11:\"editorTheme\";s:6:\"chrome\";s:12:\"YandexApiKey\";s:84:\"trnsl.1.1.20140122T095925Z.9cbf2380c6a6f92e.c2c9b595aefe6a251deb1859c272d444258049de\";}', NULL);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (346, 'sample_module', 'sample_module', 1, 1, 0, NULL, NULL);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (347, 'socauth', 'socauth', 1, 0, 0, NULL, NULL);


#
# TABLE STRUCTURE FOR: content
#

DROP TABLE IF EXISTS content;

CREATE TABLE `content` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `meta_title` varchar(300) DEFAULT NULL,
  `url` varchar(500) NOT NULL,
  `cat_url` varchar(260) DEFAULT NULL,
  `keywords` text,
  `description` text,
  `prev_text` text,
  `full_text` longtext NOT NULL,
  `category` int(11) NOT NULL,
  `full_tpl` varchar(50) DEFAULT NULL,
  `main_tpl` varchar(50) NOT NULL,
  `position` smallint(5) NOT NULL,
  `comments_status` smallint(1) NOT NULL,
  `comments_count` int(9) DEFAULT '0',
  `post_status` varchar(15) NOT NULL,
  `author` varchar(50) NOT NULL,
  `publish_date` int(11) NOT NULL,
  `created` int(11) NOT NULL,
  `updated` int(11) NOT NULL,
  `showed` int(11) NOT NULL,
  `lang` int(11) NOT NULL DEFAULT '0',
  `lang_alias` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `url` (`url`(333)),
  KEY `lang` (`lang`),
  KEY `post_status` (`post_status`(4)),
  KEY `cat_url` (`cat_url`),
  KEY `publish_date` (`publish_date`),
  KEY `category` (`category`),
  KEY `created` (`created`),
  KEY `updated` (`updated`)
) ENGINE=MyISAM AUTO_INCREMENT=98 DEFAULT CHARSET=utf8;

INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (35, 'Про сайт', '', 'pro-sait', '', 'это, базовый, шаблон, imagecms, котором, релизованы, следующие, функции, вывод, фотогалереи, статической, статьи, блога', 'Это базовый шаблон ImageCMS, на котором релизованы следующие функции: вывод фотогалереи, вывод статической статьи, вывод блога.', '<p>Это базовый шаблон ImageCMS, на котором релизованы следующие функции: отображение фотогалереи, отображение статической статьи, отображение корпоративного блога, отображение формы обратной связи.</p>\n<p>Общий вид шаблона можно отредактировать и изменить лого, графическую вставку на свои тематические.</p>\n<p>Слева в сайдбаре Вы видите список категорий блога, который легко вставляется с помощью функции {sub_category_list()} в файле main.tpl. Также в левом сайдбаре находится форма поиска по сайту, виджет последних комментариев и виджет тегов сайта. В этот сайдбар можно также добавить виджет последних либо популярных новостей, а также любые счетчики, информеры.</p>\n<p>Верхнее меню реализовано с помощью модуля Меню. Управлять его содержимым можно из административной части в разделе Меню - Главное меню. Сюда как правило можно еще добавить страницы: о компании, контакты, услуги и т.п.</p>\n<p>За дополнительной информацией обращайтесь в официальный раздел документации: <a href=\"http://www.imagecms.net/wiki\">http://www.imagecms.net/wiki</a></p>\n<p>Обсудить дополнительные возможности, а также вопросы по установке, настройке системы можно на официальном форуме: <a href=\"http://forum.imagecms.net/index.php\">http://forum.imagecms.net/</a></p>', '<p>іаіаіваіваіваів</p>', 0, '', '', 1, 1, 0, 'publish', 'Administrator', 1267203253, 1267203328, 1390482384, 17, 3, 0);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (64, 'Про фірму', '', 'pro-firmu', '', 'магазине', 'О магазине', '<h2>Фірма \"Інпром-сервіс\" заснована в 1999 році</h2>', '', 0, '', '', 2, 1, 0, 'publish', '111', 1291295776, 0, 1392214549, 539, 3, 0);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (65, 'Оплата', '', 'oplata', '', 'оплата', 'Оплата', '<p>Оплата за обладнання проводиться будь яким зручним для Вас способом.</p>', '', 0, '', '', 3, 1, 0, 'publish', '111', 1291295824, 1291295836, 1392457172, 172, 3, 0);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (66, 'Доставка', '', 'dostavka', '', 'доставка', 'Доставка', '<p>Доставка обладнання здійснюється транспортними компаніями за бажанням покупця:</p>\n<p>Нова Пошта</p>\n<p>САТ</p>\n<p>Автолюкс</p>\n<p>Інтайм</p>\n<p>Делівері</p>', '', 0, '', '', 4, 1, 0, 'publish', '111', 1291295844, 1291295851, 1392456392, 309, 3, 0);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (67, 'Допомога', '', 'dopomoga', '', 'помощь', 'Помощь', '<p>Консультації по телефону: 0532-544420, 544427, 544429</p>', '', 0, '', '', 5, 1, 0, 'publish', '111', 1291295855, 1291295867, 1392456534, 291, 3, 0);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (68, 'Контакти', '', 'kontakti', '', 'контакты', 'Контакты', '<p><strong style=\"line-height: 1.4em;\">Адреса офісу:</strong></p>\n<p>36002, м. Полтава, вул. Фрунзе, 90, кв. 3,4</p>\n<p>тел. (0532) 5444420, 544427, 544429</p>\n<p>тел. 095-8163587, 096-8543205</p>\n<p>&nbsp;</p>', '', 0, 'contacts', '', 0, 0, 0, 'publish', 'Administrator', 1291295870, 1291295888, 1429799345, 371, 3, 0);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (75, 'Contact', '', 'kontakti', '', 'ssss', 'ssss', '<p><span id=\"result_box\" lang=\"en\"><span>Hot Phone</span><span>:</span> <span>0800</span> <span>80</span> <span>80 800</span><br /><br /> <span>Head office in</span> <span>Moscow</span><br /><br /> <span>street</span><span>.</span> <span>Gagarin</span> <span>half</span><br /><br /> <span>tel.</span> <span>095</span> <span>095</span> <span>00</span> <span>00</span><br /><br /> <span>The main office</span> <span>in Kiev</span><br /><br /> <span>street</span><span>.</span> <span>Gagarin</span> <span>half</span><br /><br /> <span>tel.</span> <span>098</span> <span>098</span> <span>00</span> <span>00</span></span></p>', '', 0, '', '', 0, 1, 4, 'publish', 'admin', 1291295870, 1291295888, 1343664873, 35, 30, 68);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (76, 'Delivery', '', 'dostavka', '', 'support, the, delivery, service, autoworld, around, world, also, possible, all, major, cities, ukraine, and, russia, possibility, courier, your, area, please, call, desired, you, can, pick, purchased, goods, themselves, our, offices', 'We support the delivery of service Autoworld around the world. It is also possible delivery to all major cities of Ukraine and Russia (the possibility of delivery by courier in your area please call 0800820 22 22.) If desired, you can pick up the purchase', '<p><span id=\"result_box\" lang=\"en\"><span>We support the</span> <span>delivery of</span> <span>service</span> <span>Autoworld</span> <span>around the world.</span><br /><br /> <span>It is also possible</span> <span>delivery</span> <span>to all</span> <span>major cities</span> <span>of Ukraine and Russia</span> <span>(the possibility of</span> <span>delivery</span> <span>by courier</span> <span>in your area</span> <span>please call</span> <span>0800820</span> <span>22 22</span><span>.)</span><br /><br /> <span>If desired,</span> <span>you can</span> <span>pick up the</span> <span>purchased goods</span> <span>themselves</span> <span>in our offices.</span></span></p>', '', 0, '', '', 0, 1, 4, 'publish', 'admin', 1291295844, 1291295851, 1343664842, 8, 30, 66);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (77, 'Help', '', 'dopomoga', '', 'order, purchase, goods, our, store, you, must, follow, few, simple, steps, choose, the, right, product, vospolzovavshit, navigation, left, search, add, products, cart, shopping, select, shipping, method, and, provide, your, contact', 'In order to purchase goods in our store, you must follow a few simple steps: Choose the right product, vospolzovavshit navigation on the left, or search. Add products to cart. Go to the shopping cart, select shipping method and provide your contact inform', '<p><span id=\"result_box\" lang=\"en\"><span>In order to</span> <span>purchase goods</span> <span>in our store,</span> <span>you must follow</span> <span>a few simple steps</span><span>:</span><br /><br />&nbsp;&nbsp;&nbsp;&nbsp; <span>Choose</span> <span>the right product,</span> <span>vospolzovavshit</span> <span>navigation</span> <span>on the left</span><span>, or</span> <span>search.</span><br />&nbsp;&nbsp;&nbsp;&nbsp; <span>Add products</span> <span>to cart</span><span>.</span><br />&nbsp;&nbsp;&nbsp;&nbsp; <span>Go to the</span> <span>shopping cart,</span> <span>select</span> <span>shipping method</span> <span>and provide</span> <span>your contact information.</span><br />&nbsp;&nbsp;&nbsp;&nbsp; <span>Proceed to checkout</span> <span>and select the</span> <span>payment method.</span><br /><br /> <span>After that,</span> <span>our managers</span> <span>will contact</span> <span>you and</span> <span>help you</span> <span>with payment</span> <span>and delivery</span> <span>of the goods</span><span>, as well</span> <span>as give advice on</span> <span>any subject.</span></span></p>', '', 0, '', '', 0, 1, 0, 'publish', 'admin', 1291295855, 1291295867, 1343664897, 11, 30, 67);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (78, 'Payment', '', 'oplata', '', 'our, store, supports, all, currently, available, methods, payment, also, there, possibility, pay, the, courier, for, delivery, major, cities, ukraine, and, russia, ability, your, area, please, call', 'Our store supports all currently available methods of payment. Also there is a possibility to pay the courier for delivery to all major cities of Ukraine and Russia. (ability to pay for the courier in your area please call 0800820 22 22.)', '<p><span id=\"result_box\" lang=\"en\"><span>Our store</span> <span>supports all</span> <span>currently available</span> <span>methods of payment.</span><br /><br /> <span>Also there is</span> <span>a possibility to pay</span> <span>the courier</span> <span>for delivery</span> <span>to all</span> <span>major cities</span> <span>of Ukraine</span> <span>and Russia.</span> <span>(ability to</span> <span>pay for</span> <span>the courier</span> <span>in your area</span> <span>please call</span> <span>0800820</span> <span>22 22</span><span>.)</span></span></p>', '', 0, '', '', 0, 1, 3, 'publish', 'admin', 1291295824, 1291295836, 1343664949, 1, 30, 65);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (79, 'About us', '', 'pro-firmu', '', 'shop, imagecms, offers, huge, selection, vehicles, suit, every, taste, the, best, prices, our, store, has, more, than, years, and, during, that, time, was, not, single, return, goods, serve, hundreds, customers', 'Shop ImageCMS Shop offers a huge selection of vehicles to suit every taste at the best prices. Our store has more than 5 years and during that time was not a single return of the goods. We serve hundreds of customers every day and do it with joy. Buy equi', '<p><span id=\"result_box\" lang=\"en\"><span>Shop</span> <span>ImageCMS Shop</span> <span>offers</span> <span>a huge selection</span> <span>of vehicles</span> <span>to suit every taste</span> <span>at the best prices</span><span>.</span><br /><br /> <span>Our store</span> <span>has more than</span> <span>5 years</span> <span>and during that time</span> <span>was not a single</span> <span>return of the goods</span><span>.</span><br /><br /> <span>We serve</span> <span>hundreds of</span> <span>customers</span> <span>every day</span> <span>and do</span> <span>it with joy.</span><br /><br /> <span>Buy</span> <span>equipment from</span> <span>us and</span> <span>become the owner of</span> <span>the world\'s best</span> <span>technology</span><span>!</span></span></p>', '', 0, '', '', 0, 1, 1, 'publish', 'admin', 1291295776, 1291295792, 1343745649, 5, 30, 64);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (80, 'Site', '', 'pro-sait', '', 'new', 'new', '<p><span id=\"result_box\" lang=\"en\"><span>This is</span> <span>the basic template</span> <span>ImageCMS,</span> <span>which</span> <span>relizovany</span> <span>the following functions</span><span>: display</span> <span>gallery</span><span>, displaying</span> <span>static</span> <span>articles</span><span>, displaying</span> <span>a corporate blog</span><span>, displaying</span> <span>the feedback form.</span><br /><br /> <span>General view of the</span> <span>template, you can</span> <span>edit and</span> <span>change the</span> <span>logo,</span> <span>a graphic</span> <span>box on</span> <span>your</span> <span>case</span><span>.</span><br /><br /> <span>On the left</span> <span>you can see</span> <span>in the sidebar</span> <span>list of</span> <span>categories of</span> <span>the blog,</span> <span>which is easily</span> <span>inserted</span> <span>by using the</span> <span>{sub_category_list ()}</span> <span>in the file</span> <span>main.tpl.</span> <span>Also</span> <span>in the left</span> <span>sidebar</span> <span>is</span> <span>a search form</span> <span>on the site,</span> <span>recent comments</span> <span>widget</span> <span>and the widget</span> <span>tag</span> <span>site.</span> <span>In</span> <span>this</span> <span>sidebar</span> <span>you can also</span> <span>add a widget</span><span>, or</span> <span>the latest</span> <span>popular</span> <span>news,</span> <span>as well as any</span> <span>counters,</span> <span>widgets</span><span>.</span><br /><br /> <span>The top menu</span> <span>is implemented</span> <span>by the module</span> <span>menu</span><span>.</span> <span>And manage</span> <span>its content</span> <span>can be</span> <span>part</span> <span>of the</span> <span>administration</span> <span>in Menu</span> <span>-</span> <span>Main Menu.</span> <span>It</span> <span>is usually</span> <span>possible to add</span> <span>page</span> <span>about the company</span><span>, contacts,</span> <span>services, etc.</span><br /><br /> <span>For more</span> <span>information, contact the</span> <span>official</span> <span>section of the documentation</span><span>: http://www.imagecms.net/wiki</span><br /><br /> <span>Discuss</span> <span>additional opportunities</span><span>, as well as</span> <span>questions about</span> <span>installation, configuration,</span> <span>the system can be</span> <span>on the official forum</span><span>: http://forum.imagecms.net/</span></span></p>', '', 0, '', '', 0, 1, 0, 'publish', 'admin', 1267203253, 1267203328, 1343722704, 0, 30, 35);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (91, 'Как раскрутить сайт? Методы поискового продвижения', '', 'kak-raskrutit-sait-metody-poiskovogo-prodvizheniia', 'novosti/poslednie-novosti/', 'наличие, корпоративного, сайта, стало, стандартом, факто, знаком, хорошего, тона, любой, компании, только, известных, игроков, рынка, независимо, области, вашей, деятельности, собственный, ресурс, любом, случае, принесет, пользу, особенно, знаете, раскрутить, сайт, самостоятельно', 'Наличие корпоративного сайта уже стало стандартом де-факто и знаком   хорошего тона любой компании, а не только известных игроков рынка.   Независимо от области вашей деятельности, собственный ресурс в любом   случае принесет вам пользу, особенно если вы', '<p>Наличие корпоративного сайта уже стало стандартом де-факто и знаком  \nхорошего тона любой компании, а не только известных игроков рынка.  \nНезависимо от области вашей деятельности, собственный ресурс в любом  \nслучае принесет вам пользу, особенно если вы знаете как раскрутить сайт \n самостоятельно. Его можно использовать не только для повышения  \nузнаваемости бренда, но и в качестве эффективного инструмента продаж.</p>', '<p>Наличие корпоративного сайта уже стало стандартом де-факто и знаком \nхорошего тона любой компании, а не только известных игроков рынка. \nНезависимо от области вашей деятельности, собственный ресурс в любом \nслучае принесет вам пользу, особенно если вы знаете как раскрутить сайт \nсамостоятельно. Его можно использовать не только для повышения \nузнаваемости бренда, но и в качестве эффективного инструмента продаж.\n</p><p>После разработки и создания, каждый владелец Интернет-ресурса \nнепременно задумается как раскрутить сайт, ведь это - очень важный \nмомент. И тогда стоит разобраться в актуальных методах продвижения с \nцелью выбора оптимального.</p>\n<p>Все методы можно разделить на две основные группы: белые и черные \n(или спамные) - не важно, интересует ли вас как раскрутить сайт \nбесплатно или же с помощью студии. Если применение «белых» методов не \nвлечет за собой возможные санкции со стороны поисковых систем, то \nприменение запрещенных «черных» методов хотя и обещает быстрый результат\n и высокую эффективность в краткосрочном периоде, в долгосрочном периоде\n может обернутся жесткими санкциями со стороны поисковых систем.</p>\n<p>Но, скорее всего, большинство интересуется именно вопросом как \nраскрутить сайт бесплатно или с минимальными финансовыми вложениями. А \nзначит, стоит обратить внимание на такие методы бесплатного продвижения \nкак добавление в специализированные каталоги, рассылку пресс-релизов, \ne-mail маркетинг, обмен ссылками с другими сайтами схожей тематики. В \nтаком случае вопрос сколько стоит раскрутить сайт отпадает, так как все \nделается своими силами. Но прежде нужно хорошо подумать, не лучше ли \nобратиться к профессионалам своего дела? Ведь <a href=\"http://www.imagecms.net/blog/obzory/biznes-v-internete-kak-perspektivnyi-trend\" target=\"_blank\">бизнес в Интернете</a>\n требует затрат времени и они могут оказаться колоссальными, и в случае с\n профессиональными подрядчиками по крайней мере можно быть уверенным в \nрезультате.</p>\n<p>Кроме того, стоит обратить внимание на специализированные движки для \nсайтов, которые “с коробки” обладают хорошими возможностями в плане \nSEO-оптимизации. Одной из таких систем является <a href=\"http://www.imagecms.net/download\">ImageCMS</a>\n - благодаря тому, что движок изначально является SEO-friendly, не нужно\n устанавливать дополнительные модули и компоненты, а значит можно \nсэкономить массу времени и нервов.</p>\n<p><a href=\"http://www.imagecms.net/download\"><img src=\"http://www.imagecms.net/uploads/images/blog/2.png\" alt=\"Система для создания интернет-магазинов - ImageCMS\" height=\"183\" width=\"705\"></a></p>\n<p>Если анализировать сколько стоит раскрутить сайт, то стоит \nотталкиваться от того факта, что это - комплексный процесс, и \nпредусматривает он работу сразу в нескольких направлениях, а значит \nлучше, если работу будут вести несколько человек. Поэтому самостоятельно\n справиться будет нелегко.</p>\n<p>Если вы задумались как раскрутить сайт бесплатно в сжатые сроки, то \nлучше сразу отбросьте эту идею и обратите внимание на платные методы - с\n их помощью можно сделать это гораздо быстрее, да и эффективность в этом\n случае на порядок выше. Здесь важен вопрос сколько стоит раскрутить \nсайт и вопрос больше по бюджету. Продвижение в таком случае ведется с \nиспользованием покупных ссылок на тематических сайтах, \nспециализированных бирж, заказа текстов у копирайтеров, организации \nкампаний в сетях контекстной рекламы, а также использования потенциала \nсоциальных медиа. Кроме того, <a href=\"http://www.imagecms.net/blog/obzory/osnovy-iuzabiliti-saita\" target=\"_blank\">юзабилити сайта</a> также играет важную роль.</p>\n<p>Выбирать между возможностью раскрутить сайт самостоятельно и заказать\n продвижение у специализированного агентства – нелегко. Во многом из-за \nнеобходимости хорошо проанализировать, что для вас важнее – экономия \nсредств или экономия времени. Да порой, если задумываешься как \nраскрутить сайт самостоятельно, стоит обратить внимание в сторону услуг \nподрядчиков, ведь с помощью профессионалов гораздо лучше сделать все \nбыстро и сэкономленный временной ресурс направить на получение прибыли в\n области, в которой вы действительно хорошо разбираетесь.</p>', 70, '', '', 0, 1, 0, 'draft', 'admin', 1362225580, 1362225580, 0, 1, 3, 0);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (92, 'Как добавить сайт в Яндекс и Гугл. Советы начинающим вебмастерам', '', 'kak-dobavit-sait-v-iandeks-i-gugl-sovety-nachinaiushchim-vebmasteram', 'novosti/poslednie-novosti/', 'создание, сайта, само, себе, является, нелегким, довольно, продолжительным, процессом, позади, неприятно, обнаружить, ваш, красивый, наполненный, полезными, материалами, сайт, никто, кроме, самих, заходит, пожалуй, владельцы, сайтов, которые, запустили, свой, первый, проект', 'Создание сайта само по себе является нелегким и довольно продолжительным   процессом, и когда все уже позади, довольно неприятно обнаружить, что   на ваш красивый и наполненный полезными материалами сайт никто кроме  вас  самих не заходит. Пожалуй, владел', '<p>Создание сайта само по себе является нелегким и довольно продолжительным\n  процессом, и когда все уже позади, довольно неприятно обнаружить, что \n на ваш красивый и наполненный полезными материалами сайт никто кроме \nвас  самих не заходит. Пожалуй, владельцы сайтов, которые запустили свой\n  первый проект, чаще всего испытывают неприятное удивление в связи с \nэтим  фактом. А на самом деле все просто – прежде всего, нужно знать как\n  добавить сайт в поисковики.</p>', '<p>Создание сайта само по себе является нелегким и довольно \nпродолжительным процессом, и когда все уже позади, довольно неприятно \nобнаружить, что на ваш красивый и наполненный полезными материалами сайт\n никто кроме вас самих не заходит. Пожалуй, владельцы сайтов, которые \nзапустили свой первый проект, чаще всего испытывают неприятное удивление\n в связи с этим фактом. А на самом деле все просто – прежде всего, нужно\n знать как добавить сайт в поисковики.\n</p><p>Посетители переходят на сайты из результатов поиска, выдаваемых им \nGoogle при вводе определенного запроса. Но, чтобы появится в выдаче по \nэтому запросу, нужно сначала, чтобы поисковый робот проиндексировал ваш \nсайт, то есть, внес его в свою поисковую базу. Поэтому, если вы имеете \nпонятие про <a href=\"http://www.imagecms.net/blog/obzory/biznes-v-internete-kak-perspektivnyi-trend\" target=\"_blank\">бизнес в Интернете</a>, и уже запустили собственный ресурс, вопрос как добавить сайт в поисковики будет актуальным для каждого вебмастера.</p>\n<p><a href=\"http://www.imagecms.net/download\"><img src=\"http://www.imagecms.net/uploads/images/blog/2.png\" alt=\"Мощная система для создания сайтов любых типов\" height=\"183\" width=\"705\"></a></p>\n<p>Часто бывает, что ресурс может проиндексироваться сразу же после \nрегистрации доменного имени, но лучше всего самостоятельно добавить сайт\n в поисковые системы. Тем более, учитывая тот факт, что это займет \nсовсем немного времени.</p><br><h3>Добавить сайт в Яндекс</h3><br><p>Для того, чтобы сообщить этому поисковику о новом сайте, нужно \nперейти на страницу со специальной формой, которая находится по  \nследующему адресу: <a href=\"http://webmaster.yandex.ua/addurl.xml\" target=\"_blank\">http://webmaster.yandex.ua/addurl.xml</a></p>\n<p>С помощью панельки можно просто и быстро добавить сайт в Яндекс с \nминимальными затратами времени и сил. Перейдя по ссылке, вы увидите \nследующую форму: <br><img src=\"http://www.imagecms.net/uploads/images/blog/add_yandex.jpg\" alt=\"Форма добавления сайта в индекс ПС Яндекс\" height=\"266\" width=\"695\"> <br>В\n поле URL ведите адрес сайта, ниже введите цифры с картинки каптчи \n(защита от спама), после чего нажмите кнопку «Добавить». Поздравляем! \nТолько что вы смогли добавить сайт в Яндекс и уже в ближайшее время на \nнего заглянет поисковый паук, чтобы внести в свою базу. После этого он \nпоявится в результатах поиска, и вы получите первых посетителей.</p><br><h3>Добавить сайт в Гугл</h3><br><p>Эта поисковая система является мировым лидером в области web-поиска, и\n сообщить ей о своем сайте нужно обязательно. Добавить сайт в Гугл еще \nпроще, чем в предыдущем случае, ведь не нужно даже вводить каптчу. \nПерейдите <a href=\"https://www.google.com/webmasters/tools/submit-url?hl=ru\" target=\"_blank\">по этой ссылке</a> и перед вами откроется окно, с помощью которого можно добавить сайт в Google: <br><img src=\"http://www.imagecms.net/uploads/images/blog/add_google.jpg\" alt=\"Добавление url в индекс ПС Google\" height=\"311\" width=\"695\"><br>\n Введите адрес и по желанию можно добавить примечание. Хотя вряд ли в \nэтом есть смысл, так как это ни на что не влияет. Кстати, не нужно \nвводить никаких отдельных страниц, чтобы добавить сайт в Гугл достаточно\n вставить в поле формы URL главной страницы.</p>\n<p>Как видите, добавить сайт в поисковые системы совсем не сложно. Тем \nболее, если учитывать, что хорошая индексация ведет к росту \nпосещаемости, а значит и повышает <a href=\"http://www.imagecms.net/blog/obzory/otsenka-stoimosti-saita-i-faktory-kotorye-vliiaiut-na-tsenu\" target=\"_blank\">стоимость сайта</a>\n в целом. Это займет у вас минимум времени, но благодаря проделанным \nоперациям вы сможете быть уверены в том, что поисковые системы узнают о \nсайте и добавят его в базу, а значит, на сайт начнут заходить \nпосетители. Теперь вы знаете как добавить сайт в Google и можете без \nпроблем сделать это самостоятельно.</p>', 70, '', '', 0, 1, 0, 'draft', 'admin', 1362225699, 1362225699, 0, 1, 3, 0);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (93, '8Р: Бизнес в сети', '', '8r-biznes-v-seti', 'novosti/poslednie-novosti/', 'редкий, предприниматель, наше, время, задается, вопросом, «как, помощью, интернета, увеличить, продажи, подробный, обстоятельный, ответ, каждый, сможет, получить, традиционной, ежегодной, конференции, бизнес, сети, которая, третий, состоится, одессе, ожидается, около, участников, этом', 'Редкий предприниматель в наше время не задается вопросом: «Как с помощью  интернета увеличить продажи?» Подробный и обстоятельный ответ каждый  сможет получить на традиционной ежегодной конференции “8Р: Бизнес в  сети”, которая в третий раз состоится в Од', '<p>Редкий предприниматель в наше время не задается вопросом: «Как с помощью\n интернета увеличить продажи?» Подробный и обстоятельный ответ каждый \nсможет получить на традиционной ежегодной конференции “8Р: Бизнес в \nсети”, которая в третий раз состоится &nbsp;в Одессе 13.07.2013г. Ожидается \nоколо 700 участников.</p>', '<br><p><img src=\"http://www.imagecms.net/uploads/images/8p_logo.jpg\" height=\"70\" width=\"300\">Редкий\n предприниматель в наше время не задается вопросом: «Как с помощью \nинтернета увеличить продажи?» Подробный и обстоятельный ответ каждый \nсможет получить на традиционной ежегодной конференции “8Р: Бизнес в \nсети”, которая в третий раз состоится &nbsp;в Одессе 13.07.2013г. Ожидается \nоколо 700 участников.</p>\n<p dir=\"ltr\">В этом году оргкомитет выбрал наиболее актуальные темы, \nпригласил более 40 докладчиков и решил немного отойти от теоретики, \nсделав упор на примеры из практики. Большое количество кейсов – \nотличительная черта “8P” 2013.</p>\n<p dir=\"ltr\">В программе конференции предусмотрены 4 потока:</p><br><ul><li dir=\"ltr\">Интернет-маркетинг &nbsp;– инструменты онлайн продвижения бизнеса</li><li dir=\"ltr\">E-commerce – привлечение новых клиентов, увеличение конверсии, формирование лояльности</li><li dir=\"ltr\">Кейсы – примеры успешного продвижения в сети</li><li dir=\"ltr\">Мастер-классы – полтора часа непрерывного общения&nbsp;</li></ul><br><p>Оформить регистрацию на конференцию “8Р: Бизнес в сети” 2013 можно <a href=\"http://8p.ua/?utm_source=p20954&amp;utm_medium=press_release&amp;utm_campaign=8p\">здесь</a>.</p>\n<p dir=\"ltr\">Там же вы можете посмотреть фото и видео с прошлогодней конференции, прочитать отзывы участников.</p>\n<p dir=\"ltr\">Стартовая цена билета – 950 грн. Внимание: с каждым проданным билетом она возрастает на 1 грн.<br>Адрес\n конференции: г.Одесса, банкетный дом Ренессанс. От железнодорожного \nвокзала будет курсировать комфортабельный автобус. Добираться можно и на\n своем автомобиле - бесплатная парковка к вашим услугам.</p>\n<p>В программе также кофе-брейки, обед, афтер-пати.<br>Испытание на стойкость - афтер-афтер-пати.<br> <br>Организатор конференции: <a href=\"http://netpeak.ua\">Netpeak</a> - агентство интернет-маркетинга</p>', 70, '', '', 0, 1, 0, 'draft', 'admin', 1362225792, 1362225792, 0, 1, 3, 0);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (94, 'Lviv Social Media Camp 2013', '', 'lviv-social-media-camp-2013', 'novosti/arhiv/', 'lviv, social, media, camp, третья, ежегодная, конференция, вопросам, продвижения, малого, бизнеса, социальных, сетях, состоится, февраля, успешные, форумы, года, собравшие, почти, участников, доказали, покорения, изменчивого, мира, медиа, необходимы, незаурядные, знания, опыт', 'Lviv Social Media Camp 2013 - третья ежегодная конференция по вопросам  продвижения малого бизнеса в социальных сетях - состоится 23 февраля.  Успешные форумы 2011 и 2012 года, собравшие почти 700 участников,  доказали - для покорения изменчивого мира соц', '<p>Lviv Social Media Camp 2013 - третья ежегодная конференция по вопросам \nпродвижения малого бизнеса в социальных сетях - состоится 23 февраля. \nУспешные форумы 2011 и 2012 года, собравшие почти 700 участников, \nдоказали - для покорения &nbsp;изменчивого мира социальных медиа необходимы \nнезаурядные знания и опыт, которыми могут поделиться только настоящие \nпрофессионалы. Как следствие - десятки новых ярких звезд, вспыхнувших в \nукраинском бизнес-пространстве. Такие результаты не могли не вдохновить \nорганизаторов на продолжение работы в этом перспективном направлении.</p>', '<p><img src=\"http://www.imagecms.net/uploads/images/smcamp2013.png\" height=\"237\" width=\"850\"><br><a href=\"http://smcamp.com.ua\">Lviv Social Media Camp 2013</a>\n - третья ежегодная конференция по вопросам продвижения малого бизнеса в\n социальных сетях - состоится 23 февраля. Успешные форумы 2011 и 2012 \nгода, собравшие почти 700 участников, доказали - для покорения \n&nbsp;изменчивого мира социальных медиа необходимы незаурядные знания и опыт,\n которыми могут поделиться только настоящие профессионалы. Как следствие\n - десятки новых ярких звезд, вспыхнувших в украинском \nбизнес-пространстве. Такие результаты не могли не вдохновить \nорганизаторов на продолжение работы в этом перспективном направлении.<br> <br>Красноречивые факты:</p><br><ul><li dir=\"ltr\">22 млн. гривен - общий объем видеорекламы в Уанете.</li><li dir=\"ltr\">680 млн. гривен - объем украинского рынка интернет-рекламы</li><li dir=\"ltr\">180 млн. гривен - объем прошлогоднего рынка Digital-услуг</li><li dir=\"ltr\">Около 20% - &nbsp;прогнозируемый рост Digital на 2013 год</li></ul><br><p><br>Нынешняя программа конференции разработана специально для \nпредпринимателей и представителей малого бизнеса, которым интересны \n&nbsp;новые возможности для продвижения своего продукта. К тому же, \nконференция станет точкой сбора для украинских профессионалов SMM.<br> <br>По традиции, в программе конференции будет три потока:<br> <br>Social Media Marketing:</p><br><ul><li dir=\"ltr\">Украинский SMM в 2013 году - успехи и провалы</li><li dir=\"ltr\">Нужен ли SMM украинскому бизнесу?</li><li dir=\"ltr\">Методы манипулирования выдачей Facebook</li><li dir=\"ltr\">Как продвигать \"звезд\" в YouTube</li><li dir=\"ltr\">Вирусные промокампании</li><li dir=\"ltr\">Использование возможностей Pinterest и Instagram</li><li dir=\"ltr\">Social Media Optimization: о секретных алгоритмах Facebook</li><li dir=\"ltr\">Опыт работы лучших украинских Digital-агентств</li></ul><br><p><br>Social Media и бизнес:</p><br><ul><li dir=\"ltr\">Нуждается ли мой бизнес в использовании &nbsp;соц. сетей - как узнать?</li><li dir=\"ltr\">Успешные локальные маркетинговые кампании - рассмотрим примеры</li><li dir=\"ltr\">Facebook в Украине, Киеве, во Львове - определяем пользу</li><li dir=\"ltr\">Facebook-страница - как правильно оформить?</li><li dir=\"ltr\">Максимум результата за минимум времени - как добиться?</li><li dir=\"ltr\">Агентства – стоит ли доверяться?</li></ul><br><p><br>Новые медиа, разработка, стартапы:</p><br><ul><li dir=\"ltr\">Собственные сервисы и social media - вопросы интеграции</li><li dir=\"ltr\">Mixed media</li><li dir=\"ltr\">Twitter, Facebook, Foursquare API</li><li dir=\"ltr\">BlogCamp</li><li dir=\"ltr\">SmartTV</li><li dir=\"ltr\">Линчи social media стартапов </li></ul><br><p><br>Стоимость билета:<br>200 грн. - Первые 50 билетов для ранних пташек<br>300 грн. - Следующие 200 билетов<br>500 грн. - Предпоследние 50 билетов<br>800 грн. - Кто поздно приходит, тому последние 20 билетов<br> <br>Встречаемся&nbsp;23 февраля в конференц-зале УКУ (ул.. Хуторовка, 35а).</p>', 71, '', '', 0, 1, 0, 'draft', 'admin', 1362225886, 1362225886, 0, 1, 3, 0);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (95, 'Оценка стоимости сайта и факторы, которые влияют на цену', '', 'otsenka-stoimosti-saita-i-faktory-kotorye-vliiaiut-na-tsenu', 'novosti/arhiv/', 'как, время, разработки, продажи, интернет, ресурса, учитывается, достаточно, много, факторов, влияющих, цену, поэтому, нужно, уметь, оценить, стоимость, сайта, своими, силами, важно, планируете, создание, коммерческого, собираетесь, запустить, личный, блог, знать, финансовые', 'Как во время разработки, так и во время продажи Интернет-ресурса   учитывается достаточно много факторов, влияющих на его цену. Поэтому   нужно уметь оценить стоимость сайта своими силами. Не важно, планируете   ли вы создание коммерческого сайта или соби', '<p>Как во время разработки, так и во время продажи Интернет-ресурса  \nучитывается достаточно много факторов, влияющих на его цену. Поэтому  \nнужно уметь оценить стоимость сайта своими силами. Не важно, планируете \n ли вы создание коммерческого сайта или собираетесь запустить личный  \nблог, знать финансовые стороны вопроса никогда не будет лишним.</p>', '<br><p><img src=\"http://www.imagecms.net/uploads/images/blog/site-price.jpg\" alt=\"Быстрая оценка любого сайта\" height=\"172\" width=\"250\">Как\n во время разработки, так и во время продажи Интернет-ресурса \nучитывается достаточно много факторов, влияющих на его цену. Поэтому \nнужно уметь оценить стоимость сайта своими силами. Не важно, планируете \nли вы создание коммерческого сайта или собираетесь запустить личный \nблог, знать финансовые стороны вопроса никогда не будет лишним. <a title=\"стоимость создания сайта\" href=\"http://www.imagecms.net/blog/obzory/skolko-stoit-sait-postroit\" target=\"_blank\">Стоимость создания сайта</a>\n для многих является ключевым фактором, влияющим на принятие решения о \nразработка. Многое зависит от необходимых вам возможностей, ведь для \nпростого блога вполне хватит бесплатной версии ImageCMS, а вот уже для \nторговой площадки понадобится коммерческий модуль Интернет-магазина.</p>\n<p>Оценка стоимости сайта при его разработке зависит от нескольких факторов. Пройдемся по пунктам:</p><br><ul><li>Дизайн. Если он уникальный – стоимость будет выше, но в этом случае \nучитываются все ваши пожелания и специфика вашего бизнеса. \nИндивидуальный подход позволяет сделать внешний вид сайта именно таким, \nкаким вы бы хотели его видеть, и поднять <a title=\"юзабилити сайт\" href=\"http://www.imagecms.net/blog/obzory/osnovy-iuzabiliti-saita\" target=\"_blank\">юзабилити сайта</a>\n на действительно высокий уровень. Шаблонный сайт обойдется дешевле, что\n позволит оценить стоимость сайта ниже, но и качество не будет на \nвысоком уровне. Кроме того, такой же шаблон может использоваться и на \nдесятках других сайтов.</li><li>Функциональность. Думаю, не нужно быть профессионалом в \nweb-разработке, чтобы понять, что различие в цене разработки \nсайта-визитки для местного фотографа и туристического портала, будет \nсущественным. Оценка стоимости сайта в таком случае определяется \nсложностью добавляемых модулей.</li><li>Контент. Пожалуй, о важности качественного контента на данный момент\n можно и не напоминать, это аксиома известная всем, как заказчикам,  так\n и исполнителям. Конечно, качественный копирайтинг не может стоить \nдешево, и чем больше таких страниц нужно создать, тем дороже это \nобойдется. Точные знания относительно необходимого количества контента, \nпозволяет узнать стоимость сайта более подробно. Но стоит помнить, что \nвложения в качество обязательно окупятся в долгосрочной перспективе.</li><li>Оптимизация под поисковые системы (SEO). Если вам не нужны \nпосетители, а сайт сделан просто для галочки и надписи на визитке – \nможете смело пропускать этот пункт. Вот только зачем тогда его вообще \nсоздавать? Оптимизация сайта является важным пунктом договора, который \nзаранее оговаривается при разработке. Чтобы узнать стоимость сайта, \nнеобязательно сразу же просчитывать этот пункт, это скорее затраты \nбудущего периода. Особенно хорошо нужно проработать такой момент как <a title=\"подбор ключевых слов для сайта\" href=\"http://www.imagecms.net/blog/obzory/podbor-kliuchevyh-slov-kak-sdelat-vse-pravilno\" target=\"_blank\">подбор ключевых слов</a> для сайта, то есть, составление семантического ядра.</li><li>Тематика сайта. Коммерческая ниша в любом случае будет цениться гораздо выше, чем развлекательная.</li><li>Количество страниц в индексе. Чем их больше, тем выше можно \nвыставить цену при продаже. Хороший багаж в плане контента будет полезен\n для любого проекта, как залог лояльности со стороны поисковых систем. \nГлавное – чтобы все материалы сайта были уникальными, а не обычным \nкопипастом.</li><li>Показатели тИЦ и PR. Пожалуй, оценить стоимость сайта на основе \nэтого показателя проще всего. Тут действует простое правило – чем \nбольше, тем лучше.</li><li>Посещаемость сайта. Оценка стоимости сайта с высокой посещаемостью \nвсегда была высокой. В последнее время, в связи с ужесточением поисковых\n алгоритмов и увеличением конкуренции, сайты с более-менее пристойным \nколичеством посетителей стали цениться еще выше.</li><li>Присутствие в каталогах DMOZ, Mail.ru и Яндекс.Каталог. Хотя данный \nфактор уже не имеет такого веса как во времена расцвета ссылочных бирж, \nно он все еще играет весомую роль, если вас интересует оценка стоимости \nсайта, так как является своеобразным знаком качества от поисковиков.</li></ul><br><p><a href=\"http://www.imagecms.net/download\"><img src=\"http://www.imagecms.net/uploads/images/blog/2.png\" alt=\"Загрузить ImageCMS Corporate бесплатно\" height=\"183\" width=\"705\"></a></p>\n<p>Перечисленные выше факторы позволяют точно оценить стоимость сайта \nеще на этапе проектирования, и в случае надобности – внести необходимые \nкорректировки. В случае, если ресурс принадлежит вам лично, а не \nкомпании, узнать стоимость сайта также очень важно, ведь он является \nвыгодным активом, который можно в любой момент продать. Это может быть \nкак блог, так и узкотематический проект, который хорошо закрепился в \nсвоей нише и представляет ценность для пользователей.</p>\n<p>В таком случае узнать стоимость сайта можно с помощью оценки немного \nдругих показателей, чем в первом случае. При продаже на стоимость \nповлияют такие показатели:</p>\n<p>В этой статье мы перечислили все основные факторы, с учетом которых \nможно оценить стоимость сайта и применить данные методики по отношению \nкак корпоративному, так и личному проекту.</p>', 71, '', '', 0, 1, 0, 'draft', 'admin', 1362225958, 1362225958, 0, 1, 3, 0);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (96, 'Зачем вашему оффлайн-бизнесу нужен Интернет-магазин?', '', 'zachem-vashemu-offlain-biznesu-nuzhen-internet-magazin', 'novosti/arhiv/', 'несмотря, бурный, рост, интернет, коммерции, далеко, предприниматели, понимают, преимущества, магазина, особенно, оффлайная, торговая, точка, именно, таком, случае, проявляются, лучше, всего, ведь, получаете, только, отличный, источник, дополнительного, дохода, возможность, сравнения, эффективности', 'Несмотря на бурный рост Интернет-коммерции, далеко не все  предприниматели понимают, в чем преимущества Интернет-магазина, особенно  если уже есть оффлайная торговая точка. Но именно в таком случае  преимущества Интернет-магазина проявляются лучше всего,', '<p>Несмотря на бурный рост Интернет-коммерции, далеко не все \nпредприниматели понимают, в чем преимущества Интернет-магазина, особенно\n если уже есть оффлайная торговая точка. Но именно в таком случае \nпреимущества Интернет-магазина проявляются лучше всего, ведь вы \nполучаете не только отличный источник дополнительного дохода, но и \nвозможность сравнения эффективности вложения средств.</p>', '<br><p><img src=\"http://www.imagecms.net/uploads/images/blog/inet-magaz.jpg\" alt=\"Интернет как перспективная бизнес-среда\" height=\"200\" width=\"213\">Несмотря\n на бурный рост Интернет-коммерции, далеко не все предприниматели \nпонимают, в чем преимущества Интернет-магазина, особенно если уже есть \nоффлайная торговая точка. Но именно в таком случае преимущества \nИнтернет-магазина проявляются лучше всего, ведь вы получаете не только \nотличный источник дополнительного дохода, но и возможность сравнения \nэффективности вложения средств.</p>\n<p>Так зачем нужен Интернет-магазин современному предпринимателю? В \nзависимости от того, есть ли у вас уже действующий оффлайн-бизнес, он \nможет быть как дополнением к нему, или же основным источником дохода. \nУже отталкиваясь от этого, нужно планировать бюджет создания магазина и \nего развития. Над онлайновой торговой площадкой нужно вести постоянную \nработу, подробно проработать <a href=\"http://www.imagecms.net/blog/obzory/biznes-plan-internet-magazina-na-chto-obratit-vnimanie\" target=\"_blank\">бизнес-план Интернет-магазина</a>\n - это не просто визитка, созданная «для галочки»... это полноценный и \nочень эффективный инструмент продаж. Плюсов у онлайн-бизнеса, по \nсравнению с оффлайном, довольно много.</p>\n<p><a href=\"http://www.imagecms.net/download\"><img src=\"http://www.imagecms.net/uploads/images/blog/2.png\" alt=\"Система для создания интернет-магазинов - ImageCMS\" height=\"183\" width=\"705\"></a></p>\n<p>Перечислим основные преимущества Интернет-магазина:</p><br><ul><li>можно обойтись без аренды производственных площадей и складов -  достаточно небольшого офиса для обслуживания;</li><li>может быть как основным источником прибыли, так и дополнительным по \nотношению к основному бизнесу - это важное обоснование при вопросе зачем\n нужен Интернет-магазин;</li><li>гораздо меньший порог вхождения, хотя конкуренция в разных тематиках отличается;</li><li>нет региональных ограничений: можно находить клиентов как в своем городе или области, так и по всей стране;</li><li>доступность в режиме 24/7: круглосуточно и семь дней в неделю;</li><li>такие преимущества Интернет-магазина как экономия времени и свобода выбора, играют важную роль и для покупателей;</li><li><a title=\"бизнес в Интернете\" href=\"http://www.imagecms.net/blog/obzory/biznes-v-internete-kak-perspektivnyi-trend\" target=\"_blank\">бизнес в Интернете</a>\n не требует большого количества обслуживающего персонала: можно обойтись\n одним консультантом там, где обычные торговые точки обслуживают \nпятерых;</li><li>нет ограничений по количеству представленных на виртуальной витрине товаров;</li><li>в случае с раскруткой и продвижением можно сфокусироваться только на\n потенциально заинтересованных в ваших товарах или услугах \nпользователях.</li></ul><br><p>Можно привести несколько примеров развертывания Интернет-магазинов на платформе <a href=\"http://www.imagecms.net/products/imagecms-shop-professional\">ImageCMS Shop Professional</a>:\n boutique-ekaterinasmolina.ru, euro-technika.com.ua и др. Как видно из \nпримеров, можно торговать в онлайне как с небольшим ассортиментом, так и\n предлагая тысячи наименований товаров. Учитывая вышеперечисленное, \nкаждый владелец бизнеса может понять, зачем нужен Интернет-магазин и \nкакие выгоды от его разработки можно получить (независимо от того, \nработаете ли вы с розничной торговлей или в области B2B).</p>', 71, '', '', 0, 1, 0, 'draft', 'admin', 1362226037, 1362226037, 0, 3, 3, 0);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (97, '', NULL, 'kontakti', '', NULL, NULL, NULL, '', 0, 'conracts', '', 0, 1, 0, 'publish', 'Administrator', 1291295870, 1291295888, 0, 8, 32, 68);


#
# TABLE STRUCTURE FOR: content_field_groups
#

DROP TABLE IF EXISTS content_field_groups;

CREATE TABLE `content_field_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO content_field_groups (`id`, `name`, `description`) VALUES (9, 'g1', '');
INSERT INTO content_field_groups (`id`, `name`, `description`) VALUES (11, 'g4', '');
INSERT INTO content_field_groups (`id`, `name`, `description`) VALUES (12, 'g3', '');


#
# TABLE STRUCTURE FOR: content_fields
#

DROP TABLE IF EXISTS content_fields;

CREATE TABLE `content_fields` (
  `field_name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `data` text NOT NULL,
  `weight` int(11) NOT NULL,
  `in_search` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`field_name`),
  UNIQUE KEY `field_name` (`field_name`),
  KEY `type` (`type`),
  KEY `in_search` (`in_search`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO content_fields (`field_name`, `type`, `label`, `data`, `weight`, `in_search`) VALUES ('field_doc', 'text', 'Documentation', 'a:4:{s:7:\"initial\";s:0:\"\";s:9:\"help_text\";s:8:\"PDF-file\";s:19:\"enable_file_browser\";s:1:\"1\";s:10:\"validation\";s:0:\"\";}', 6, 0);


#
# TABLE STRUCTURE FOR: content_fields_data
#

DROP TABLE IF EXISTS content_fields_data;

CREATE TABLE `content_fields_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `item_type` varchar(15) NOT NULL,
  `field_name` varchar(255) NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`),
  KEY `item_type` (`item_type`),
  KEY `field_name` (`field_name`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

INSERT INTO content_fields_data (`id`, `item_id`, `item_type`, `field_name`, `data`) VALUES (23, 89, 'page', 'field_doc', '');


#
# TABLE STRUCTURE FOR: content_fields_groups_relations
#

DROP TABLE IF EXISTS content_fields_groups_relations;

CREATE TABLE `content_fields_groups_relations` (
  `field_name` varchar(64) NOT NULL,
  `group_id` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO content_fields_groups_relations (`field_name`, `group_id`) VALUES ('field_sfsdfsdf', 0);
INSERT INTO content_fields_groups_relations (`field_name`, `group_id`) VALUES ('field_sfsdfsdf', 11);
INSERT INTO content_fields_groups_relations (`field_name`, `group_id`) VALUES ('field_fyjtyutyu', 0);
INSERT INTO content_fields_groups_relations (`field_name`, `group_id`) VALUES ('field_fg12', 9);
INSERT INTO content_fields_groups_relations (`field_name`, `group_id`) VALUES ('field_fg12', 9);
INSERT INTO content_fields_groups_relations (`field_name`, `group_id`) VALUES ('field_doc', 11);


#
# TABLE STRUCTURE FOR: content_permissions
#

DROP TABLE IF EXISTS content_permissions;

CREATE TABLE `content_permissions` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `page_id` bigint(11) NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `page_id` (`page_id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

INSERT INTO content_permissions (`id`, `page_id`, `data`) VALUES (23, 80, 'a:3:{i:0;a:1:{s:7:\"role_id\";s:1:\"0\";}i:1;a:1:{s:7:\"role_id\";s:1:\"1\";}i:2;a:1:{s:7:\"role_id\";s:1:\"2\";}}');


#
# TABLE STRUCTURE FOR: content_tags
#

DROP TABLE IF EXISTS content_tags;

CREATE TABLE `content_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `page_id` (`page_id`),
  KEY `tag_id` (`tag_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: custom_fields
#

DROP TABLE IF EXISTS custom_fields;

CREATE TABLE `custom_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_type_id` int(11) NOT NULL,
  `field_name` varchar(64) NOT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT '1',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `validators` varchar(255) DEFAULT NULL,
  `entity` varchar(32) DEFAULT NULL,
  `options` varchar(65) DEFAULT NULL,
  `classes` text,
  `position` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=96 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: custom_fields_data
#

DROP TABLE IF EXISTS custom_fields_data;

CREATE TABLE `custom_fields_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_id` int(11) NOT NULL,
  `entity_id` int(11) NOT NULL,
  `field_data` text,
  `locale` varchar(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=514 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: custom_fields_i18n
#

DROP TABLE IF EXISTS custom_fields_i18n;

CREATE TABLE `custom_fields_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(4) NOT NULL,
  `field_label` varchar(255) DEFAULT NULL,
  `field_description` text,
  `possible_values` text,
  PRIMARY KEY (`id`,`locale`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: emails
#

DROP TABLE IF EXISTS emails;

CREATE TABLE `emails` (
  `name` varchar(50) CHARACTER SET utf8 NOT NULL,
  `template` text CHARACTER SET utf8 NOT NULL,
  `settings` text CHARACTER SET utf8 NOT NULL,
  `locale` varchar(5) CHARACTER SET utf8 NOT NULL,
  `description` text CHARACTER SET utf8 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('wishListMail', 'Шановний %userName%. Ви створили наступний список побажань %wishKey%<br>Створений: %wishDateCreated%  ', 'a:4:{s:5:\"theme\";s:29:\"Список побажань\";s:4:\"from\";s:43:\"Адміністрація магазину\";s:9:\"from_mail\";s:19:\"admin@localhost.loc\";s:9:\"variables\";a:3:{i:0;s:10:\"%userName%\";i:1;s:9:\"%wishKey%\";i:2;s:17:\"%wishDateCreated%\";}}', 'ua', 'Лист про створений список побажань  ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('wishListMail', '<h2> Уважаемый %userName%.</h2> Вы создали следующий список желаний %wishKey%<div>Ссылка на просмотр списка желаний -&nbsp;&nbsp; %wishLink% <br>Создан %wishDateCreated%   %orderId% </div>  ', 'a:5:{s:5:\"theme\";s:14:\"Вишлист\";s:4:\"from\";s:43:\"Администрация магазина\";s:9:\"from_mail\";s:19:\"admin@localhost.loc\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Письмо о создании списка желаний.  ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('noticeOfAppearance', 'Шаблон письма  ', 'a:5:{s:5:\"theme\";s:46:\"Уведомлениен о появлении\";s:4:\"from\";s:37:\"Администрация сайта\";s:9:\"from_mail\";s:0:\"\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Шаблон письма об уведомлении о появлении  ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('callBackNotification', 'Callback notification  ', 'a:5:{s:5:\"theme\";s:8:\"Callback\";s:4:\"from\";s:24:\"Пользователь\";s:10:\"from_email\";s:0:\"\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Шаблон письма для callback  ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('toAdminOrderNotification', 'Шаблон письма для администратора о совершении заказа  ', 'a:5:{s:5:\"theme\";s:59:\"Уведомление о совершении заказа\";s:4:\"from\";s:34:\"Админ панель сайта\";s:10:\"from_email\";s:0:\"\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Шаблон письма для администратора о совершении заказа    ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('toUserOrderNotification', 'Здравствуйте, %userName%.<br><br>Мы благодарны Вам за то, что совершили заказ в нашем магазине \"ImageCMS Shop\"<br><br>Вы указали следующие контактные данные:<br><br>Email адрес: %userEmail%<br><br>Номер телефона: %userPhone%<br><br>Адрес доставки: %userDeliver%<br><br>Менеджеры нашего магазина вскоре свяжутся с Вами и помогут с оформлением и оплатой товара.<br><br>Также, Вы можете всегда посмотреть за статусом Вашего заказа, перейдя по ссылке:&nbsp; %orderLink%.<br><br>Спасибо за ваш заказ, искренне Ваши, сотрудники ImageCMS Shop.<br><br>При возникновении любых вопросов, обращайтесь за телефонами:<br><br>+7 (095) 222-33-22 +38 (098) 222-33-22  ', 'a:5:{s:5:\"theme\";s:80:\"Уведомление покупателя о совершении заказа\";s:4:\"from\";b:0;s:9:\"from_mail\";s:21:\"noreply@localhost.loc\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Уведомление покупателя о совершении заказа  ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('toUserChangeOrderStatusNotification', 'Уведомление пользователя о смене статуса заказа    ', 'a:5:{s:5:\"theme\";s:89:\"Уведомление пользователя о смене статуса заказа\";s:4:\"from\";s:37:\"Администрация сайта\";s:10:\"from_email\";s:19:\"admin@localhost.loc\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Уведомление пользователя о смене статуса заказа    ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('afterOrderUserRegistration', 'Письмо о регистрации на сатйе после совершения заказа  ', 'a:5:{s:5:\"theme\";s:38:\"Регистрация на сайте\";s:4:\"from\";s:43:\"Администрация магазина\";s:10:\"from_email\";s:19:\"admin@localhost.loc\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Письмо о регистрации на сатйе после совершения заказа    ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('forgotPassword', 'Здравствуйте!<br><br>На сайте %webSiteName% создан запрос на восстановление пароля для Вашего аккаунта.<br><br>Для завершения процедуры восстановления пароля перейдите по ссылке %resetPasswordUri%<br><br>Ваш новый пароль для входа: %password%<br><br>Если это письмо попало к Вам по ошибке просто проигнорируйте его.<br><br>При возникновении любых вопросов, обращайтесь по телефонам:<br><br>(012)&nbsp; 345-67-89 , (012)&nbsp; 345-67-89<br><br>---<br><br>С уважением,<br><br>сотрудники службы продаж %webSiteName%  ', 'a:5:{s:5:\"theme\";s:41:\"Восстановление пароля\";s:4:\"from\";s:37:\"Администрация сайта\";s:9:\"from_mail\";s:0:\"\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Шаблон письма о восстановлении пароля  ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('wishListMail', 'Шановний %userName%. Ви створили наступний список побажань %wishKey%<br>Створений: %wishDateCreated%  ', 'a:4:{s:5:\"theme\";s:29:\"Список побажань\";s:4:\"from\";s:43:\"Адміністрація магазину\";s:9:\"from_mail\";s:19:\"admin@localhost.loc\";s:9:\"variables\";a:3:{i:0;s:10:\"%userName%\";i:1;s:9:\"%wishKey%\";i:2;s:17:\"%wishDateCreated%\";}}', 'ua', 'Лист про створений список побажань  ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('wishListMail', '<h2> Уважаемый %userName%.</h2> Вы создали следующий список желаний %wishKey%<div>Ссылка на просмотр списка желаний -&nbsp;&nbsp; %wishLink% <br>Создан %wishDateCreated%   %orderId% </div>  ', 'a:5:{s:5:\"theme\";s:14:\"Вишлист\";s:4:\"from\";s:43:\"Администрация магазина\";s:9:\"from_mail\";s:19:\"admin@localhost.loc\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Письмо о создании списка желаний.  ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('noticeOfAppearance', 'Шаблон письма  ', 'a:5:{s:5:\"theme\";s:46:\"Уведомлениен о появлении\";s:4:\"from\";s:37:\"Администрация сайта\";s:9:\"from_mail\";s:0:\"\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Шаблон письма об уведомлении о появлении  ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('callBackNotification', 'Callback notification  ', 'a:5:{s:5:\"theme\";s:8:\"Callback\";s:4:\"from\";s:24:\"Пользователь\";s:10:\"from_email\";s:0:\"\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Шаблон письма для callback  ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('toAdminOrderNotification', 'Шаблон письма для администратора о совершении заказа  ', 'a:5:{s:5:\"theme\";s:59:\"Уведомление о совершении заказа\";s:4:\"from\";s:34:\"Админ панель сайта\";s:10:\"from_email\";s:0:\"\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Шаблон письма для администратора о совершении заказа    ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('toUserOrderNotification', 'Здравствуйте, %userName%.<br><br>Мы благодарны Вам за то, что совершили заказ в нашем магазине \"ImageCMS Shop\"<br><br>Вы указали следующие контактные данные:<br><br>Email адрес: %userEmail%<br><br>Номер телефона: %userPhone%<br><br>Адрес доставки: %userDeliver%<br><br>Менеджеры нашего магазина вскоре свяжутся с Вами и помогут с оформлением и оплатой товара.<br><br>Также, Вы можете всегда посмотреть за статусом Вашего заказа, перейдя по ссылке:&nbsp; %orderLink%.<br><br>Спасибо за ваш заказ, искренне Ваши, сотрудники ImageCMS Shop.<br><br>При возникновении любых вопросов, обращайтесь за телефонами:<br><br>+7 (095) 222-33-22 +38 (098) 222-33-22  ', 'a:5:{s:5:\"theme\";s:80:\"Уведомление покупателя о совершении заказа\";s:4:\"from\";b:0;s:9:\"from_mail\";s:21:\"noreply@localhost.loc\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Уведомление покупателя о совершении заказа  ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('toUserChangeOrderStatusNotification', 'Уведомление пользователя о смене статуса заказа    ', 'a:5:{s:5:\"theme\";s:89:\"Уведомление пользователя о смене статуса заказа\";s:4:\"from\";s:37:\"Администрация сайта\";s:10:\"from_email\";s:19:\"admin@localhost.loc\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Уведомление пользователя о смене статуса заказа    ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('afterOrderUserRegistration', 'Письмо о регистрации на сатйе после совершения заказа  ', 'a:5:{s:5:\"theme\";s:38:\"Регистрация на сайте\";s:4:\"from\";s:43:\"Администрация магазина\";s:10:\"from_email\";s:19:\"admin@localhost.loc\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Письмо о регистрации на сатйе после совершения заказа    ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('forgotPassword', 'Здравствуйте!<br><br>На сайте %webSiteName% создан запрос на восстановление пароля для Вашего аккаунта.<br><br>Для завершения процедуры восстановления пароля перейдите по ссылке %resetPasswordUri%<br><br>Ваш новый пароль для входа: %password%<br><br>Если это письмо попало к Вам по ошибке просто проигнорируйте его.<br><br>При возникновении любых вопросов, обращайтесь по телефонам:<br><br>(012)&nbsp; 345-67-89 , (012)&nbsp; 345-67-89<br><br>---<br><br>С уважением,<br><br>сотрудники службы продаж %webSiteName%  ', 'a:5:{s:5:\"theme\";s:41:\"Восстановление пароля\";s:4:\"from\";s:37:\"Администрация сайта\";s:9:\"from_mail\";s:0:\"\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Шаблон письма о восстановлении пароля  ');


#
# TABLE STRUCTURE FOR: gallery_albums
#

DROP TABLE IF EXISTS gallery_albums;

CREATE TABLE `gallery_albums` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `cover_id` int(11) NOT NULL DEFAULT '0',
  `position` int(9) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL,
  `updated` int(11) NOT NULL,
  `tpl_file` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `created` (`created`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: gallery_albums_i18n
#

DROP TABLE IF EXISTS gallery_albums_i18n;

CREATE TABLE `gallery_albums_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `description` text NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`,`locale`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: gallery_category
#

DROP TABLE IF EXISTS gallery_category;

CREATE TABLE `gallery_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cover_id` int(11) NOT NULL DEFAULT '0',
  `position` int(9) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: gallery_category_i18n
#

DROP TABLE IF EXISTS gallery_category_i18n;

CREATE TABLE `gallery_category_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `description` text,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`locale`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: gallery_images
#

DROP TABLE IF EXISTS gallery_images;

CREATE TABLE `gallery_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `album_id` int(11) NOT NULL,
  `file_name` varchar(150) NOT NULL,
  `file_ext` varchar(8) NOT NULL,
  `file_size` varchar(20) NOT NULL,
  `position` int(9) NOT NULL,
  `width` int(6) NOT NULL,
  `height` int(6) NOT NULL,
  `uploaded` int(11) NOT NULL,
  `views` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: gallery_images_i18n
#

DROP TABLE IF EXISTS gallery_images_i18n;

CREATE TABLE `gallery_images_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`,`locale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: languages
#

DROP TABLE IF EXISTS languages;

CREATE TABLE `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang_name` varchar(100) NOT NULL,
  `identif` varchar(10) NOT NULL,
  `image` text NOT NULL,
  `folder` varchar(100) NOT NULL,
  `template` varchar(100) NOT NULL,
  `default` int(1) NOT NULL,
  `locale` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `identif` (`identif`),
  KEY `default` (`default`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

INSERT INTO languages (`id`, `lang_name`, `identif`, `image`, `folder`, `template`, `default`, `locale`) VALUES (3, 'Русский', 'ru', '', 'russian', 'commerce4x', 1, 'uk_UA');
INSERT INTO languages (`id`, `lang_name`, `identif`, `image`, `folder`, `template`, `default`, `locale`) VALUES (31, 'Англиский', 'en', '', '', 'newLevel', 0, 'en_US');
INSERT INTO languages (`id`, `lang_name`, `identif`, `image`, `folder`, `template`, `default`, `locale`) VALUES (32, 'Украинский', 'uk', '', '', 'newLevel', 0, 'uk_UA');


#
# TABLE STRUCTURE FOR: login_attempts
#

DROP TABLE IF EXISTS login_attempts;

CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(40) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ip_address` (`ip_address`),
  KEY `time` (`time`)
) ENGINE=MyISAM AUTO_INCREMENT=164 DEFAULT CHARSET=utf8;

INSERT INTO login_attempts (`id`, `ip_address`, `time`) VALUES (145, '37.229.227.141', '2016-02-26 14:55:15');
INSERT INTO login_attempts (`id`, `ip_address`, `time`) VALUES (144, '37.229.227.141', '2016-02-26 14:54:57');
INSERT INTO login_attempts (`id`, `ip_address`, `time`) VALUES (143, '37.229.227.141', '2016-02-26 14:54:42');
INSERT INTO login_attempts (`id`, `ip_address`, `time`) VALUES (146, '37.229.227.141', '2016-02-26 14:55:41');
INSERT INTO login_attempts (`id`, `ip_address`, `time`) VALUES (147, '37.229.227.141', '2016-02-26 15:01:07');
INSERT INTO login_attempts (`id`, `ip_address`, `time`) VALUES (148, '37.115.235.84', '2016-02-29 09:32:34');
INSERT INTO login_attempts (`id`, `ip_address`, `time`) VALUES (149, '37.115.235.84', '2016-02-29 09:33:34');
INSERT INTO login_attempts (`id`, `ip_address`, `time`) VALUES (150, '37.115.235.84', '2016-02-29 09:33:55');
INSERT INTO login_attempts (`id`, `ip_address`, `time`) VALUES (151, '37.115.235.84', '2016-03-01 12:18:11');


#
# TABLE STRUCTURE FOR: logs
#

DROP TABLE IF EXISTS logs;

CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` varchar(250) NOT NULL,
  `message` text NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`)
) ENGINE=MyISAM AUTO_INCREMENT=1235 DEFAULT CHARSET=utf8;

INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (741, 1, 'admin', 'Вышел из панели управления', 1363601996);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (742, 1, 'admin', 'Вошел в панель управления IP 127.0.0.1', 1363602140);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (743, 1, 'admin', 'Изменил настройки сайта', 1363605006);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (744, 1, 'admin', 'Создал виджет popular_products', 1363606273);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (745, 1, 'admin', 'Создал виджет new_products', 1363606324);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (746, 1, 'admin', 'Создал виджет action_products', 1363606361);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (747, 1, 'admin', 'Создал виджет brands', 1363606422);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (748, 1, 'admin', 'Создал виджет view_product', 1363606497);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (749, 1, 'admin', 'Создал виджет similar', 1363606582);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (750, 1, 'admin', 'Создал категорию        <a href=\"/admin/categories/edit/69\"> Новости</a>', 1363608590);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (751, 1, 'admin', 'Создал категорию        <a href=\"/admin/categories/edit/70\"> Последние новости</a>', 1363608751);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (752, 1, 'admin', 'Изменил категорию   <a href=\"/admin/categories/edit/70\"> Последние новости</a>', 1363608759);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (753, 1, 'admin', 'Создал категорию        <a href=\"/admin/categories/edit/71\"> Архив</a>', 1363608777);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (754, 1, 'admin', 'Изменил категорию   <a href=\"/admin/categories/edit/69\"> Новости</a>', 1363610618);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (755, 1, 'admin', 'Вышел из панели управления', 1363617075);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (756, 47, 'admin', 'Вышел из панели управления', 1368174639);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (757, 47, 'admin', 'Вошел в панель управления IP 127.0.0.1', 1368174783);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (758, 47, 'admin', 'Очистил кеш', 1368174887);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (759, 1, 'Administrator', 'Введен IP панели управления 93.78.126.221', 1386267478);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (760, 1, 'Administrator', 'Введен IP панели управления 195.2.237.17', 1386270946);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (761, 1, 'Administrator', 'Введен IP панели управления 82.144.203.66', 1386313497);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (762, 1, 'Administrator', 'Введен IP панели управления 82.144.203.66', 1386314563);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (763, 1, 'Administrator', 'Кэш очищен', 1386321298);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (764, 1, 'Administrator', 'Кэш очищен', 1386321299);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (765, 1, 'Administrator', 'Настройки сайта изменены', 1386327027);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (766, 1, 'Administrator', 'Настройки сайта изменены', 1386327119);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (767, 1, 'Administrator', 'Настройки сайта изменены', 1386327130);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (768, 1, 'Administrator', 'Настройки сайта изменены', 1386327138);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (769, 1, 'Administrator', 'Настройки сайта изменены', 1386327146);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (770, 1, 'Administrator', 'Настройки сайта изменены', 1386327148);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (771, 1, 'Administrator', 'Настройки сайта изменены', 1386327157);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (772, 1, 'Administrator', 'Настройки сайта изменены', 1386327159);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (773, 1, 'Administrator', 'Настройки сайта изменены', 1386327225);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (774, 1, 'Administrator', 'Настройки сайта изменены', 1386327280);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (775, 1, 'Administrator', 'Настройки сайта изменены', 1386327280);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (776, 1, 'Administrator', 'Настройки сайта изменены', 1386327300);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (777, 1, 'Administrator', 'Настройки сайта изменены', 1386327301);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (778, 1, 'Administrator', 'Настройки сайта изменены', 1386327318);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (779, 1, 'Administrator', 'Настройки сайта изменены', 1386327319);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (780, 1, 'Administrator', 'Настройки сайта изменены', 1386333415);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (781, 1, 'Administrator', 'Настройки сайта изменены', 1386333416);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (782, 1, 'Administrator', 'Кэш очищен', 1386333427);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (783, 1, 'Administrator', 'Кэш очищен', 1386333428);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (784, 1, 'Administrator', 'Настройки сайта изменены', 1386333443);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (785, 1, 'Administrator', 'Настройки сайта изменены', 1386333445);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (786, 1, 'Administrator', 'Настройки сайта изменены', 1386333446);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (787, 1, 'Administrator', 'Настройки сайта изменены', 1386333447);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (788, 1, 'Administrator', 'Настройки сайта изменены', 1386333448);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (789, 1, 'Administrator', 'Настройки сайта изменены', 1386333456);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (790, 1, 'Administrator', 'Настройки сайта изменены', 1386333456);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (791, 1, 'Administrator', 'Настройки сайта изменены', 1386333465);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (792, 1, 'Administrator', 'Настройки сайта изменены', 1386333466);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (793, 1, 'Administrator', 'Настройки сайта изменены', 1386333466);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (794, 1, 'Administrator', 'Настройки сайта изменены', 1386333467);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (795, 1, 'Administrator', 'Настройки сайта изменены', 1386333468);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (796, 1, 'Administrator', 'Настройки сайта изменены', 1386333476);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (797, 1, 'Administrator', 'Настройки сайта изменены', 1386333477);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (798, 1, 'Administrator', 'Настройки сайта изменены', 1386333489);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (799, 1, 'Administrator', 'Настройки сайта изменены', 1386333490);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (800, 1, 'Administrator', 'Настройки сайта изменены', 1386333491);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (801, 1, 'Administrator', 'Настройки сайта изменены', 1386333491);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (802, 1, 'Administrator', 'Настройки сайта изменены', 1386333681);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (803, 1, 'Administrator', 'Настройки сайта изменены', 1386333681);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (804, 1, 'Administrator', 'Настройки сайта изменены', 1386333702);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (805, 1, 'Administrator', 'Настройки сайта изменены', 1386333703);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (806, 1, 'Administrator', 'Введен IP панели управления 193.93.14.168', 1386334225);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (807, 1, 'Administrator', 'Созданный  ', 1386334280);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (808, 48, '111', 'Введен IP панели управления 193.93.14.168', 1386334348);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (809, 48, '111', 'Настройки сайта изменены', 1386334521);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (810, 48, '111', 'Настройки сайта изменены', 1386334522);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (811, 48, '111', 'Кэш очищен', 1386334646);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (812, 48, '111', 'Кэш очищен', 1386334660);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (813, 48, '111', 'Кэш очищен', 1386335881);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (814, 48, '111', 'Кэш очищен', 1386335930);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (815, 48, '111', 'Введен IP панели управления 37.115.232.23', 1386337426);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (816, 48, '111', 'Настройки сайта изменены', 1386337680);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (817, 48, '111', 'Настройки сайта изменены', 1386337883);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (818, 48, '111', 'Настройки сайта изменены', 1386337960);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (819, 48, '111', 'Настройки сайта изменены', 1386338008);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (820, 48, '111', 'Настройки сайта изменены', 1386338072);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (821, 48, '111', 'Кэш очищен', 1386338296);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (822, 48, '111', 'Кэш очищен', 1386338420);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (823, 48, '111', 'Кэш очищен', 1386338519);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (824, 48, '111', 'Кэш очищен', 1386338665);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (825, 48, '111', 'Создать язык Украинский', 1386338899);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (826, 48, '111', 'Настройки сайта изменены', 1386339055);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (827, 48, '111', 'Кэш очищен', 1386339061);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (828, 48, '111', 'Настройки сайта изменены', 1386339077);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (829, 48, '111', 'Кэш очищен', 1386339213);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (830, 48, '111', 'Кэш очищен', 1386341348);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (831, 48, '111', 'Кэш очищен', 1386341743);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (832, 48, '111', 'Указажите язык Украинский по умолчанию', 1386341832);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (833, 48, '111', 'Указажите язык Русский по умолчанию', 1386341868);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (834, 48, '111', 'Кэш очищен', 1386342110);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (835, 48, '111', 'Кэш очищен', 1386402216);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (836, 48, '111', 'Настройки сайта изменены', 1386402477);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (837, 48, '111', 'Кэш очищен', 1386402482);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (838, 48, '111', 'Кэш очищен', 1386403565);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (839, 48, '111', 'Кэш очищен', 1386412044);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (840, 1, 'Administrator', 'Введен IP панели управления 193.93.14.168', 1386587535);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (841, 1, 'Administrator', 'Настройки сайта изменены', 1386587551);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (842, 1, 'Administrator', 'Кэш очищен', 1386587554);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (843, 1, 'Administrator', 'Кэш очищен', 1386587555);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (844, 1, 'Administrator', 'Настройки сайта изменены', 1386587569);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (845, 1, 'Administrator', 'Кэш очищен', 1386587571);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (846, 1, 'Administrator', 'Кэш очищен', 1386587571);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (847, 1, 'Administrator', 'Настройки сайта изменены', 1386587585);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (848, 1, 'Administrator', 'Указажите язык Украинский по умолчанию', 1386587590);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (849, 1, 'Administrator', 'Кэш очищен', 1386587598);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (850, 1, 'Administrator', 'Кэш очищен', 1386587599);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (851, 1, 'Administrator', 'Указажите язык Русский по умолчанию', 1386587612);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (852, 1, 'Administrator', 'Указажите язык Украинский по умолчанию', 1386587614);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (853, 1, 'Administrator', 'Язык изменен Украинский', 1386587633);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (854, 1, 'Administrator', 'Язык изменен Украинский', 1386587634);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (855, 1, 'Administrator', 'Язык изменен Украинский', 1386587635);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (856, 1, 'Administrator', 'Кэш очищен', 1386587637);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (857, 1, 'Administrator', 'Кэш очищен', 1386587638);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (858, 1, 'Administrator', 'Указажите язык Русский по умолчанию', 1386587647);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (859, 1, 'Administrator', 'Кэш очищен', 1386587649);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (860, 1, 'Administrator', 'Настройки сайта изменены', 1386587676);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (861, 48, '111', 'Кэш очищен', 1386588100);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (862, 48, '111', 'Кэш очищен', 1386588212);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (863, 48, '111', 'Кэш очищен', 1386588319);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (864, 48, '111', 'Кэш очищен', 1386588449);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (865, 48, '111', 'Кэш очищен', 1386589232);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (866, 48, '111', 'Кэш очищен', 1386589952);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (867, 48, '111', 'Кэш очищен', 1386590093);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (868, 48, '111', 'Кэш очищен', 1386590352);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (869, 48, '111', 'Введен IP панели управления 77.120.104.93', 1386759099);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (870, 48, '111', 'Кэш очищен', 1386759958);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (871, 48, '111', 'Кэш очищен', 1386760837);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (872, 48, '111', 'Кэш очищен', 1386761134);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (873, 48, '111', 'Кэш очищен', 1386761619);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (874, 48, '111', 'Кэш очищен', 1386762033);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (875, 48, '111', 'Кэш очищен', 1386762529);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (876, 48, '111', 'Кэш очищен', 1386763789);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (877, 48, '111', 'Кэш очищен', 1386782017);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (878, 48, '111', 'Кэш очищен', 1386782084);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (879, 48, '111', 'Кэш очищен', 1386782144);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (880, 48, '111', 'Кэш очищен', 1386782492);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (881, 48, '111', 'Кэш очищен', 1386782575);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (882, 48, '111', 'Кэш очищен', 1386783186);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (883, 48, '111', 'Кэш очищен', 1386783241);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (884, 48, '111', 'Кэш очищен', 1386783354);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (885, 48, '111', 'Кэш очищен', 1386783629);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (886, 48, '111', 'Кэш очищен', 1386784476);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (887, 48, '111', 'Кэш очищен', 1386785346);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (888, 48, '111', 'Кэш очищен', 1386785471);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (889, 48, '111', 'Кэш очищен', 1386786097);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (890, 48, '111', 'Кэш очищен', 1386787575);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (891, 48, '111', 'Кэш очищен', 1386800327);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (892, 48, '111', 'Кэш очищен', 1386801850);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (893, 48, '111', 'Кэш очищен', 1386829697);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (894, 48, '111', 'Кэш очищен', 1386839586);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (895, 48, '111', 'Кэш очищен', 1386936476);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (896, 48, '111', 'Кэш очищен', 1386939676);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (897, 48, '111', 'Кэш очищен', 1386945455);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (898, 48, '111', 'Кэш очищен', 1386946526);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (899, 48, '111', 'Кэш очищен', 1386946913);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (900, 48, '111', 'Кэш очищен', 1386958766);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (901, 48, '111', 'Кэш очищен', 1386960054);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (902, 48, '111', 'Кэш очищен', 1386960171);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (903, 48, '111', 'Кэш очищен', 1386962570);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (904, 48, '111', 'Кэш очищен', 1386962900);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (905, 48, '111', 'Кэш очищен', 1386962934);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (906, 48, '111', 'Кэш очищен', 1386964503);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (907, 48, '111', 'Кэш очищен', 1386965095);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (908, 48, '111', 'Кэш очищен', 1386965370);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (909, 48, '111', 'Настройки сайта изменены', 1386965680);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (910, 48, '111', 'Настройки сайта изменены', 1386965753);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (911, 48, '111', 'Кэш очищен', 1386965760);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (912, 48, '111', 'Кэш очищен', 1386965802);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (913, 48, '111', 'Кэш очищен', 1386966122);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (914, 48, '111', 'Кэш очищен', 1386966242);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (915, 48, '111', 'Кэш очищен', 1386966284);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (916, 48, '111', 'Кэш очищен', 1386966405);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (917, 48, '111', 'Кэш очищен', 1386967704);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (918, 48, '111', 'Кэш очищен', 1386968112);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (919, 48, '111', 'Кэш очищен', 1386968152);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (920, 48, '111', 'Кэш очищен', 1386968246);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (921, 48, '111', 'Введен IP панели управления 77.120.104.93', 1386970168);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (922, 48, '111', 'Кэш очищен', 1386970518);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (923, 48, '111', 'Кэш очищен', 1386970758);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (924, 48, '111', 'Кэш очищен', 1386971300);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (925, 48, '111', 'Кэш очищен', 1386971358);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (926, 48, '111', 'Кэш очищен', 1386971408);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (927, 48, '111', 'Кэш очищен', 1386971621);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (928, 48, '111', 'Введен IP панели управления 77.120.104.93', 1387015125);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (929, 48, '111', 'Кэш очищен', 1387015689);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (930, 48, '111', 'Кэш очищен', 1387015694);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (931, 48, '111', 'Кэш очищен', 1387031672);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (932, 48, '111', 'Кэш очищен', 1387034008);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (933, 48, '111', 'Кэш очищен', 1387043783);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (934, 48, '111', 'Кэш очищен', 1387045358);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (935, 48, '111', 'Кэш очищен', 1387048766);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (936, 48, '111', 'Кэш очищен', 1387095085);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (937, 48, '111', 'Кэш очищен', 1387095305);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (938, 48, '111', 'Кэш очищен', 1387095370);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (939, 48, '111', 'Кэш очищен', 1387139507);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (940, 48, '111', 'Кэш очищен', 1387141694);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (941, 48, '111', 'Кэш очищен', 1387141751);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (942, 48, '111', 'Кэш очищен', 1387142530);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (943, 48, '111', 'Введен IP панели управления 77.120.104.93', 1387306982);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (944, 48, '111', 'Введен IP панели управления 77.120.104.93', 1387362490);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (945, 48, '111', 'Кэш очищен', 1387362673);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (946, 48, '111', 'Кэш очищен', 1387381811);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (947, 48, '111', 'Кэш очищен', 1387381948);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (948, 48, '111', 'Кэш очищен', 1387383718);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (949, 48, '111', 'вышли с контрольной панели', 1387383926);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (950, 48, '111', 'Введен IP панели управления 77.120.104.93', 1387383942);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (951, 48, '111', 'Кэш очищен', 1387551104);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (952, 48, '111', 'Кэш очищен', 1387551219);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (953, 48, '111', 'Кэш очищен', 1387551369);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (954, 48, '111', 'Кэш очищен', 1387551463);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (955, 48, '111', 'Кэш очищен', 1387615208);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (956, 48, '111', 'Кэш очищен', 1387806203);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (957, 48, '111', 'Кэш очищен', 1387869698);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (958, 48, '111', 'Кэш очищен', 1387869811);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (959, 48, '111', 'Кэш очищен', 1387869978);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (960, 48, '111', 'Кэш очищен', 1387870880);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (961, 48, '111', 'Кэш очищен', 1387896985);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (962, 48, '111', 'Кэш очищен', 1387955148);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (963, 48, '111', 'Кэш очищен', 1388048620);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (964, 48, '111', 'Кэш очищен', 1388124964);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (965, 48, '111', 'Кэш очищен', 1388346583);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (966, 48, '111', 'Кэш очищен', 1388346794);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (967, 48, '111', 'Кэш очищен', 1388351091);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (968, 48, '111', 'Кэш очищен', 1388352411);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (969, 48, '111', 'Кэш очищен', 1388352445);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (970, 48, '111', 'Кэш очищен', 1388352652);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (971, 48, '111', 'Кэш очищен', 1388352843);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (972, 48, '111', 'Кэш очищен', 1388353200);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (973, 48, '111', 'Кэш очищен', 1388400945);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (974, 48, '111', 'Кэш очищен', 1388577877);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (975, 48, '111', 'Кэш очищен', 1390217036);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (976, 48, '111', 'Кэш очищен', 1390217039);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (977, 48, '111', 'Кэш очищен', 1390220683);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (978, 48, '111', 'Кэш очищен', 1390220796);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (979, 48, '111', 'Кэш очищен', 1390221066);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (980, 48, '111', 'Кэш очищен', 1390294282);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (981, 48, '111', 'Кэш очищен', 1390383390);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (982, 1, 'Administrator', 'Кэш очищен', 1390384242);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (983, 1, 'Administrator', 'Кэш очищен', 1390384242);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (984, 1, 'Administrator', 'Кэш очищен', 1390384701);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (985, 1, 'Administrator', 'Модуль установлен translator', 1390384718);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (986, 1, 'Administrator', 'Модуль установлен sample_module', 1390384722);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (987, 1, 'Administrator', 'Модуль установлен socauth', 1390384725);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (988, 1, 'Administrator', 'Кэш очищен', 1390385023);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (989, 1, 'Administrator', 'Кэш очищен', 1390385056);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (990, 1, 'Administrator', 'Настройки сайта изменены', 1390385217);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (991, 1, 'Administrator', 'Настройки сайта изменены', 1390385237);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (992, 1, 'Administrator', 'Кэш очищен', 1390385247);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (993, 1, 'Administrator', 'Настройки сайта изменены', 1390385271);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (994, 1, 'Administrator', 'Страница изменена <a href=\"http://inpromservice.com.ua/admin/pages/edit/64\">О магазине</a>', 1390385295);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (995, 1, 'Administrator', 'Язык изменен Украинский', 1390385534);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (996, 1, 'Administrator', 'Виджет удален benefits', 1390385990);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (997, 1, 'Administrator', 'Введен IP панели управления 193.93.14.168', 1390389059);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (998, 1, 'Administrator', 'Сиджетов создан langswitcher', 1390393480);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (999, 1, 'Administrator', 'Кэш очищен', 1390394936);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1000, 1, 'Administrator', 'Кэш очищен', 1390395434);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1001, 1, 'Administrator', 'Кэш очищен', 1390396300);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1002, 48, '111', 'Кэш очищен', 1390463161);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1003, 1, 'Administrator', 'Язык изменен Украинс', 1390465681);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1004, 1, 'Administrator', 'Язык изменен Русский', 1390465699);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1005, 1, 'Administrator', 'Язык изменен Украинский', 1390465725);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1006, 1, 'Administrator', 'Язык изменен Русский', 1390465731);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1007, 1, 'Administrator', 'Язык изменен Украинский', 1390465896);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1008, 1, 'Administrator', 'Язык изменен Русский', 1390465911);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1009, 1, 'Administrator', 'Язык изменен Англиский', 1390465918);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1010, 1, 'Administrator', 'Виджет удален langswitcher', 1390465970);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1011, 1, 'Administrator', 'Кэш очищен', 1390467797);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1012, 1, 'Administrator', 'Кэш очищен', 1390467953);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1013, 1, 'Administrator', 'Кэш очищен', 1390467984);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1014, 1, 'Administrator', 'Кэш очищен', 1390468055);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1015, 1, 'Administrator', 'Кэш очищен', 1390468110);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1016, 1, 'Administrator', 'Кэш очищен', 1390468144);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1017, 1, 'Administrator', 'Кэш очищен', 1390468226);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1018, 1, 'Administrator', 'Кэш очищен', 1390468295);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1019, 1, 'Administrator', 'Кэш очищен', 1390468332);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1020, 1, 'Administrator', 'Кэш очищен', 1390468455);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1021, 1, 'Administrator', 'Кэш очищен', 1390468609);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1022, 1, 'Administrator', 'Кэш очищен', 1390468665);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1023, 1, 'Administrator', 'Кэш очищен', 1390468719);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1024, 1, 'Administrator', 'Введен IP панели управления 193.93.14.168', 1390471464);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1025, 1, 'Administrator', 'Кэш очищен', 1390474766);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1026, 1, 'Administrator', 'Язык изменен Украинский', 1390475788);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1027, 1, 'Administrator', 'Кэш очищен', 1390479271);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1028, 1, 'Administrator', 'Кэш очищен', 1390480155);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1029, 1, 'Administrator', 'Кэш очищен', 1390482289);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1030, 1, 'Administrator', 'Категория изменена <a href=\"/admin/categories/edit/69\"> Новини</a>', 1390482335);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1031, 1, 'Administrator', 'Страница изменена <a href=\"http://www.inpromservice.com.ua/admin/pages/edit/35\">Про сайт</a>', 1390482384);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1032, 1, 'Administrator', 'Страница изменена <a href=\"http://www.inpromservice.com.ua/admin/pages/edit/64\">Про магазин</a>', 1390482396);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1033, 1, 'Administrator', 'Страница изменена <a href=\"http://www.inpromservice.com.ua/admin/pages/edit/67\">Допомога</a>', 1390482411);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1034, 1, 'Administrator', 'Страница изменена <a href=\"http://www.inpromservice.com.ua/admin/pages/edit/68\">Контакти</a>', 1390482429);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1035, 1, 'Administrator', 'Кэш очищен', 1390482478);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1036, 1, 'Administrator', 'Кэш очищен', 1390483216);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1037, 1, 'Administrator', 'Кэш очищен', 1390483294);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1038, 1, 'Administrator', 'Кэш очищен', 1390483309);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1039, 1, 'Administrator', 'Кэш очищен', 1390483703);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1040, 1, 'Administrator', 'Язык изменен Русский', 1390483943);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1041, 1, 'Administrator', 'Кэш очищен', 1390483954);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1042, 1, 'Administrator', 'Кэш очищен', 1390484002);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1043, 1, 'Administrator', 'Создать язык Украинский', 1390484126);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1044, 1, 'Administrator', 'Указажите язык Украинский по умолчанию', 1390484140);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1045, 1, 'Administrator', 'Указажите язык Русский по умолчанию', 1390484295);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1046, 1, 'Administrator', 'Указажите язык Украинский по умолчанию', 1390487560);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1047, 1, 'Administrator', 'Указажите язык Русский по умолчанию', 1390487561);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1048, 1, 'Administrator', 'Кэш очищен', 1390487574);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1049, 1, 'Administrator', 'Кэш очищен', 1390487737);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1050, 1, 'Administrator', 'Язык изменен Русский', 1390487838);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1051, 1, 'Administrator', 'Кэш очищен', 1390487850);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1052, 1, 'Administrator', 'Язык изменен Русский', 1390487894);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1053, 1, 'Administrator', 'Указажите язык Украинский по умолчанию', 1390487951);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1054, 1, 'Administrator', 'Кэш очищен', 1390487954);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1055, 1, 'Administrator', 'Указажите язык Русский по умолчанию', 1390487967);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1056, 1, 'Administrator', 'Язык изменен Русский', 1390487978);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1057, 1, 'Administrator', 'Язык изменен Русский', 1390488003);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1058, 1, 'Administrator', 'Кэш очищен', 1390488018);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1059, 1, 'Administrator', 'Язык изменен Русский', 1390488034);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1060, 1, 'Administrator', 'Кэш очищен', 1390488037);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1061, 1, 'Administrator', 'Язык изменен Русский', 1390488083);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1062, 1, 'Administrator', 'Кэш очищен', 1390488123);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1063, 1, 'Administrator', 'Кэш очищен', 1390488599);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1064, 1, 'Administrator', 'Кэш очищен', 1390489020);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1065, 1, 'Administrator', 'Кэш очищен', 1390489062);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1066, 1, 'Administrator', 'Кэш очищен', 1390489088);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1067, 1, 'Administrator', 'Кэш очищен', 1390549223);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1068, 48, '111', 'Кэш очищен', 1390567513);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1069, 48, '111', 'Кэш очищен', 1390567592);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1070, 48, '111', 'Кэш очищен', 1390568047);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1071, 48, '111', 'Кэш очищен', 1390568535);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1072, 48, '111', 'Кэш очищен', 1390568707);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1073, 48, '111', 'Кэш очищен', 1390568778);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1074, 48, '111', 'Кэш очищен', 1390568873);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1075, 48, '111', 'Кэш очищен', 1390568905);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1076, 48, '111', 'Кэш очищен', 1390568999);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1077, 48, '111', 'Кэш очищен', 1390570139);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1078, 48, '111', 'Кэш очищен', 1390572962);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1079, 48, '111', 'Кэш очищен', 1390573180);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1080, 48, '111', 'Кэш очищен', 1390587021);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1081, 48, '111', 'Кэш очищен', 1390587729);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1082, 48, '111', 'Кэш очищен', 1390588444);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1083, 48, '111', 'Кэш очищен', 1390588555);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1084, 48, '111', 'Кэш очищен', 1390591503);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1085, 48, '111', 'Кэш очищен', 1390592062);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1086, 48, '111', 'Кэш очищен', 1390592254);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1087, 48, '111', 'Введен IP панели управления 37.229.234.69', 1390847860);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1088, 48, '111', 'Кэш очищен', 1390848173);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1089, 48, '111', 'Кэш очищен', 1390849494);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1090, 48, '111', 'Кэш очищен', 1390850340);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1091, 48, '111', 'Кэш очищен', 1390850430);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1092, 48, '111', 'Введен IP панели управления 37.115.234.179', 1390908943);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1093, 48, '111', 'Кэш очищен', 1390909027);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1094, 48, '111', 'Виджет изменен ', 1392214379);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1095, 48, '111', 'Страница изменена <a href=\"http://www.inpromservice.com.ua/admin/pages/edit/64\">Про фірму</a>', 1392214549);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1096, 48, '111', 'Кэш очищен', 1392214553);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1097, 48, '111', 'Страница изменена <a href=\"http://www.inpromservice.com.ua/admin/pages/edit/68\">Контакти</a>', 1392215094);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1098, 48, '111', 'Кэш очищен', 1392215099);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1099, 48, '111', 'Страница изменена <a href=\"http://www.inpromservice.com.ua/admin/pages/edit/68\">Контакти</a>', 1392215246);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1100, 48, '111', 'Кэш очищен', 1392215385);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1101, 48, '111', 'Кэш очищен', 1392215395);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1102, 48, '111', 'Кэш очищен', 1392215474);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1103, 48, '111', 'Кэш очищен', 1392377430);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1104, 48, '111', 'Кэш очищен', 1392456169);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1105, 48, '111', 'Страница изменена <a href=\"http://www.inpromservice.com.ua/admin/pages/edit/66\">Доставка</a>', 1392456347);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1106, 48, '111', 'Кэш очищен', 1392456359);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1107, 48, '111', 'Страница изменена <a href=\"http://www.inpromservice.com.ua/admin/pages/edit/66\">Доставка</a>', 1392456392);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1108, 48, '111', 'Страница изменена <a href=\"http://www.inpromservice.com.ua/admin/pages/edit/67\">Допомога</a>', 1392456534);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1109, 48, '111', 'Кэш очищен', 1392456539);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1110, 48, '111', 'Категория изменена <a href=\"/admin/categories/edit/70\"> Останні новини</a>', 1392456760);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1111, 48, '111', 'Категория изменена <a href=\"/admin/categories/edit/71\"> Архів</a>', 1392456771);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1112, 48, '111', 'Кэш очищен', 1392456785);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1113, 48, '111', 'Кэш очищен', 1392456843);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1114, 48, '111', 'Страница изменена <a href=\"http://www.inpromservice.com.ua/admin/pages/edit/65\">Оплата</a>', 1392457172);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1115, 48, '111', 'Кэш очищен', 1392457876);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1116, 48, '111', 'Введен IP панели управления 37.229.233.216', 1392623106);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1117, 1, 'Administrator', 'Введен IP панели управления 93.78.126.221', 1396535461);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1118, 1, 'Administrator', 'Кэш очищен', 1396535536);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1119, 1, 'Administrator', 'Введен IP панели управления 176.113.209.17', 1409390155);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1120, 1, 'Administrator', 'Магазин - Изменения сохранены<a href=\"http://inpromservice.com.ua/admin/components/run/shop/users/edit/1\">Administrator</a>', 1409390176);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1121, 48, '111', 'Кэш очищен', 1409649647);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1122, 48, '111', 'Кэш очищен', 1409650833);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1123, 48, '111', 'Кэш очищен', 1409651259);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1124, 48, '111', 'Кэш очищен', 1409653021);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1125, 48, '111', 'Кэш очищен', 1409653171);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1126, 48, '111', 'Кэш очищен', 1409653415);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1127, 48, '111', 'Кэш очищен', 1409653749);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1128, 48, '111', 'Кэш очищен', 1409654193);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1129, 48, '111', 'Кэш очищен', 1409654317);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1130, 48, '111', 'Кэш очищен', 1409654811);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1131, 48, '111', 'Кэш очищен', 1409657136);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1132, 48, '111', 'Кэш очищен', 1409657924);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1133, 48, '111', 'Введен IP панели управления 46.211.225.65', 1425544312);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1134, 48, '111', 'Магазин - Изменения сохранены<a href=\"http://inpromservice.com.ua/admin/components/run/shop/users/edit/48\">admin</a>', 1427530072);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1135, 48, 'admin', 'Магазин - Изменения сохранены<a href=\"http://inpromservice.com.ua/admin/components/run/shop/users/edit/48\">admin</a>', 1427530080);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1136, 48, 'admin', 'Магазин - Изменения сохранены<a href=\"http://inpromservice.com.ua/admin/components/run/shop/users/edit/48\">admin</a>', 1427530121);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1137, 48, 'admin', 'Созданный ', 1427530395);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1138, 49, 'Igor', 'Введен IP панели управления 178.137.159.179', 1427530519);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1139, 1, 'Administrator', 'Введен IP панели управления 176.113.209.17', 1429799151);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1140, 1, 'Administrator', 'Страница изменена <a href=\"http://inpromservice.com.ua/admin/pages/edit/68\">Контакти</a>', 1429799233);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1141, 1, 'Administrator', 'Страница изменена <a href=\"http://inpromservice.com.ua/admin/pages/edit/68\">Контакти</a>', 1429799293);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1142, 1, 'Administrator', 'Кэш очищен', 1429799297);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1143, 1, 'Administrator', 'Страница изменена <a href=\"http://inpromservice.com.ua/admin/pages/edit/68\">Контакти</a>', 1429799317);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1144, 1, 'Administrator', 'Страница изменена <a href=\"http://inpromservice.com.ua/admin/pages/edit/68\">Контакти</a>', 1429799345);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1145, 1, 'Administrator', 'Кэш очищен', 1429799523);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1146, 1, 'Administrator', 'Кэш очищен', 1429799575);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1147, 1, 'Administrator', 'Кэш очищен', 1429799604);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1148, 1, 'Administrator', 'Кэш очищен', 1429799609);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1149, 1, 'Administrator', 'Кэш очищен', 1429799633);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1150, 49, 'Igor', 'Введен IP панели управления 5.248.181.80', 1429858436);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1151, 49, 'Igor', 'Магазин - Изменения сохранены<a href=\"http://www.inpromservice.com.ua/admin/components/run/shop/users/edit/49\">Igor</a>', 1429859270);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1152, 49, 'Igor', 'Введен IP панели управления 5.248.181.80', 1429876738);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1153, 49, 'Igor', 'Введен IP панели управления 37.229.229.135', 1430132041);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1154, 49, 'Igor', 'Введен IP панели управления 176.8.215.116', 1430201212);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1155, 49, 'Igor', 'Кэш очищен', 1430201343);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1156, 49, 'Igor', 'Кэш очищен', 1430201362);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1157, 49, 'Igor', 'Кэш очищен', 1430201477);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1158, 49, 'Igor', 'Кэш очищен', 1430202999);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1159, 49, 'Igor', 'Кэш очищен', 1430203208);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1160, 49, 'Igor', 'Кэш очищен', 1430203217);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1161, 49, 'Igor', 'Кэш очищен', 1430203379);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1162, 49, 'Igor', 'Кэш очищен', 1430203747);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1163, 49, 'Igor', 'Кэш очищен', 1430203810);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1164, 49, 'Igor', 'Кэш очищен', 1430203931);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1165, 49, 'Igor', 'Кэш очищен', 1430203987);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1166, 49, 'Igor', 'Кэш очищен', 1430204086);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1167, 49, 'Igor', 'Кэш очищен', 1430204267);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1168, 49, 'Igor', 'Кэш очищен', 1430204604);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1169, 49, 'Igor', 'вышли с контрольной панели', 1430207974);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1170, 49, 'Igor', 'Введен IP панели управления 176.8.215.116', 1430207994);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1171, 49, 'Igor', 'Кэш очищен', 1430221496);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1172, 49, 'Igor', 'Кэш очищен', 1430300247);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1173, 49, 'Igor', 'Кэш очищен', 1430300321);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1174, 49, 'Igor', 'Кэш очищен', 1430300405);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1175, 49, 'Igor', 'Кэш очищен', 1434549476);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1176, 1, 'Administrator', 'Введен IP панели управления 178.92.98.152', 1435493334);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1177, 1, 'Administrator', 'Настройки сайта изменены', 1435493354);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1178, 1, 'Administrator', 'Настройки сайта изменены', 1435493390);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1179, 1, 'Administrator', 'Настройки сайта изменены', 1435493625);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1180, 1, 'Administrator', 'Виджет изменен ', 1435493729);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1181, 1, 'Administrator', 'Настройки сайта изменены', 1435494900);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1182, 1, 'Administrator', 'Настройки сайта изменены', 1435495006);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1183, 1, 'Administrator', 'Настройки сайта изменены', 1435495012);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1184, 1, 'Administrator', 'Настройки сайта изменены', 1435495360);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1185, 1, 'Administrator', 'Настройки сайта изменены', 1435495415);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1186, 1, 'Administrator', 'Кэш очищен', 1435495420);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1187, 1, 'Administrator', 'Введен IP панели управления 91.219.223.86', 1437732145);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1188, 1, 'Administrator', 'Кэш очищен', 1437732152);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1189, 1, 'Administrator', 'Настройки сайта изменены', 1437732363);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1190, 1, 'Administrator', 'Кэш очищен', 1437732366);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1191, 1, 'Administrator', 'Настройки сайта изменены', 1437732462);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1192, 49, 'Igor', 'Кэш очищен', 1454067726);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1193, 49, 'Igor', 'Кэш очищен', 1454076270);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1194, 49, 'Igor', 'Введен IP панели управления 37.229.229.101', 1454144453);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1195, 49, 'Igor', 'Настройки сайта изменены', 1454144532);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1196, 49, 'Igor', 'Кэш очищен', 1454144552);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1197, 49, 'Igor', 'Кэш очищен', 1454575790);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1198, 49, 'Igor', 'Кэш очищен', 1455090189);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1199, 49, 'Igor', 'Созданный ', 1456491565);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1200, 49, 'Igor', 'Кэш очищен', 1456491816);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1201, 49, 'Igor', 'Магазин - Изменения сохранены<a href=\"http://www.inpromservice.com.ua/admin/components/run/shop/users/edit/51\">Админ</a>', 1456491838);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1202, 49, 'Igor', 'Кэш очищен', 1456491844);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1203, 49, 'Igor', 'вышли с контрольной панели', 1456493256);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1204, 49, 'Igor', 'Кэш очищен', 1457702021);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1205, 49, 'Igor', 'Кэш очищен', 1457702059);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1206, 1, 'Administrator', 'Введен IP панели управления 37.57.177.192', 1457707210);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1207, 1, 'Administrator', 'Магазин - Изменения сохранены<a href=\"http://inpromservice.com.ua/admin/components/run/shop/users/edit/49\">Igor</a>', 1457707232);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1208, 1, 'Administrator', 'Магазин - Изменения сохранены<a href=\"http://inpromservice.com.ua/admin/components/run/shop/users/edit/52\">inpromservice</a>', 1457708110);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1209, 52, 'inpromservice', 'Введен IP панели управления 176.8.215.172', 1457763151);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1210, 52, 'inpromservice', 'Кэш очищен', 1458030040);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1211, 52, 'inpromservice', 'Введен IP панели управления 37.229.227.113', 1458108693);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1212, 52, 'inpromservice', 'Указажите язык Украинский по умолчанию', 1458116313);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1213, 52, 'inpromservice', 'Указажите язык Русский по умолчанию', 1458116464);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1214, 52, 'inpromservice', 'Указажите язык Англиский по умолчанию', 1458116779);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1215, 52, 'inpromservice', 'Указажите язык Украинский по умолчанию', 1458116789);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1216, 52, 'inpromservice', 'Указажите язык Русский по умолчанию', 1458116791);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1217, 52, 'inpromservice', 'Указажите язык Украинский по умолчанию', 1458116805);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1218, 52, 'inpromservice', 'Указажите язык Русский по умолчанию', 1458116826);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1219, 52, 'inpromservice', 'Кэш очищен', 1458120950);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1220, 52, 'inpromservice', 'Кэш очищен', 1458121278);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1221, 52, 'inpromservice', 'Кэш очищен', 1458121323);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1222, 52, 'inpromservice', 'Кэш очищен', 1458121348);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1223, 52, 'inpromservice', 'Кэш очищен', 1458121445);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1224, 52, 'inpromservice', 'Кэш очищен', 1458121587);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1225, 52, 'inpromservice', 'Кэш очищен', 1458121667);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1226, 52, 'inpromservice', 'Кэш очищен', 1458121981);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1227, 52, 'inpromservice', 'Кэш очищен', 1458122034);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1228, 52, 'inpromservice', 'Кэш очищен', 1458123725);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1229, 52, 'inpromservice', 'Кэш очищен', 1458123955);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1230, 52, 'inpromservice', 'Кэш очищен', 1458124016);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1231, 52, 'inpromservice', 'Кэш очищен', 1458124324);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1232, 52, 'inpromservice', 'Кэш очищен', 1458125901);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1233, 52, 'inpromservice', 'Кэш очищен', 1458126145);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (1234, 52, 'inpromservice', 'Кэш очищен', 1458217651);


#
# TABLE STRUCTURE FOR: mail
#

DROP TABLE IF EXISTS mail;

CREATE TABLE `mail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `date` int(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: menu_translate
#

DROP TABLE IF EXISTS menu_translate;

CREATE TABLE `menu_translate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `lang_id` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`),
  KEY `lang_id` (`lang_id`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (32, 8, 30, 'Home');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (31, 8, 3, 'Главная');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (6, 9, 30, 'About');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (5, 9, 3, 'О Магазине');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (7, 13, 3, 'Контакты');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (8, 13, 30, 'Contacts');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (11, 10, 3, 'Оплата');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (12, 10, 30, 'Delivery');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (15, 12, 3, 'Помощь');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (16, 12, 30, 'Help');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (17, 14, 3, 'Главная');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (18, 14, 30, 'Home');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (19, 15, 3, 'О магазине');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (20, 15, 30, 'About');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (21, 16, 3, 'Доставка');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (22, 16, 30, 'Delivery');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (23, 17, 3, 'Помощь');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (24, 17, 30, 'Help');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (25, 18, 3, 'Контакты');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (26, 18, 30, 'Contacts');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (29, 19, 3, 'Главная');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (30, 19, 30, 'Home');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (33, 20, 3, 'Видео');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (34, 20, 30, 'Video');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (36, 21, 3, 'О магазине');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (37, 21, 30, 'About');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (38, 22, 3, 'Домашнее аудио');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (39, 22, 30, 'Home music');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (40, 23, 3, 'Доставка и оплата');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (41, 23, 30, 'Delivery');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (42, 24, 3, 'Фото и камеры');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (43, 24, 30, 'Photo and Camera');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (44, 25, 3, 'Помощь');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (45, 25, 30, 'Help');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (46, 26, 3, 'Домашняя электроника');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (47, 26, 30, 'Home Electronics');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (48, 27, 3, 'Контакты');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (49, 27, 30, 'Contacts');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (50, 28, 3, 'Авто музыка и видео');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (51, 28, 30, 'Auto Tabs');


#
# TABLE STRUCTURE FOR: menus
#

DROP TABLE IF EXISTS menus;

CREATE TABLE `menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `main_title` varchar(300) NOT NULL,
  `tpl` varchar(255) DEFAULT NULL,
  `expand_level` int(255) DEFAULT NULL,
  `description` text,
  `created` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO menus (`id`, `name`, `main_title`, `tpl`, `expand_level`, `description`, `created`) VALUES (1, 'main_menu', 'Главное меню', 'shop_menu', 0, 'Главное меню шаблона', '2012-02-07 15:34:41');
INSERT INTO menus (`id`, `name`, `main_title`, `tpl`, `expand_level`, `description`, `created`) VALUES (4, 'top_menu', 'Top menu', 'top_menu', 0, 'Меню в верхней части шаблона', '2012-05-11 14:53:24');
INSERT INTO menus (`id`, `name`, `main_title`, `tpl`, `expand_level`, `description`, `created`) VALUES (5, 'footer_menu', 'Footer menu', 'footer_menu', 0, 'Нижнее меню шаблона', '2012-05-25 11:43:06');
INSERT INTO menus (`id`, `name`, `main_title`, `tpl`, `expand_level`, `description`, `created`) VALUES (11, 'left_menu', 'left_menu', 'left_menu', 1, 'Меню в левой части шаблона', '2013-03-18 16:13:38');
INSERT INTO menus (`id`, `name`, `main_title`, `tpl`, `expand_level`, `description`, `created`) VALUES (12, 'footer_menu_mobile', 'footer_menu_mobile', '', 0, 'Меню нижней части мобильной версии', '2013-09-19 17:42:17');


#
# TABLE STRUCTURE FOR: menus_data
#

DROP TABLE IF EXISTS menus_data;

CREATE TABLE `menus_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(9) NOT NULL,
  `item_id` int(9) NOT NULL,
  `item_type` varchar(15) NOT NULL,
  `item_image` varchar(255) DEFAULT NULL,
  `roles` text,
  `hidden` smallint(1) NOT NULL DEFAULT '0',
  `title` varchar(300) NOT NULL,
  `parent_id` int(9) NOT NULL,
  `position` smallint(5) DEFAULT NULL,
  `description` text,
  `add_data` text,
  PRIMARY KEY (`id`),
  KEY `menu_id` (`menu_id`),
  KEY `position` (`position`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;

INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (10, 1, 0, 'url', NULL, '', 0, 'Сервіс', 0, 4, NULL, 'a:2:{s:3:\"url\";s:8:\"/service\";s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (8, 1, 0, 'url', NULL, '', 0, 'Головна', 0, 1, NULL, 'a:2:{s:3:\"url\";s:1:\"/\";s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (9, 1, 64, 'category', NULL, '', 0, 'Про фірму', 0, 3, NULL, 'N;');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (11, 1, 0, 'url', NULL, '', 0, 'Доставка та оплата', 0, 5, NULL, 'a:2:{s:3:\"url\";s:9:\"/dostavka\";s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (12, 1, 0, 'url', NULL, '', 0, 'Допомога', 0, 6, NULL, 'a:2:{s:3:\"url\";s:5:\"/help\";s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (13, 1, 0, 'url', NULL, '', 0, 'Контакти', 0, 7, NULL, 'a:2:{s:3:\"url\";s:11:\"/contact_us\";s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (14, 4, 0, 'url', NULL, '', 0, 'Головна', 0, 2, NULL, 'a:2:{s:3:\"url\";s:1:\"/\";s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (15, 4, 64, 'page', NULL, '', 0, 'Про магазин', 0, 5, NULL, 'a:2:{s:4:\"page\";N;s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (16, 4, 66, 'category', NULL, '', 1, 'Доставка', 0, 1, NULL, 'N;');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (17, 4, 0, 'url', NULL, '', 1, 'Допомога', 0, 4, NULL, 'a:2:{s:3:\"url\";s:8:\"dopomoga\";s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (18, 4, 0, 'url', NULL, '', 0, 'Контакти', 0, 6, NULL, 'a:2:{s:3:\"url\";s:8:\"kontakti\";s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (19, 5, 0, 'url', '', '', 0, 'Главная', 0, 1, NULL, 'a:2:{s:3:\"url\";s:1:\"/\";s:7:\"newpage\";s:1:\"0\";}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (20, 5, 0, 'url', '', '', 0, 'Видео', 0, 2, NULL, 'a:2:{s:3:\"url\";s:20:\"/shop/category/video\";s:7:\"newpage\";s:1:\"0\";}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (21, 5, 64, 'page', '', '', 0, 'О магазине', 0, 3, NULL, 'a:1:{s:7:\"newpage\";s:1:\"0\";}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (22, 5, 0, 'url', '', '', 0, 'Домашнее  аудио', 0, 4, NULL, 'a:2:{s:3:\"url\";s:30:\"/shop/category/domashnee_audio\";s:7:\"newpage\";s:1:\"0\";}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (23, 5, 66, 'page', '', '', 0, 'Доставка и оплата', 0, 5, NULL, 'a:1:{s:7:\"newpage\";s:1:\"0\";}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (24, 5, 0, 'url', '', '', 0, 'Фото и камеры', 0, 6, NULL, 'a:2:{s:3:\"url\";s:28:\"/shop/category/foto_i_kamery\";s:7:\"newpage\";s:1:\"0\";}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (25, 5, 67, 'page', '', '', 0, 'Помощь', 0, 7, NULL, 'a:1:{s:7:\"newpage\";s:1:\"0\";}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (26, 5, 0, 'url', '', '', 0, 'Домашняя электроника', 0, 8, NULL, 'a:2:{s:3:\"url\";s:38:\"/shop/category/domashniaia_elektronika\";s:7:\"newpage\";s:1:\"0\";}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (27, 5, 68, 'page', '', '', 0, 'Контакты', 0, 9, NULL, 'a:1:{s:7:\"newpage\";s:1:\"0\";}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (28, 5, 0, 'url', '', '', 0, 'Авто музыка и видео', 0, 10, NULL, 'a:2:{s:3:\"url\";s:34:\"/shop/category/avto_muzyka_i_video\";s:7:\"newpage\";s:1:\"0\";}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (37, 11, 69, 'category', NULL, '', 0, 'Новости', 0, 2, NULL, 'N;');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (38, 11, 70, 'category', NULL, '', 0, 'Последние новости', 37, 1, NULL, 'a:1:{s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (39, 11, 71, 'category', NULL, '', 0, 'Архив', 37, 2, NULL, 'a:1:{s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (40, 4, 0, 'url', NULL, '', 1, 'Новини', 0, 3, NULL, 'a:2:{s:3:\"url\";s:7:\"novosti\";s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (41, 11, 64, 'page', NULL, 'a:1:{i:0;s:1:\"0\";}', 0, 'О магазине', 0, 6, NULL, 'a:2:{s:4:\"page\";N;s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (42, 11, 66, 'page', NULL, '', 0, 'Доставка', 0, 3, NULL, 'a:1:{s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (43, 11, 67, 'page', NULL, '', 0, 'Помощь', 0, 4, NULL, 'a:1:{s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (44, 12, 67, 'page', '', '', 0, 'Помощь', 0, 2, NULL, 'a:1:{s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (45, 12, 65, 'page', '', '', 0, 'Оплата', 0, 3, NULL, 'a:1:{s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (46, 12, 35, 'page', '', '', 0, 'О сайте', 0, 4, NULL, 'a:1:{s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (47, 12, 66, 'page', '', '', 0, 'Доставка', 0, 5, NULL, 'a:1:{s:7:\"newpage\";i:0;}');


#
# TABLE STRUCTURE FOR: mod_banner
#

DROP TABLE IF EXISTS mod_banner;

CREATE TABLE `mod_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active` tinyint(4) NOT NULL,
  `active_to` int(11) DEFAULT NULL,
  `where_show` text,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO mod_banner (`id`, `active`, `active_to`, `where_show`, `position`) VALUES (2, 1, 1572386400, 'a:0:{}', 1);
INSERT INTO mod_banner (`id`, `active`, `active_to`, `where_show`, `position`) VALUES (3, 1, 1564693200, 'a:0:{}', 2);
INSERT INTO mod_banner (`id`, `active`, `active_to`, `where_show`, `position`) VALUES (5, 1, 1451599200, 'a:0:{}', 0);
INSERT INTO mod_banner (`id`, `active`, `active_to`, `where_show`, `position`) VALUES (6, 1, 1451599200, 'a:0:{}', 0);
INSERT INTO mod_banner (`id`, `active`, `active_to`, `where_show`, `position`) VALUES (7, 1, 1398373200, 'a:0:{}', 0);
INSERT INTO mod_banner (`id`, `active`, `active_to`, `where_show`, `position`) VALUES (8, 1, 1396044000, 'a:0:{}', 1);
INSERT INTO mod_banner (`id`, `active`, `active_to`, `where_show`, `position`) VALUES (9, 1, 1393624800, 'N;', 2);
INSERT INTO mod_banner (`id`, `active`, `active_to`, `where_show`, `position`) VALUES (10, 1, 1451599200, 'a:0:{}', 0);
INSERT INTO mod_banner (`id`, `active`, `active_to`, `where_show`, `position`) VALUES (11, 1, 1458165600, 'a:0:{}', 0);


#
# TABLE STRUCTURE FOR: mod_banner_i18n
#

DROP TABLE IF EXISTS mod_banner_i18n;

CREATE TABLE `mod_banner_i18n` (
  `id` int(11) NOT NULL,
  `url` text,
  `locale` varchar(5) NOT NULL,
  `name` varchar(25) DEFAULT NULL,
  `description` text,
  `photo` varchar(255) DEFAULT NULL,
  KEY `id` (`id`,`locale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO mod_banner_i18n (`id`, `url`, `locale`, `name`, `description`, `photo`) VALUES (2, '', 'ru', 'РРО MINI Т51.01', '', '/uploads/gallery/390.jpg');
INSERT INTO mod_banner_i18n (`id`, `url`, `locale`, `name`, `description`, `photo`) VALUES (3, '', 'ru', 'РРО Марія 304Т', '', '/uploads/304.jpg');
INSERT INTO mod_banner_i18n (`id`, `url`, `locale`, `name`, `description`, `photo`) VALUES (5, '', 'ru', 'РРО MINI T400 з КСЕФ', '<p>Текст банера здесь</p>', '/uploads/T400.jpg');
INSERT INTO mod_banner_i18n (`id`, `url`, `locale`, `name`, `description`, `photo`) VALUES (5, '', 'ukr', '', '', '');
INSERT INTO mod_banner_i18n (`id`, `url`, `locale`, `name`, `description`, `photo`) VALUES (6, '', 'ru', 'РРО ІКС-Е810Т', '', '/uploads/ИКС810.jpg');
INSERT INTO mod_banner_i18n (`id`, `url`, `locale`, `name`, `description`, `photo`) VALUES (6, '', 'ukr', '', '', '');
INSERT INTO mod_banner_i18n (`id`, `url`, `locale`, `name`, `description`, `photo`) VALUES (7, '', 'ua', 'Lenovo', '<p>Lenovo IdeaPad S110 Black Суперцена</p>', '/uploads/mPOS.jpg');
INSERT INTO mod_banner_i18n (`id`, `url`, `locale`, `name`, `description`, `photo`) VALUES (8, '', 'ua', 'Web cam', '<p>Веб-камера Genious 010011</p>', '/uploads/datalogic_1100i.jpg');
INSERT INTO mod_banner_i18n (`id`, `url`, `locale`, `name`, `description`, `photo`) VALUES (9, '', 'ua', 'Електронний рахувач', '<p>Електронний рахувач 1000m</p>', '/uploads/NEON_grey_550x550_001.jpg');
INSERT INTO mod_banner_i18n (`id`, `url`, `locale`, `name`, `description`, `photo`) VALUES (10, '', 'ru', 'РРО Екселліо FP2000', '', '/uploads/FP2000.jpg');
INSERT INTO mod_banner_i18n (`id`, `url`, `locale`, `name`, `description`, `photo`) VALUES (11, '', 'ru', 'РРО Datecs FP-T88', '', '/uploads/images/datecs_fp_t88_color.jpg');


#
# TABLE STRUCTURE FOR: mod_discount_all_order
#

DROP TABLE IF EXISTS mod_discount_all_order;

CREATE TABLE `mod_discount_all_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `for_autorized` tinyint(4) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `is_gift` tinyint(4) DEFAULT NULL,
  `begin_value` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discount_id` (`discount_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mod_discount_brand
#

DROP TABLE IF EXISTS mod_discount_brand;

CREATE TABLE `mod_discount_brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_id` int(11) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discount_id` (`discount_id`),
  KEY `brand_id` (`brand_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mod_discount_category
#

DROP TABLE IF EXISTS mod_discount_category;

CREATE TABLE `mod_discount_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discount_id` (`discount_id`),
  KEY `category_id` (`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mod_discount_comulativ
#

DROP TABLE IF EXISTS mod_discount_comulativ;

CREATE TABLE `mod_discount_comulativ` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discount_id` int(11) DEFAULT NULL,
  `begin_value` int(11) DEFAULT NULL,
  `end_value` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discount_id` (`discount_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mod_discount_group_user
#

DROP TABLE IF EXISTS mod_discount_group_user;

CREATE TABLE `mod_discount_group_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discount_id` (`discount_id`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mod_discount_product
#

DROP TABLE IF EXISTS mod_discount_product;

CREATE TABLE `mod_discount_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discount_id` (`discount_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mod_discount_user
#

DROP TABLE IF EXISTS mod_discount_user;

CREATE TABLE `mod_discount_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discount_id` (`discount_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mod_email_paterns
#

DROP TABLE IF EXISTS mod_email_paterns;

CREATE TABLE `mod_email_paterns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `patern` text,
  `from` varchar(256) NOT NULL,
  `from_email` varchar(256) NOT NULL,
  `admin_email` varchar(256) NOT NULL,
  `type` enum('HTML','Text') NOT NULL DEFAULT 'HTML',
  `user_message_active` tinyint(1) NOT NULL,
  `admin_message_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO mod_email_paterns (`id`, `name`, `patern`, `from`, `from_email`, `admin_email`, `type`, `user_message_active`, `admin_message_active`) VALUES (1, 'make_order', '', 'Администрация сайта', 'no-replay@shop.com', '', 'HTML', 1, 1);
INSERT INTO mod_email_paterns (`id`, `name`, `patern`, `from`, `from_email`, `admin_email`, `type`, `user_message_active`, `admin_message_active`) VALUES (2, 'change_order_status', '', 'Администрация сайта', 'no-replay@shop.com', '', 'HTML', 1, 0);
INSERT INTO mod_email_paterns (`id`, `name`, `patern`, `from`, `from_email`, `admin_email`, `type`, `user_message_active`, `admin_message_active`) VALUES (3, 'notification_email', '', 'Администрация сайта', 'no-replay@shop.com', '', 'HTML', 1, 0);
INSERT INTO mod_email_paterns (`id`, `name`, `patern`, `from`, `from_email`, `admin_email`, `type`, `user_message_active`, `admin_message_active`) VALUES (4, 'create_user', '', 'Администрация сайта', 'no-replay@shop.com', '', 'HTML', 1, 1);
INSERT INTO mod_email_paterns (`id`, `name`, `patern`, `from`, `from_email`, `admin_email`, `type`, `user_message_active`, `admin_message_active`) VALUES (5, 'forgot_password', '', 'Администрация сайта', 'no-replay@shop.com', '', 'HTML', 1, 0);
INSERT INTO mod_email_paterns (`id`, `name`, `patern`, `from`, `from_email`, `admin_email`, `type`, `user_message_active`, `admin_message_active`) VALUES (6, 'change_password', '', 'Администрация сайта', 'no-replay@shop.com', '', 'HTML', 1, 0);
INSERT INTO mod_email_paterns (`id`, `name`, `patern`, `from`, `from_email`, `admin_email`, `type`, `user_message_active`, `admin_message_active`) VALUES (7, 'price_change', '', 'Администрация сайта', 'admin@local.loc', 'admin@local.loc', 'HTML', 1, 0);
INSERT INTO mod_email_paterns (`id`, `name`, `patern`, `from`, `from_email`, `admin_email`, `type`, `user_message_active`, `admin_message_active`) VALUES (8, 'wish_list', '', 'Администрация сайта', 'no-replay@shop.com', '', 'HTML', 1, 1);


#
# TABLE STRUCTURE FOR: mod_email_paterns_i18n
#

DROP TABLE IF EXISTS mod_email_paterns_i18n;

CREATE TABLE `mod_email_paterns_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `theme` varchar(256) NOT NULL,
  `user_message` text NOT NULL,
  `admin_message` text NOT NULL,
  `description` text NOT NULL,
  `variables` text NOT NULL,
  PRIMARY KEY (`id`,`locale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO mod_email_paterns_i18n (`id`, `locale`, `theme`, `user_message`, `admin_message`, `description`, `variables`) VALUES (1, 'ru', 'Заказ товара', '<p>adsdasdasdasdasd</p>', '<p>Пользователь&nbsp;<span>$userName$ совершил заказ товара&nbsp;</span></p>\n<p><span><span>Email адрес: $userEmail$</span><br /><br /><span>Номер телефона: $userPhone$</span><br /><br /><span>Адрес доставки: $userDeliver$</span></span></p>', '<p><span>Уведомление покупателя о совершении заказа</span></p>', 'a:5:{s:10:\"$userName$\";s:31:\"Имя пользователя\";s:11:\"$userEmail$\";s:30:\"Email Пользователя\";s:11:\"$userPhone$\";s:39:\"Телефон Пользователя\";s:13:\"$userDeliver$\";s:27:\"Адрес доставки\";s:11:\"$orderLink$\";s:28:\"Ссылка на заказ\";}');
INSERT INTO mod_email_paterns_i18n (`id`, `locale`, `theme`, `user_message`, `admin_message`, `description`, `variables`) VALUES (2, 'ru', 'Смена статуса заказа', '<p><span>Здравствуйте, $userName$.</span><br /><br /><span>Статус вашего заказа изменен на&nbsp;<span>$status$</span></span><br /><br /><span>Вы указали следующие контактные данные:</span><br /><br /><span>Email адрес: $userEmail$</span><br /><br /><span>Номер телефона: $userPhone$</span><br /><br /><span>Адрес доставки: $userDeliver$</span><br /><br /><span>Менеджеры нашего магазина вскоре свяжутся с Вами и помогут с оформлением и оплатой товара.</span><br /><br /><span>Также, Вы можете всегда посмотреть за статусом Вашего заказа, перейдя по ссылке:&nbsp; $orderLink$.</span><br /><br /><span>Спасибо за ваш заказ, искренне Ваши, сотрудники ImageCMS Shop.</span><br /><br /><span>При возникновении любых вопросов, обращайтесь за телефонами:</span><br /><br /><span>+7 (095) 222-33-22 +38 (098) 222-33-22</span>&nbsp;</p>', '', '<p>Смена статуса заказа</p>', 'a:4:{s:10:\"$userName$\";s:31:\"Имя пользователя\";s:11:\"$userEmail$\";s:30:\"Email Пользователя\";s:11:\"$orderLink$\";s:28:\"Ссылка на заказ\";s:8:\"$status$\";s:25:\"статус заказа\";}');
INSERT INTO mod_email_paterns_i18n (`id`, `locale`, `theme`, `user_message`, `admin_message`, `description`, `variables`) VALUES (3, 'ru', 'Уведомление', '<p><span>Здравствуйте, $userName$.</span><br /><br /><span>Статус товара $productName$&nbsp;за которым вы следите изменен на <span>$status$</span></span><br /><br /><span>Спасибо за ваш заказ, искренне Ваши, сотрудники ImageCMS Shop.</span><br /><br /><span>При возникновении любых вопросов, обращайтесь за телефонами:</span><br /><br /><span>+7 (095) 222-33-22 +38 (098) 222-33-22</span>&nbsp;</p>', '', '<p>Уведомление о появлении</p>', 'a:5:{s:10:\"$userName$\";s:31:\"Имя пользователя\";s:11:\"$userEmail$\";s:30:\"Email Пользователя\";s:13:\"$productName$\";s:33:\"Название продукта\";s:8:\"$status$\";s:12:\"Статус\";s:13:\"$productLink$\";s:32:\"Ссылка на продукт\";}');
INSERT INTO mod_email_paterns_i18n (`id`, `locale`, `theme`, `user_message`, `admin_message`, `description`, `variables`) VALUES (4, 'ru', 'Создание пользователя', '<p><span>Успешно пройдена реєстрация $user_name$&nbsp;</span></p>\n<p>Ваши данние:<br /><span>Пароль: $user_password$</span><br /><span>Адрес: &nbsp;$user_address$</span><br /><span>Email: $user_email$</span><br /><span>Телефон: $user_phone$</span></p>', '<p><span>Создан пользователь $user_name$:</span><br /><span>С паролем: $user_password$</span><br /><span>Адресом: &nbsp;$<span>user_</span>address$</span><br /><span>Email пользователя: $user_email$</span><br /><span>Телефон пользователя: $user_phone$</span></p>', '<p>Шаблон письма на создание пользователя</p>', 'a:6:{s:11:\"$user_name$\";s:31:\"Имя пользователя\";s:14:\"$user_address$\";s:35:\"Адрес пользователя\";s:15:\"$user_password$\";s:37:\"Пароль пользователя\";s:12:\"$user_phone$\";s:39:\"Телефон пользователя\";s:12:\"$user_email$\";s:30:\"Email пользователя\";}');
INSERT INTO mod_email_paterns_i18n (`id`, `locale`, `theme`, `user_message`, `admin_message`, `description`, `variables`) VALUES (5, 'ru', 'Восстановление пароля', '<p><span>Здравствуйте!</span><br /><br /><span>На сайте $webSiteName$ создан запрос на восстановление пароля для Вашего аккаунта.</span><br /><br /><span>Для завершения процедуры восстановления пароля перейдите по ссылке $resetPasswordUri$</span><br /><br /><span>Ваш новый пароль для входа: $password$</span><br /><br /><span>Если это письмо попало к Вам по ошибке просто проигнорируйте его.</span><br /><br /><span>При возникновении любых вопросов, обращайтесь по телефонам:</span><br /><br /><span>(012)&nbsp; 345-67-89 , (012)&nbsp; 345-67-89</span><br /><br /><span>---</span><br /><br /><span>С уважением,</span><br /><br /><span>сотрудники службы продаж $webSiteName$</span></p>', '', 'Шаблон письма на  восстановление пароля', 'a:5:{s:13:\"$webSiteName$\";s:17:\"Имя сайта\";s:18:\"$resetPasswordUri$\";s:57:\"Ссилка на восстановления пароля\";s:10:\"$password$\";s:12:\"Пароль\";s:5:\"$key$\";s:8:\"Ключ\";s:16:\"$webMasterEmail$\";s:52:\"Email сотрудникjd службы продаж\";}');
INSERT INTO mod_email_paterns_i18n (`id`, `locale`, `theme`, `user_message`, `admin_message`, `description`, `variables`) VALUES (6, 'ru', 'Смена пароля', '<p><span>Здравствуйте $user_name$!</span><br /><br /><span>Ваш новый пароль для входа: $password$</span><br /><br /><span>Если это письмо попало к Вам по ошибке просто проигнорируйте его.</span><br /><br /><span><br /></span></p>', '', '<p>Шаблон письма изменения пароля</p>', 'a:2:{s:11:\"$user_name$\";s:31:\"Имя пользователя\";s:10:\"$password$\";s:23:\"Новий пароль\";}');
INSERT INTO mod_email_paterns_i18n (`id`, `locale`, `theme`, `user_message`, `admin_message`, `description`, `variables`) VALUES (7, 'ru', 'Изменение цены', '<p>Цена на $name$ за которым вы следите на сайте $server$ изменилась.<br /> <a title=\"Посмотреть список слежения\" href=\"$list_url_look$\">Посмотреть список слежения</a><br /> <a title=\"Отписатся от слежения\" href=\"$delete_list_url_look$\">Отписатся от слежения</a></p>\n<div id=\"dc_vk_code\"  none;\">&nbsp;</div>', '<p>&nbsp;</p>\n<div id=\"dc_vk_code\">&nbsp;</div>', '<p>Изменение цены</p>\n<div id=\"dc_vk_code\" style=\"display: none;\">&nbsp;</div>', '');
INSERT INTO mod_email_paterns_i18n (`id`, `locale`, `theme`, `user_message`, `admin_message`, `description`, `variables`) VALUES (7, 'ua', 'Ціна змінилася', '<p>Ціна на $name$ за яким Ви слідкуєте на сайті $server$ змінилася.<br /> <a title=\"Переглянути список слідкувань\" href=\"$list_url_look$\">Переглянути список слідкувань</a><br /> <a title=\"Відписатися від слідкування\" href=\"$delete_list_url_look$\">Відписатися від слідкування</a></p>\n<div id=\"dc_vk_code\"  none;\">&nbsp;</div>', '<p>&nbsp;</p>\n<div id=\"dc_vk_code\">&nbsp;</div>', '<p>Слідкування за ціною</p>\n<div id=\"dc_vk_code\" style=\"display: none;\">&nbsp;</div>', '');
INSERT INTO mod_email_paterns_i18n (`id`, `locale`, `theme`, `user_message`, `admin_message`, `description`, `variables`) VALUES (8, 'ru', 'Список Желаний', '<h2>Уважаемый $userName$.</h2>\n<p>Вы создали следующий список желаний $wishName$ null</p>\n<div>Ссылка на просмотр списка желаний -&nbsp;&nbsp; $wishLink$ <br /> Количество просмотров списка - $wishListViews$</div>', '<p>Пользователь&nbsp;<span>$userName$ совершил заказ товара&nbsp;</span></p>\n<p><span><span>Email адрес: $userEmail$</span><br /><br /><span>Номер телефона: $userPhone$</span><br /><br /><span>Адрес доставки: $userDeliver$</span></span></p>', '<p><span>Уведомление покупателя о совершении заказа</span></p>', 'a:4:{s:10:\"$userName$\";s:31:\"Имя пользователя\";s:10:\"$wishName$\";s:29:\"Название списка\";s:10:\"$wishLink$\";s:30:\"Ссилка на список\";s:15:\"$wishListViews$\";s:54:\"Количество просмотров списка\";}');


#
# TABLE STRUCTURE FOR: mod_new_level_columns
#

DROP TABLE IF EXISTS mod_new_level_columns;

CREATE TABLE `mod_new_level_columns` (
  `category_id` varchar(500) NOT NULL,
  `column` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO mod_new_level_columns (`category_id`, `column`) VALUES ('s:0:\"\";', '1');


#
# TABLE STRUCTURE FOR: mod_new_level_product_properties_types
#

DROP TABLE IF EXISTS mod_new_level_product_properties_types;

CREATE TABLE `mod_new_level_product_properties_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `property_id` int(11) NOT NULL,
  `name` int(11) NOT NULL,
  `type` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO mod_new_level_product_properties_types (`id`, `property_id`, `name`, `type`) VALUES (1, 29, 0, 'a:1:{i:0;s:6:\"scroll\";}');
INSERT INTO mod_new_level_product_properties_types (`id`, `property_id`, `name`, `type`) VALUES (4, 28, 0, 'a:1:{i:0;s:6:\"scroll\";}');


#
# TABLE STRUCTURE FOR: mod_sample_settings
#

DROP TABLE IF EXISTS mod_sample_settings;

CREATE TABLE `mod_sample_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `value` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO mod_sample_settings (`id`, `name`, `value`) VALUES (1, 'mailTo', 'admin@site.com');
INSERT INTO mod_sample_settings (`id`, `name`, `value`) VALUES (2, 'useEmailNotification', 'TRUE');
INSERT INTO mod_sample_settings (`id`, `name`, `value`) VALUES (3, 'key', 'UUUsssTTTeee');


#
# TABLE STRUCTURE FOR: mod_shop_discounts
#

DROP TABLE IF EXISTS mod_shop_discounts;

CREATE TABLE `mod_shop_discounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(25) DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL,
  `active` tinyint(4) DEFAULT NULL,
  `max_apply` int(11) DEFAULT NULL,
  `count_apply` int(11) DEFAULT NULL,
  `date_begin` int(11) DEFAULT NULL,
  `date_end` int(11) DEFAULT NULL,
  `type_value` tinyint(4) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  `type_discount` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_UNIQUE` (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mod_shop_discounts_i18n
#

DROP TABLE IF EXISTS mod_shop_discounts_i18n;

CREATE TABLE `mod_shop_discounts_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`,`locale`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mod_shop_news
#

DROP TABLE IF EXISTS mod_shop_news;

CREATE TABLE `mod_shop_news` (
  `content_id` int(11) NOT NULL,
  `shop_categories_ids` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mod_social
#

DROP TABLE IF EXISTS mod_social;

CREATE TABLE `mod_social` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `socialId` varchar(30) DEFAULT NULL,
  `userId` varchar(25) DEFAULT NULL,
  `social` varchar(20) DEFAULT NULL,
  `isMain` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mod_wish_list
#

DROP TABLE IF EXISTS mod_wish_list;

CREATE TABLE `mod_wish_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(254) NOT NULL,
  `description` text,
  `access` enum('public','private','shared') NOT NULL DEFAULT 'shared',
  `user_id` int(11) NOT NULL,
  `review_count` int(11) NOT NULL DEFAULT '0',
  `hash` varchar(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mod_wish_list_products
#

DROP TABLE IF EXISTS mod_wish_list_products;

CREATE TABLE `mod_wish_list_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wish_list_id` int(11) NOT NULL,
  `variant_id` int(11) NOT NULL,
  `comment` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mod_wish_list_users
#

DROP TABLE IF EXISTS mod_wish_list_users;

CREATE TABLE `mod_wish_list_users` (
  `id` int(11) NOT NULL,
  `user_name` varchar(254) DEFAULT NULL,
  `user_image` text,
  `user_birthday` int(11) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO mod_wish_list_users (`id`, `user_name`, `user_image`, `user_birthday`, `description`) VALUES (1, 'Administrator', NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: propel_migration
#

DROP TABLE IF EXISTS propel_migration;

CREATE TABLE `propel_migration` (
  `version` int(11) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO propel_migration (`version`) VALUES (1363604832);


#
# TABLE STRUCTURE FOR: rating
#

DROP TABLE IF EXISTS rating;

CREATE TABLE `rating` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_type` varchar(25) DEFAULT NULL,
  `type` varchar(25) DEFAULT NULL,
  `votes` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: search
#

DROP TABLE IF EXISTS search;

CREATE TABLE `search` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(264) NOT NULL,
  `datetime` int(11) NOT NULL,
  `where_array` text NOT NULL,
  `select_array` text NOT NULL,
  `table_name` varchar(100) NOT NULL,
  `order_by` text NOT NULL,
  `row_count` int(11) NOT NULL,
  `total_rows` int(11) NOT NULL,
  `ids` text NOT NULL,
  `search_title` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hash` (`hash`),
  KEY `datetime` (`datetime`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO search (`id`, `hash`, `datetime`, `where_array`, `select_array`, `table_name`, `order_by`, `row_count`, `total_rows`, `ids`, `search_title`) VALUES (11, '81cf9744cbb82e795b1531a8e2391fba4a125eee', 1458121575, 'a:5:{i:0;a:2:{s:15:\"publish_date <=\";s:16:\"UNIX_TIMESTAMP()\";s:9:\"backticks\";b:0;}i:1;a:2:{s:4:\"id =\";i:0;s:9:\"backticks\";s:4:\"both\";}i:2;a:3:{s:9:\"prev_text\";s:6:\"gkfuby\";s:8:\"operator\";s:4:\"LIKE\";s:9:\"backticks\";s:4:\"both\";}i:3;a:3:{s:9:\"full_text\";s:6:\"gkfuby\";s:8:\"operator\";s:7:\"OR_LIKE\";s:9:\"backticks\";s:4:\"both\";}i:4;a:3:{s:5:\"title\";s:6:\"gkfuby\";s:8:\"operator\";s:7:\"OR_LIKE\";s:9:\"backticks\";s:4:\"both\";}}', 'a:0:{}', 'content', 'a:1:{s:12:\"publish_date\";s:4:\"DESC\";}', 15, 0, 'a:0:{}', 'gkfuby');


#
# TABLE STRUCTURE FOR: settings
#

DROP TABLE IF EXISTS settings;

CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `s_name` varchar(50) NOT NULL,
  `create_keywords` varchar(25) NOT NULL,
  `create_description` varchar(25) NOT NULL,
  `create_cat_keywords` varchar(25) NOT NULL,
  `create_cat_description` varchar(25) NOT NULL,
  `add_site_name` int(1) NOT NULL,
  `add_site_name_to_cat` int(1) NOT NULL,
  `delimiter` varchar(5) NOT NULL,
  `editor_theme` varchar(10) NOT NULL,
  `site_template` varchar(50) NOT NULL,
  `site_offline` varchar(5) NOT NULL,
  `google_analytics_id` varchar(40) DEFAULT NULL,
  `main_type` varchar(50) NOT NULL,
  `main_page_id` int(11) NOT NULL,
  `main_page_cat` text NOT NULL,
  `main_page_module` varchar(50) NOT NULL,
  `sidepanel` varchar(5) NOT NULL,
  `lk` varchar(250) DEFAULT NULL,
  `lang_sel` varchar(15) NOT NULL DEFAULT 'russian_lang',
  `google_webmaster` varchar(200) DEFAULT NULL,
  `yandex_webmaster` varchar(200) DEFAULT NULL,
  `yandex_metric` varchar(11) NOT NULL,
  `ss` varchar(255) NOT NULL,
  `cat_list` varchar(10) NOT NULL,
  `text_editor` varchar(30) NOT NULL,
  `siteinfo` text NOT NULL,
  `update` text,
  `backup` text,
  PRIMARY KEY (`id`),
  KEY `s_name` (`s_name`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO settings (`id`, `s_name`, `create_keywords`, `create_description`, `create_cat_keywords`, `create_cat_description`, `add_site_name`, `add_site_name_to_cat`, `delimiter`, `editor_theme`, `site_template`, `site_offline`, `google_analytics_id`, `main_type`, `main_page_id`, `main_page_cat`, `main_page_module`, `sidepanel`, `lk`, `lang_sel`, `google_webmaster`, `yandex_webmaster`, `yandex_metric`, `ss`, `cat_list`, `text_editor`, `siteinfo`, `update`, `backup`) VALUES (2, 'main', 'auto', 'auto', '0', '0', 1, 1, '/', '0', 'newLevel', 'no', '', 'module', 69, '63', 'shop', '', '', 'russian_lang', 'kExHpxtP5ms7upUshY7bVxfHVw_aIjprMT_Tv-uWpEY', '5102604e59dce45a', '31144891', '', 'yes', 'tinymce', 'a:3:{s:13:\"siteinfo_logo\";a:1:{s:8:\"newLevel\";s:15:\"qweqweqwe83.png\";}s:16:\"siteinfo_favicon\";a:1:{s:8:\"newLevel\";s:15:\"qweqweqwe83.png\";}s:2:\"ru\";a:7:{s:20:\"siteinfo_companytype\";s:70:\"© Інтернет-магазин «Інпром-сервіс», 2015\";s:16:\"siteinfo_address\";s:44:\"м. Полтава, вул. Фрунзе, 90\";s:18:\"siteinfo_mainphone\";s:75:\"(0532) 54-44-20,  54-44-27,  54-44-29,<br>\n    095-816-35-87, 096-854-32-05\";s:19:\"siteinfo_adminemail\";s:27:\"webmaster@artexgroup.com.ua\";s:14:\"siteinfo_Email\";s:27:\"office@inpromservice.com.ua\";s:14:\"siteinfo_Skype\";s:21:\"inprom-service.com.ua\";s:8:\"contacts\";a:2:{s:5:\"Email\";s:27:\"office@inpromservice.com.ua\";s:5:\"Skype\";s:21:\"inprom-service.com.ua\";}}}', 'a:3:{i:0;b:0;s:10:\"newVersion\";s:8:\"s:1:\"1\";\";s:9:\"checkTime\";i:1458122063;}', NULL);


#
# TABLE STRUCTURE FOR: settings_i18n
#

DROP TABLE IF EXISTS settings_i18n;

CREATE TABLE `settings_i18n` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang_ident` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `short_name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `keywords` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO settings_i18n (`id`, `lang_ident`, `name`, `short_name`, `description`, `keywords`) VALUES (1, 3, 'Инпром-сервис. Інпром-сервіс. Фирма Інпром-сервіс ООО', 'Инпром-сервис. Інпром-сервіс. Фирма Інпром-сервіс ООО', 'Инпром-сервис. Інпром-сервіс. Фирма Інпром-сервіс ООО', 'Инпром-сервис, Інпром-сервіс, Фирма Інпром-сервіс ООО');
INSERT INTO settings_i18n (`id`, `lang_ident`, `name`, `short_name`, `description`, `keywords`) VALUES (3, 31, 'Інпром-сервіс', 'Інпром-сервіс', 'Інпром-сервіс', 'Інпром-сервіс');


#
# TABLE STRUCTURE FOR: shop_banners
#

DROP TABLE IF EXISTS shop_banners;

CREATE TABLE `shop_banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` smallint(6) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `categories` text,
  `on_main` tinyint(1) DEFAULT NULL,
  `espdate` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_banners_I_1` (`position`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO shop_banners (`id`, `position`, `active`, `categories`, `on_main`, `espdate`) VALUES (7, 23, 1, 'false', 1, 2147483647);
INSERT INTO shop_banners (`id`, `position`, `active`, `categories`, `on_main`, `espdate`) VALUES (11, 24, 1, 'false', 1, 2147457600);
INSERT INTO shop_banners (`id`, `position`, `active`, `categories`, `on_main`, `espdate`) VALUES (12, 25, 1, 'false', 1, 2147457600);


#
# TABLE STRUCTURE FOR: shop_banners_i18n
#

DROP TABLE IF EXISTS shop_banners_i18n;

CREATE TABLE `shop_banners_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`locale`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_banners_i18n (`id`, `locale`, `name`, `text`, `url`, `image`) VALUES (12, 'ru', 'Samsung', ' ', '/shop/brand/samsung', 'template-imageshop-banner-3.jpg');
INSERT INTO shop_banners_i18n (`id`, `locale`, `name`, `text`, `url`, `image`) VALUES (7, 'ru', 'Epson', ' ', '/shop/brand/epson', 'template-imageshop-banner-1.jpg');
INSERT INTO shop_banners_i18n (`id`, `locale`, `name`, `text`, `url`, `image`) VALUES (11, 'ru', 'Sony', ' ', '/shop/brand/sony', 'template-imageshop-banner-2.jpg');


#
# TABLE STRUCTURE FOR: shop_brands
#

DROP TABLE IF EXISTS shop_brands;

CREATE TABLE `shop_brands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `position` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_brands_I_2` (`url`),
  KEY `shop_brands_I_1` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: shop_brands_i18n
#

DROP TABLE IF EXISTS shop_brands_i18n;

CREATE TABLE `shop_brands_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `name` varchar(500) NOT NULL,
  `description` text,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`locale`),
  KEY `shop_brands_i18n_I_1` (`name`(333))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: shop_callbacks
#

DROP TABLE IF EXISTS shop_callbacks;

CREATE TABLE `shop_callbacks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `theme_id` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text,
  `date` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_callbacks_I_1` (`user_id`),
  KEY `shop_callbacks_I_2` (`status_id`),
  KEY `shop_callbacks_I_3` (`theme_id`),
  KEY `shop_callbacks_I_4` (`date`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: shop_callbacks_statuses
#

DROP TABLE IF EXISTS shop_callbacks_statuses;

CREATE TABLE `shop_callbacks_statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_default` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO shop_callbacks_statuses (`id`, `is_default`) VALUES (1, 1);
INSERT INTO shop_callbacks_statuses (`id`, `is_default`) VALUES (3, 0);


#
# TABLE STRUCTURE FOR: shop_callbacks_statuses_i18n
#

DROP TABLE IF EXISTS shop_callbacks_statuses_i18n;

CREATE TABLE `shop_callbacks_statuses_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `text` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`locale`),
  KEY `shop_callbacks_statuses_i18n_I_1` (`text`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_callbacks_statuses_i18n (`id`, `locale`, `text`) VALUES (1, 'ru', 'Новый');
INSERT INTO shop_callbacks_statuses_i18n (`id`, `locale`, `text`) VALUES (3, 'ru', 'Обработан');


#
# TABLE STRUCTURE FOR: shop_callbacks_themes
#

DROP TABLE IF EXISTS shop_callbacks_themes;

CREATE TABLE `shop_callbacks_themes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO shop_callbacks_themes (`id`, `position`) VALUES (1, 0);


#
# TABLE STRUCTURE FOR: shop_callbacks_themes_i18n
#

DROP TABLE IF EXISTS shop_callbacks_themes_i18n;

CREATE TABLE `shop_callbacks_themes_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `text` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`locale`),
  KEY `shop_callbacks_themes_i18n_I_1` (`text`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_callbacks_themes_i18n (`id`, `locale`, `text`) VALUES (1, 'ru', 'Первая тема');
INSERT INTO shop_callbacks_themes_i18n (`id`, `locale`, `text`) VALUES (1, 'ua', 'Перша тема');


#
# TABLE STRUCTURE FOR: shop_category
#

DROP TABLE IF EXISTS shop_category;

CREATE TABLE `shop_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `full_path` varchar(1000) DEFAULT NULL,
  `full_path_ids` varchar(250) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `external_id` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `tpl` varchar(250) DEFAULT NULL,
  `order_method` int(11) DEFAULT NULL,
  `showsitetitle` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_category_I_2` (`url`),
  KEY `shop_category_I_3` (`active`),
  KEY `shop_category_I_4` (`parent_id`),
  KEY `shop_category_I_5` (`position`),
  KEY `shop_category_I_1` (`url`),
  KEY `external_id` (`external_id`)
) ENGINE=MyISAM AUTO_INCREMENT=112 DEFAULT CHARSET=utf8;

INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (78, 'vagove-obladnannia', 0, 4, 'vagove-obladnannia', 'a:0:{}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (79, 'kasove-obladnannia', 0, 0, 'kasove-obladnannia', 'a:0:{}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (80, 'vitratni-materiali', 0, 19, 'vitratni-materiali', 'a:0:{}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (81, 'pos-obladnannia', 0, 10, 'pos-obladnannia', 'a:0:{}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (83, 'bankivske-obladnannia', 0, 18, 'bankivske-obladnannia', 'a:0:{}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (92, 'fiskalni-reestratori', 79, 3, 'kasove-obladnannia/fiskalni-reestratori', 'a:1:{i:0;i:79;}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (91, 'statsionarni-rro', 79, 2, 'kasove-obladnannia/statsionarni-rro', 'a:1:{i:0;i:79;}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (90, 'portativni-rro', 79, 1, 'kasove-obladnannia/portativni-rro', 'a:1:{i:0;i:79;}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (93, 'torgovi-vagi', 78, 5, 'vagove-obladnannia/torgovi-vagi', 'a:1:{i:0;i:78;}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (94, 'tovarni-vagi', 78, 6, 'vagove-obladnannia/tovarni-vagi', 'a:1:{i:0;i:78;}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (95, 'laboratorni-vagi', 78, 7, 'vagove-obladnannia/laboratorni-vagi', 'a:1:{i:0;i:78;}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (96, 'groshovi-skrinki', 81, 11, 'pos-obladnannia/groshovi-skrinki', 'a:1:{i:0;i:81;}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (97, 'pos-terminali', 81, 12, 'pos-obladnannia/pos-terminali', 'a:1:{i:0;i:81;}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (98, 'skaneri-shtrihkodiv', 81, 13, 'pos-obladnannia/skaneri-shtrihkodiv', 'a:1:{i:0;i:81;}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (99, 'terminali-zboru-danih', 81, 14, 'pos-obladnannia/terminali-zboru-danih', 'a:1:{i:0;i:81;}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (100, 'chekodrukuiuchi-vagi', 78, 8, 'vagove-obladnannia/chekodrukuiuchi-vagi', 'a:1:{i:0;i:78;}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (101, 'printeri-dlia-druku-chekiv', 81, 15, 'pos-obladnannia/printeri-dlia-druku-chekiv', 'a:1:{i:0;i:81;}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (102, 'zasobi-markuvannia', 81, 16, 'pos-obladnannia/zasobi-markuvannia', 'a:1:{i:0;i:81;}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (103, 'detektori-valiut', 83, 19, 'bankivske-obladnannia/detektori-valiut', 'a:1:{i:0;i:83;}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (104, 'lichilniki-banknot', 83, 20, 'bankivske-obladnannia/lichilniki-banknot', 'a:1:{i:0;i:83;}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (105, 'kasova-strichka', 80, 22, 'vitratni-materiali/kasova-strichka', 'a:1:{i:0;i:80;}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (106, 'termoetiketka', 80, 23, 'vitratni-materiali/termoetiketka', 'a:1:{i:0;i:80;}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (107, 'ribboni', 80, 24, 'vitratni-materiali/ribboni', 'a:1:{i:0;i:80;}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (108, 'etiket-strichka', 80, 25, 'vitratni-materiali/etiket-strichka', 'a:1:{i:0;i:80;}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (109, 'samokleiuchi-etiketki-na-arkushah-a4', 80, 26, 'vitratni-materiali/samokleiuchi-etiketki-na-arkushah-a4', 'a:1:{i:0;i:80;}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (110, 'fasovochni-vagi', 78, 9, 'vagove-obladnannia/fasovochni-vagi', 'a:1:{i:0;i:78;}', 1, NULL, '', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (111, 'zchituvachi-magnitnih-kart', 81, 17, 'pos-obladnannia/zchituvachi-magnitnih-kart', 'a:1:{i:0;i:81;}', 1, NULL, '', '', 0, NULL);


#
# TABLE STRUCTURE FOR: shop_category_i18n
#

DROP TABLE IF EXISTS shop_category_i18n;

CREATE TABLE `shop_category_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `name` varchar(255) NOT NULL,
  `h1` varchar(255) NOT NULL,
  `description` text,
  `meta_desc` varchar(255) NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  PRIMARY KEY (`id`,`locale`),
  KEY `shop_category_i18n_I_1` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (78, 'ru', 'Вагове обладнання', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (79, 'ru', 'Касове обладнання', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (80, 'ru', 'Витратні матеріали', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (81, 'ru', 'POS-обладнання', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (83, 'ru', 'Банківське обладнання', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (90, 'ru', 'Портативні РРО', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (91, 'ru', 'Стаціонарні РРО', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (92, 'ru', 'Фіскальні реєстратори', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (93, 'ru', 'Торгові ваги', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (94, 'ru', 'Товарні ваги', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (95, 'ru', 'Лабораторні ваги', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (96, 'ru', 'Грошові скриньки', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (97, 'ru', 'POS-термінали', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (98, 'ru', 'Сканери штрихкодів', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (99, 'ru', 'Термінали збору даних', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (100, 'ru', 'Чекодрукуючі ваги', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (101, 'ru', 'Принтери для друку чеків', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (102, 'ru', 'Засоби маркування', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (103, 'ru', 'Детектори валют', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (104, 'ru', 'Лічильники банкнот', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (105, 'ru', 'Касова стрічка', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (106, 'ru', 'Термоетикетка', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (107, 'ru', 'Ріббони', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (108, 'ru', 'Етикет-стрічка', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (109, 'ru', 'Самоклеючі етикетки на аркушах А4', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (110, 'ru', 'Фасовочні ваги', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (111, 'ru', 'Зчитувачі магнітних карт', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: shop_comulativ_discount
#

DROP TABLE IF EXISTS shop_comulativ_discount;

CREATE TABLE `shop_comulativ_discount` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `discount` int(3) DEFAULT NULL,
  `active` int(1) DEFAULT NULL,
  `date` int(15) DEFAULT NULL,
  `total` int(255) DEFAULT NULL,
  `total_a` int(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: shop_currencies
#

DROP TABLE IF EXISTS shop_currencies;

CREATE TABLE `shop_currencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `main` tinyint(1) DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT NULL,
  `code` varchar(5) DEFAULT NULL,
  `symbol` varchar(5) DEFAULT NULL,
  `rate` float(6,3) DEFAULT '1.000',
  `showOnSite` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `shop_currencies_I_1` (`name`),
  KEY `shop_currencies_I_2` (`main`),
  KEY `shop_currencies_I_3` (`is_default`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO shop_currencies (`id`, `name`, `main`, `is_default`, `code`, `symbol`, `rate`, `showOnSite`) VALUES (1, 'Dollars', 0, 0, 'USD', '$', '0.031', 0);
INSERT INTO shop_currencies (`id`, `name`, `main`, `is_default`, `code`, `symbol`, `rate`, `showOnSite`) VALUES (4, 'Гривна', 1, 1, 'UAH', 'грн.', '1.000', 1);


#
# TABLE STRUCTURE FOR: shop_delivery_methods
#

DROP TABLE IF EXISTS shop_delivery_methods;

CREATE TABLE `shop_delivery_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` float(10,2) NOT NULL,
  `free_from` float(10,2) NOT NULL,
  `enabled` tinyint(1) DEFAULT NULL,
  `is_price_in_percent` tinyint(1) NOT NULL,
  `position` int(11) DEFAULT NULL,
  `delivery_sum_specified` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_delivery_methods_I_2` (`enabled`),
  KEY `shop_delivery_methods_I_1` (`enabled`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

INSERT INTO shop_delivery_methods (`id`, `price`, `free_from`, `enabled`, `is_price_in_percent`, `position`, `delivery_sum_specified`) VALUES (7, '0.00', '0.00', 1, 0, NULL, NULL);
INSERT INTO shop_delivery_methods (`id`, `price`, `free_from`, `enabled`, `is_price_in_percent`, `position`, `delivery_sum_specified`) VALUES (5, '0.00', '0.00', 1, 0, NULL, 0);
INSERT INTO shop_delivery_methods (`id`, `price`, `free_from`, `enabled`, `is_price_in_percent`, `position`, `delivery_sum_specified`) VALUES (6, '0.00', '0.00', 1, 0, NULL, 0);


#
# TABLE STRUCTURE FOR: shop_delivery_methods_i18n
#

DROP TABLE IF EXISTS shop_delivery_methods_i18n;

CREATE TABLE `shop_delivery_methods_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `name` varchar(500) NOT NULL,
  `description` text,
  `pricedescription` text,
  `delivery_sum_specified_message` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`,`locale`),
  KEY `shop_delivery_methods_i18n_I_1` (`name`(333))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_delivery_methods_i18n (`id`, `locale`, `name`, `description`, `pricedescription`, `delivery_sum_specified_message`) VALUES (7, 'ru', 'Самовывоз', ' ', ' ', NULL);
INSERT INTO shop_delivery_methods_i18n (`id`, `locale`, `name`, `description`, `pricedescription`, `delivery_sum_specified_message`) VALUES (5, 'ru', 'Нова Пошта', '<p>Только по Киеву и Москве</p>', '', '');
INSERT INTO shop_delivery_methods_i18n (`id`, `locale`, `name`, `description`, `pricedescription`, `delivery_sum_specified_message`) VALUES (6, 'ru', 'Автолюкс', '<p>Доставка по всему миру</p>', '', '');
INSERT INTO shop_delivery_methods_i18n (`id`, `locale`, `name`, `description`, `pricedescription`, `delivery_sum_specified_message`) VALUES (7, 'ua', 'Самовивезення', '', NULL, NULL);


#
# TABLE STRUCTURE FOR: shop_delivery_methods_systems
#

DROP TABLE IF EXISTS shop_delivery_methods_systems;

CREATE TABLE `shop_delivery_methods_systems` (
  `delivery_method_id` int(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  PRIMARY KEY (`delivery_method_id`,`payment_method_id`),
  KEY `shop_delivery_methods_systems_FI_2` (`payment_method_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (5, 1);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (5, 2);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (5, 3);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (6, 1);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (6, 2);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (6, 3);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (7, 1);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (15, 1);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (16, 1);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (16, 2);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (16, 3);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (20, 1);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (20, 3);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (21, 2);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (23, 3);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (24, 3);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (25, 1);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (25, 2);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (25, 3);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (25, 4);


#
# TABLE STRUCTURE FOR: shop_discounts
#

DROP TABLE IF EXISTS shop_discounts;

CREATE TABLE `shop_discounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `date_start` int(11) DEFAULT NULL,
  `date_stop` int(11) DEFAULT NULL,
  `discount` varchar(11) DEFAULT NULL,
  `min_price` float(10,2) DEFAULT NULL,
  `max_price` float(10,2) DEFAULT NULL,
  `categories` text,
  `products` text,
  `description` text,
  `user_group` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: shop_gifts
#

DROP TABLE IF EXISTS shop_gifts;

CREATE TABLE `shop_gifts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `created` int(11) DEFAULT NULL,
  `espdate` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO shop_gifts (`id`, `key`, `active`, `price`, `created`, `espdate`) VALUES (1, 'WTWWwPHJ4Al91jnZ', NULL, 100, 1354039607, 1354219200);
INSERT INTO shop_gifts (`id`, `key`, `active`, `price`, `created`, `espdate`) VALUES (2, '7WMAohSSCA3OViRL', NULL, 4, 1354039810, 1353700800);
INSERT INTO shop_gifts (`id`, `key`, `active`, `price`, `created`, `espdate`) VALUES (3, 'psnqw6IFxamCOCVmsd', NULL, 35, 1354039839, 1352404800);


#
# TABLE STRUCTURE FOR: shop_kit
#

DROP TABLE IF EXISTS shop_kit;

CREATE TABLE `shop_kit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `position` smallint(6) NOT NULL,
  `only_for_logged` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_kit_FI_1` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: shop_kit_product
#

DROP TABLE IF EXISTS shop_kit_product;

CREATE TABLE `shop_kit_product` (
  `product_id` int(11) NOT NULL,
  `kit_id` int(11) NOT NULL,
  `discount` varchar(11) DEFAULT '0',
  PRIMARY KEY (`product_id`,`kit_id`),
  KEY `shop_kit_product_FI_2` (`kit_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: shop_notification_statuses
#

DROP TABLE IF EXISTS shop_notification_statuses;

CREATE TABLE `shop_notification_statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_notification_statuses_I_2` (`position`),
  KEY `shop_notification_statuses_I_1` (`position`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO shop_notification_statuses (`id`, `position`) VALUES (1, 1);
INSERT INTO shop_notification_statuses (`id`, `position`) VALUES (2, 0);


#
# TABLE STRUCTURE FOR: shop_notification_statuses_i18n
#

DROP TABLE IF EXISTS shop_notification_statuses_i18n;

CREATE TABLE `shop_notification_statuses_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `name` varchar(500) NOT NULL,
  PRIMARY KEY (`id`,`locale`),
  KEY `shop_notification_statuses_i18n_I_1` (`name`(333))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_notification_statuses_i18n (`id`, `locale`, `name`) VALUES (1, 'ru', 'Новый');
INSERT INTO shop_notification_statuses_i18n (`id`, `locale`, `name`) VALUES (2, 'ru', 'Выполнен');


#
# TABLE STRUCTURE FOR: shop_notifications
#

DROP TABLE IF EXISTS shop_notifications;

CREATE TABLE `shop_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `user_phone` varchar(100) DEFAULT NULL,
  `user_comment` varchar(500) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `date_created` int(11) NOT NULL,
  `active_to` int(11) NOT NULL,
  `manager_id` int(11) DEFAULT NULL,
  `notified_by_email` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_notifications_I_1` (`user_email`),
  KEY `shop_notifications_I_2` (`user_phone`),
  KEY `shop_notifications_I_3` (`status`),
  KEY `shop_notifications_I_4` (`date_created`),
  KEY `shop_notifications_I_5` (`active_to`),
  KEY `shop_notifications_FI_1` (`product_id`),
  KEY `shop_notifications_FI_2` (`variant_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: shop_order_statuses
#

DROP TABLE IF EXISTS shop_order_statuses;

CREATE TABLE `shop_order_statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_order_statuses_I_2` (`position`),
  KEY `shop_order_statuses_I_1` (`position`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO shop_order_statuses (`id`, `position`) VALUES (1, 1);
INSERT INTO shop_order_statuses (`id`, `position`) VALUES (2, 99);


#
# TABLE STRUCTURE FOR: shop_order_statuses_i18n
#

DROP TABLE IF EXISTS shop_order_statuses_i18n;

CREATE TABLE `shop_order_statuses_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `name` varchar(500) NOT NULL,
  PRIMARY KEY (`id`,`locale`),
  KEY `shop_order_statuses_i18n_I_1` (`name`(333))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_order_statuses_i18n (`id`, `locale`, `name`) VALUES (1, 'ru', 'Новый');
INSERT INTO shop_order_statuses_i18n (`id`, `locale`, `name`) VALUES (2, 'ru', 'Доставлен');


#
# TABLE STRUCTURE FOR: shop_orders
#

DROP TABLE IF EXISTS shop_orders;

CREATE TABLE `shop_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `delivery_method` int(11) DEFAULT NULL,
  `delivery_price` float(10,2) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `paid` tinyint(1) DEFAULT NULL,
  `user_full_name` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `user_phone` varchar(255) DEFAULT NULL,
  `user_deliver_to` varchar(500) DEFAULT NULL,
  `user_comment` varchar(1000) DEFAULT NULL,
  `date_created` int(11) DEFAULT NULL,
  `date_updated` int(11) DEFAULT NULL,
  `user_ip` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `payment_method` int(11) DEFAULT NULL,
  `total_price` float(10,2) DEFAULT NULL,
  `external_id` varchar(255) DEFAULT NULL,
  `gift_cert_key` varchar(25) DEFAULT NULL,
  `gift_cert_price` int(11) DEFAULT NULL,
  `comulativ` int(3) DEFAULT NULL,
  `discount` float(10,2) DEFAULT NULL,
  `discount_info` text,
  `origin_price` float(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_orders_I_1` (`key`),
  KEY `shop_orders_I_2` (`status`),
  KEY `shop_orders_I_3` (`date_created`),
  KEY `shop_orders_FI_1` (`delivery_method`),
  KEY `shop_orders_FI_2` (`payment_method`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: shop_orders_products
#

DROP TABLE IF EXISTS shop_orders_products;

CREATE TABLE `shop_orders_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) NOT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `variant_name` varchar(255) DEFAULT NULL,
  `price` float(10,2) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `kit_id` int(11) DEFAULT NULL,
  `is_main` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_orders_products_I_1` (`order_id`),
  KEY `shop_orders_products_FI_1` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=73 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: shop_orders_status_history
#

DROP TABLE IF EXISTS shop_orders_status_history;

CREATE TABLE `shop_orders_status_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date_created` int(11) DEFAULT NULL,
  `comment` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_orders_status_history_I_1` (`order_id`),
  KEY `shop_orders_status_history_FI_2` (`status_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: shop_payment_methods
#

DROP TABLE IF EXISTS shop_payment_methods;

CREATE TABLE `shop_payment_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) DEFAULT NULL,
  `currency_id` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `payment_system_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_payment_methods_I_2` (`position`),
  KEY `shop_payment_methods_FI_1` (`currency_id`),
  KEY `shop_payment_methods_I_1` (`position`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO shop_payment_methods (`id`, `active`, `currency_id`, `position`, `payment_system_name`) VALUES (1, 0, 4, 0, '0');
INSERT INTO shop_payment_methods (`id`, `active`, `currency_id`, `position`, `payment_system_name`) VALUES (2, 1, 4, 1, 'OschadBankInvoiceSystem');
INSERT INTO shop_payment_methods (`id`, `active`, `currency_id`, `position`, `payment_system_name`) VALUES (3, 0, 4, 2, '0');
INSERT INTO shop_payment_methods (`id`, `active`, `currency_id`, `position`, `payment_system_name`) VALUES (4, 0, 4, 3, 'RobokassaSystem');


#
# TABLE STRUCTURE FOR: shop_payment_methods_i18n
#

DROP TABLE IF EXISTS shop_payment_methods_i18n;

CREATE TABLE `shop_payment_methods_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`,`locale`),
  KEY `shop_payment_methods_i18n_I_1` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_payment_methods_i18n (`id`, `locale`, `name`, `description`) VALUES (1, 'ru', 'Нова Пошта', '<p>Оплата через веб-моней</p>');
INSERT INTO shop_payment_methods_i18n (`id`, `locale`, `name`, `description`) VALUES (2, 'ru', 'Оплата через Банк', '<p>Оплата через ОщадБанк Украины</p>');
INSERT INTO shop_payment_methods_i18n (`id`, `locale`, `name`, `description`) VALUES (3, 'ru', 'Автолюкс', '<p>Оплата через СберБанк России</p>');
INSERT INTO shop_payment_methods_i18n (`id`, `locale`, `name`, `description`) VALUES (4, 'ru', 'Robokassa', '<p>Оплата с помощью Robokassa</p>');
INSERT INTO shop_payment_methods_i18n (`id`, `locale`, `name`, `description`) VALUES (1, 'en', 'Payment for the courier', '');
INSERT INTO shop_payment_methods_i18n (`id`, `locale`, `name`, `description`) VALUES (2, 'en', 'Payment by bank', '');
INSERT INTO shop_payment_methods_i18n (`id`, `locale`, `name`, `description`) VALUES (3, 'en', 'Sberbank of Russia', '');
INSERT INTO shop_payment_methods_i18n (`id`, `locale`, `name`, `description`) VALUES (4, 'en', 'Robokassa', '');


#
# TABLE STRUCTURE FOR: shop_product_categories
#

DROP TABLE IF EXISTS shop_product_categories;

CREATE TABLE `shop_product_categories` (
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`product_id`,`category_id`),
  KEY `shop_product_categories_FI_2` (`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (196, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (196, 90);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (197, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (197, 90);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (198, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (198, 90);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (199, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (199, 91);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (200, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (200, 90);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (201, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (201, 92);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (202, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (202, 91);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (203, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (203, 90);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (204, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (204, 90);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (205, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (205, 93);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (206, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (206, 93);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (207, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (207, 94);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (208, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (208, 94);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (209, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (209, 93);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (210, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (210, 93);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (211, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (211, 96);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (212, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (212, 96);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (213, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (213, 96);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (214, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (214, 96);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (215, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (215, 91);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (216, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (216, 96);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (217, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (217, 97);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (218, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (218, 97);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (220, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (220, 98);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (221, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (221, 98);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (222, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (222, 98);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (223, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (223, 95);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (224, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (224, 95);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (225, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (225, 95);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (226, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (226, 95);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (227, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (227, 100);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (228, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (228, 100);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (229, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (229, 100);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (230, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (230, 100);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (231, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (231, 99);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (232, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (232, 99);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (233, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (233, 99);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (234, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (234, 101);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (235, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (235, 102);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (236, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (236, 102);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (237, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (237, 102);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (238, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (238, 102);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (239, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (239, 102);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (240, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (240, 90);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (241, 83);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (241, 103);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (242, 83);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (242, 103);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (243, 83);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (243, 103);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (244, 83);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (244, 104);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (245, 83);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (245, 104);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (246, 83);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (246, 104);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (247, 83);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (247, 104);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (248, 80);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (248, 105);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (249, 80);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (249, 105);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (250, 80);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (250, 105);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (251, 80);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (251, 105);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (252, 106);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (253, 80);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (253, 106);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (254, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (254, 92);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (255, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (255, 92);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (256, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (256, 90);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (257, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (257, 93);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (258, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (258, 110);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (259, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (259, 110);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (260, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (260, 110);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (261, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (261, 110);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (262, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (262, 110);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (263, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (263, 110);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (264, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (264, 93);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (265, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (265, 93);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (266, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (266, 93);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (267, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (267, 111);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (268, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (268, 101);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (269, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (269, 101);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (270, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (270, 101);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (271, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (271, 101);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (272, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (272, 101);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (275, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (275, 101);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (276, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (276, 111);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (277, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (277, 111);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (278, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (278, 92);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (279, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (279, 92);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (280, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (280, 93);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (281, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (281, 93);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (282, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (282, 98);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (283, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (283, 98);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (284, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (284, 98);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (285, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (285, 98);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (286, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (286, 98);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (287, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (287, 98);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (288, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (288, 102);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (289, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (289, 102);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (290, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (290, 95);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (291, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (291, 95);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (292, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (292, 95);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (293, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (293, 110);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (294, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (294, 93);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (295, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (295, 110);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (296, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (296, 94);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (297, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (297, 94);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (298, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (298, 94);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (299, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (299, 110);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (300, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (300, 98);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (301, 83);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (301, 104);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (302, 83);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (302, 103);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (303, 80);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (303, 106);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (304, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (304, 94);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (305, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (305, 110);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (306, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (306, 92);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (307, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (307, 92);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (308, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (308, 93);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (309, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (309, 92);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (310, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (310, 98);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (311, 80);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (311, 106);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (312, 80);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (312, 106);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (313, 80);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (313, 106);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (314, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (314, 91);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (315, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (315, 92);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (316, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (316, 102);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (317, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (317, 102);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (318, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (318, 102);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (319, 81);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (319, 102);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (320, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (320, 92);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (321, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (321, 90);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (322, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (322, 90);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (323, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (324, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (324, 91);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (325, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (325, 92);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (326, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (326, 90);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (327, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (327, 90);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (329, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (329, 93);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (330, 78);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (330, 93);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (331, 79);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (331, 92);


#
# TABLE STRUCTURE FOR: shop_product_images
#

DROP TABLE IF EXISTS shop_product_images;

CREATE TABLE `shop_product_images` (
  `product_id` int(11) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `position` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`product_id`,`image_name`),
  KEY `shop_product_images_I_1` (`position`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: shop_product_properties
#

DROP TABLE IF EXISTS shop_product_properties;

CREATE TABLE `shop_product_properties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `csv_name` varchar(50) NOT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `show_in_compare` tinyint(1) DEFAULT NULL,
  `position` int(11) NOT NULL,
  `show_on_site` tinyint(1) DEFAULT NULL,
  `multiple` tinyint(1) DEFAULT NULL,
  `external_id` varchar(255) DEFAULT NULL,
  `show_in_filter` tinyint(1) DEFAULT NULL,
  `main_property` tinyint(1) DEFAULT NULL,
  `show_faq` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_product_properties_I_2` (`active`),
  KEY `shop_product_properties_I_3` (`show_on_site`),
  KEY `shop_product_properties_I_4` (`show_in_compare`),
  KEY `shop_product_properties_I_5` (`position`),
  KEY `shop_product_properties_I_1` (`active`),
  KEY `external_id` (`external_id`)
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (41, 'virobnik', 1, 1, 0, 1, 0, NULL, 1, 0, 0);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (42, 'strichka', 1, 1, 0, 1, 0, NULL, 1, 0, 1);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (43, 'ves', 1, 1, 0, 1, 0, NULL, 1, 0, 1);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (44, 'torg', 1, 1, 0, 1, NULL, NULL, 1, NULL, 1);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (45, 'tovarni', 1, 1, 0, 1, NULL, NULL, 1, 1, 1);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (46, 'gabariti', 1, 1, 0, 1, NULL, NULL, 1, 1, 1);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (47, 'laboratorni', 1, 1, 0, 1, NULL, NULL, 1, 1, 1);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (48, 'fasovka', 1, 1, 0, 1, NULL, NULL, 1, 1, 1);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (49, 'checkodruk', 1, 1, 0, 1, 0, NULL, 1, 1, 1);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (50, 'monorejka', 1, 1, 0, 1, NULL, NULL, 1, 1, 1);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (51, 'paletni', 1, 1, 0, 1, NULL, NULL, 1, 1, 1);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (52, 'rejkovi', 1, 1, 0, 1, NULL, NULL, 1, 1, 1);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (53, 'rokla', 1, 1, 0, 1, NULL, NULL, 1, 1, 1);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (54, 'portativni', 1, 1, 0, 1, NULL, NULL, 1, 1, 1);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (55, 'stacionarni', 1, 1, 0, 1, NULL, NULL, 1, 1, 1);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (56, 'rroksef', 1, 1, 0, 1, NULL, NULL, 1, 1, 1);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (57, 'modemvnutr', 1, 1, 0, 1, NULL, NULL, 1, 1, 1);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (58, 'modemzovnish', 1, 1, 0, 1, NULL, NULL, 1, 1, 1);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (59, 'potujnistUF', 1, 1, 0, 1, 0, NULL, 1, 1, 1);


#
# TABLE STRUCTURE FOR: shop_product_properties_categories
#

DROP TABLE IF EXISTS shop_product_properties_categories;

CREATE TABLE `shop_product_properties_categories` (
  `property_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`property_id`,`category_id`),
  KEY `shop_product_properties_categories_FI_2` (`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 78);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 79);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 80);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 81);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 83);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 90);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 91);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 92);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 93);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 94);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 95);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 96);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 97);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 98);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 99);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 100);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 101);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 102);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 103);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 104);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 105);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 106);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 107);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 108);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (41, 109);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (42, 78);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (42, 79);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (42, 81);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (43, 78);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (44, 78);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (45, 78);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (48, 78);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (49, 78);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (50, 78);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (51, 78);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (52, 78);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (53, 78);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (54, 79);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (55, 79);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (56, 79);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (57, 79);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (58, 79);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (59, 83);


#
# TABLE STRUCTURE FOR: shop_product_properties_data
#

DROP TABLE IF EXISTS shop_product_properties_data;

CREATE TABLE `shop_product_properties_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `property_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `value` varchar(500) NOT NULL,
  `locale` varchar(5) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_product_properties_data_I_1` (`value`(333)),
  KEY `shop_product_properties_data_FI_2` (`product_id`),
  KEY `shop_product_properties_data_FI_1` (`property_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6118 DEFAULT CHARSET=utf8;

INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6083, 41, 196, 'Юнісистем, Київ', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6071, 41, 197, 'Юнісистем, Київ', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6087, 41, 198, 'Юнісистем, Київ', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6089, 41, 199, 'Юнісистем, Київ', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6113, 41, 200, 'Юнісистем, Київ', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6014, 41, 203, 'ДП Компанія Атлас, Київ', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6051, 41, 202, 'ДП Компанія Атлас, Київ', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6016, 41, 204, 'Інфотакс Плюс, Київ', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6099, 41, 254, 'ДП Компанія Атлас, Київ', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6102, 41, 255, 'Юнісистем, Київ', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6034, 41, 206, 'CAS, Південна Корея', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6025, 41, 207, 'CAS, Південна Корея', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6026, 41, 209, 'CAS, Південна Корея', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6053, 41, 210, 'CAS, Південна Корея', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6028, 41, 228, 'DIGI Teraoka Seiko, Японія', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6029, 41, 227, 'CAS, Південна Корея', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6056, 41, 257, 'CAS, Південна Корея', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6067, 41, 258, 'CAS, Південна Корея', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6065, 41, 259, 'JADEVER Scale Co., Ltd, Тайвань', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6037, 41, 260, 'Дозавтомати, Кіровоград', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6117, 41, 261, 'DIGI Teraoka Seiko, Японія', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6068, 41, 262, 'CAS, Південна Корея', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6040, 41, 263, 'JADEVER Scale Co., Ltd, Тайвань', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6109, 41, 264, 'JADEVER Scale Co., Ltd, Тайвань', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6110, 41, 265, 'JADEVER Scale Co., Ltd, Тайвань', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6111, 41, 266, 'JADEVER Scale Co., Ltd, Тайвань', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6075, 41, 201, 'Юнісистем, Київ', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6107, 41, 278, 'ІКС-Техно, Київ', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6049, 41, 279, 'Юнісистем, Київ', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6112, 41, 280, 'Дозавтомати, Кіровоград', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6057, 41, 281, 'Масса-К, Росія', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6115, 41, 256, 'ІКС-Техно, Київ', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6060, 41, 215, 'ДП Компанія Атлас, Київ', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6061, 41, 295, 'DIGI Teraoka Seiko, Японія', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6063, 41, 217, 'Юнісистем, Київ', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6064, 41, 294, 'DIGI Teraoka Seiko, Японія', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6103, 41, 307, 'ІКС-Техно, Київ', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6097, 41, 306, 'Резонанс, Кривий ріг', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6116, 41, 314, 'ДП Компанія Атлас, Київ', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6081, 41, 315, 'ДП Компанія Атлас, Київ', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6079, 41, 320, 'ДП Компанія Атлас, Київ', 'ru');


#
# TABLE STRUCTURE FOR: shop_product_properties_data_i18n
#

DROP TABLE IF EXISTS shop_product_properties_data_i18n;

CREATE TABLE `shop_product_properties_data_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `value` varchar(500) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_product_properties_data_i18n_I_1` (`value`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: shop_product_properties_i18n
#

DROP TABLE IF EXISTS shop_product_properties_i18n;

CREATE TABLE `shop_product_properties_i18n` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `data` text,
  `description` text,
  PRIMARY KEY (`id`,`locale`),
  KEY `shop_product_properties_i18n_I_2` (`name`),
  KEY `shop_product_properties_i18n_I_1` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (41, 'Виробник', 'ru', 'a:12:{i:0;s:28:\"Рома, Запоріжжя\";i:1;s:36:\"Техноінформ, Латвія\";i:2;s:28:\"Юнісистем, Київ\";i:3;s:42:\"ДП Компанія Атлас, Київ\";i:4;s:27:\"ІКС-Техно, Київ\";i:5;s:35:\"Інфотакс Плюс, Київ\";i:6;s:32:\"CAS, Південна Корея\";i:7;s:32:\"DIGI Teraoka Seiko, Японія\";i:8;s:38:\"JADEVER Scale Co., Ltd, Тайвань\";i:9;s:44:\"Дозавтомати, Кіровоград\";i:10;s:25:\"Масса-К, Росія\";i:11;s:37:\"Резонанс, Кривий ріг\";}', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (42, 'Стрічка', 'ru', '', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (43, 'Навантаження', 'ru', 'a:16:{i:0;s:8:\"110 гр\";i:1;s:8:\"210 гр\";i:2;s:8:\"1,5 кг\";i:3;s:6:\"3 кг\";i:4;s:6:\"6 кг\";i:5;s:7:\"15 кг\";i:6;s:7:\"30 кг\";i:7;s:7:\"60 кг\";i:8;s:8:\"150 кг\";i:9;s:8:\"300 кг\";i:10;s:8:\"600 кг\";i:11;s:9:\"1000 кг\";i:12;s:9:\"2000 кг\";i:13;s:9:\"3000 кг\";i:14;s:9:\"5000 кг\";i:15;s:10:\"10000 кг\";}', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (44, 'Торгові', 'ru', '', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (45, 'Товарні', 'ru', '', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (46, 'Габарити', 'ru', '', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (47, 'Лабораторні', 'ru', '', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (48, 'Фасовочні', 'ru', '', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (49, 'Чекодрукуючі', 'ru', '', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (50, 'Монорейкові', 'ru', '', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (51, 'Палетні', 'ru', '', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (52, 'Рейкові', 'ru', '', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (53, 'Ваги-рокла', 'ru', '', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (54, 'Портативні', 'ru', '', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (55, 'Стаціонарні', 'ru', '', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (56, 'РРО з КСЕФ', 'ru', '', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (57, 'Модем внутрішній', 'ru', '', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (58, 'Модем зовнішній', 'ru', '', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (59, 'Потужність УФ', 'ru', '', '');


#
# TABLE STRUCTURE FOR: shop_product_variants
#

DROP TABLE IF EXISTS shop_product_variants;

CREATE TABLE `shop_product_variants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `price` double(20,5) NOT NULL,
  `number` varchar(255) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `mainImage` varchar(255) DEFAULT NULL,
  `smallImage` varchar(255) DEFAULT NULL,
  `external_id` varchar(255) DEFAULT NULL,
  `currency` int(11) DEFAULT NULL,
  `price_in_main` double(20,5) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_product_variants_I_1` (`product_id`),
  KEY `shop_product_variants_I_2` (`position`),
  KEY `shop_product_variants_I_3` (`number`),
  KEY `shop_product_variants_I_5` (`price`),
  KEY `shop_product_variants_I_4` (`price`),
  KEY `shop_product_variants_FI_2` (`currency`),
  KEY `external_id` (`external_id`)
) ENGINE=MyISAM AUTO_INCREMENT=402 DEFAULT CHARSET=utf8;

INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (227, 197, '0.00000', '', 9999999, 0, '29152464_w640_h640_mini500.02_c_gprs.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (226, 196, '6726.00000', '', 999999, 0, '215.jpg', NULL, NULL, 4, '6726.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (228, 198, '6572.00000', '', 9999999, 0, '53635305_w640_h640_3901.jpg', NULL, NULL, 4, '6572.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (229, 199, '6869.00000', '', 999999, 0, '53637832_w640_h640_3911.jpg', NULL, NULL, 4, '6869.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (230, 198, '7085.00000', '', 999999, 1, '53635305_w640_h640_3901.jpg', NULL, NULL, 4, '7085.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (231, 198, '7193.00000', '', 999999, 2, '53635305_w640_h640_3901.jpg', NULL, NULL, 4, '7193.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (233, 199, '7377.00000', '', 999999, 1, '53637832_w640_h640_3911.jpg', NULL, NULL, 4, '7377.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (234, 200, '6048.00000', '', 999999, 0, '0fd2462fb17c38a922aadcd6d3deba62.jpg', NULL, NULL, 4, '6048.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (235, 201, '8202.00000', '', 999999, 0, 'fp54-1-500x500.jpg', NULL, NULL, 4, '8202.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (236, 201, '8683.00000', '', 999999, 1, 'fp54-500x500.jpg', NULL, NULL, 4, '8683.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (237, 201, '9207.00000', '', 999999, 2, 'fp54-500x500.jpg', NULL, NULL, 4, '9207.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (238, 202, '0.00000', '', 999999, 0, '2cdaf704f1d0d3c4c64f36c1cf9a82e3.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (239, 203, '0.00000', '', 999999, 0, '49072404_w640_h640_kasm_junior.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (240, 204, '0.00000', '', 9, 0, '1134231_w640_h640_dmp55.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (241, 205, '2150.00000', '', 999999, 0, '42990539_w640_h640_dw.jpg', NULL, NULL, 4, '2150.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (242, 205, '2150.00000', '', 999999, 1, 'camry_2.jpg', NULL, NULL, 4, '2150.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (243, 206, '0.00000', '', 999999, 0, '668_casberbjuniorbcbu.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (244, 207, '0.00000', '', 999999, 0, '108_418.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (245, 208, '3100.00000', '', 999999, 0, 'camry.jpg', NULL, NULL, 4, '3100.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (246, 209, '0.00000', '', 999999, 0, '_________________4d68ec1335555.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (247, 210, '0.00000', '', 999999, 0, 'b3d7b5f49c380a858ae762e7509a7eb8.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (248, 211, '1750.00000', '', 999999, 0, 'UNIQ-CB35.01-500x500.jpg', NULL, NULL, 4, '1750.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (249, 212, '2180.00000', '', 999999, 0, 'UNIQ-CB41.01-500x500.jpg', NULL, NULL, 4, '2180.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (250, 213, '1750.00000', '', 999999, 0, 'a71956d21eb6da3582ebd06a3e38a213.jpg', NULL, NULL, 4, '1750.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (251, 214, '1950.00000', '', 999999, 0, 'd-ya-mariya-1.jpg', NULL, NULL, 4, '1950.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (252, 215, '0.00000', '', 999999, 0, 'kassovyy-apparat-datecs-neon.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (253, 216, '2530.00000', '', 999999, 0, '466106.jpg', NULL, NULL, 4, '2530.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (254, 217, '0.00000', '', 999999, 0, 'ab2dabcb9252d23fcd69f48ff2c7d253.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (255, 218, '0.00000', '', 999999, 0, '16078256_w640_h640_posiflex_ks67150.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (310, 267, '0.00000', '', 999999, 0, 'b6a9051cc30aa83bfa5013cf7330c300.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (257, 220, '0.00000', '', 999999, 0, 'zebex_z-3010_b.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (258, 221, '0.00000', '', 999999, 0, 'ruchnoy-lazernyy-skaner-zebex-z-3151-hs-.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (259, 222, '0.00000', '', 999999, 0, '3190.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (260, 223, '0.00000', '', 999999, 0, 'e779374f56f322687dedbe697f83b485.JPG', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (262, 224, '0.00000', '', 999999, 0, '3516b67c0924ff1ff0f8eb9c9ae15b02.JPG', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (263, 225, '0.00000', '', 999999, 0, 'axis_A.JPG', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (264, 226, '0.00000', '', 999999, 0, 'ANG-500x500.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (265, 227, '0.00000', '', 999999, 0, '4_3982.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (266, 228, '0.00000', '', 999999, 0, '08e3807076c08131d38d27905b3cee1e.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (267, 229, '0.00000', '', 999999, 0, '84b74577eb05214c86f51dcd722a53b2.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (268, 230, '0.00000', '', 999999, 0, 'Mettler-Toledo-Tiger-3600-Pro-15D-.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (269, 227, '0.00000', '', 999999, 1, '493679_363069_1351676333.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (270, 229, '0.00000', '', 999999, 1, '733753_109773_1351677269.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (271, 231, '0.00000', '', 999999, 0, '586_88.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (272, 232, '0.00000', '', 999999, 0, 'chiper_cpt-8000_big.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (273, 233, '0.00000', '', 999999, 0, 'PT-60-500x500.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (274, 234, '0.00000', '', 999999, 0, 'uns-tp51-3-500x500.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (275, 235, '0.00000', '', 999999, 0, 'tdp-225_a__87341_zoom.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (276, 236, '0.00000', '', 999999, 0, '14249.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (277, 237, '0.00000', '', 999999, 0, 'Zebra_LP2824_Plus.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (278, 238, '0.00000', '', 999999, 0, '1860_6385.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (279, 239, '0.00000', '', 999999, 0, '6-500x500.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (280, 240, '0.00000', '', 999999, 0, 'DMP-55B-500x500.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (281, 241, '380.00000', '', 999999, 0, 'move.jpg', NULL, NULL, 4, '380.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (282, 242, '0.00000', '', 999999, 0, '42252390_w640_h640_spektr5a4m.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (283, 243, '0.00000', '', 999999, 0, 'sp_video_k_big.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (284, 244, '0.00000', '', 999999, 0, 'speed_ld_52a.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (285, 245, '0.00000', '', 999999, 0, 'speed_ld_60_2.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (286, 246, '0.00000', '', 999999, 0, '449138.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (287, 247, '0.00000', '', 999999, 0, '52412213.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (288, 248, '0.00000', '', 999999, 0, 'ba7ea0cbe5c70b837332dacba1b71581.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (289, 249, '0.00000', '', 999999, 0, '0c6205d0f8fd898943ce451cbd062f32.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (290, 250, '1.00000', '', 999999, 0, 'termolente_57_5_mm.jpg', NULL, NULL, 4, '1.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (291, 250, '1.00000', '', 999999, 1, 'termolente_57_5_mm.jpg', NULL, NULL, 4, '1.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (292, 248, '0.00000', '', 999999, 1, '14b87e2edfd7101d317fc14e86e9e213.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (293, 251, '0.00000', '', 999999, 0, '67827f35f657b03065a2cb350cd31ad2.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (294, 252, '0.00000', '', 999999, 0, '367193.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (295, 253, '0.00000', '', 1, 0, '1288_6402.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (296, 254, '6190.00000', '', 999999, 0, '8b9a7b6f34f6d6767158fb6e63c557ae.jpg', NULL, NULL, 4, '6190.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (297, 255, '11200.00000', '', 999999, 0, 'a93da045938f09ab6f182f03319ee070.jpeg', NULL, NULL, 4, '11200.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (298, 256, '5904.00000', '', 999999, 0, 'ICS.jpg', NULL, NULL, 4, '5904.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (299, 257, '0.00000', '', 999999, 0, '1553145976fde87a6d53ccb98258f33a.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (300, 258, '0.00000', '', 999999, 0, '1555.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (301, 259, '0.00000', '', 999999, 0, '052ab282d6987f0e3be22027dd9b2061.JPG', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (302, 260, '1980.00000', '', 999999, 0, '3040_4480.JPG', NULL, NULL, 4, '1980.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (303, 261, '1850.00000', '', 999999, 0, 'a401e4d448451529236cbd20b3e70122.jpg', NULL, NULL, 4, '1850.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (304, 262, '3450.00000', '', 999999, 0, 'sw_w_cas.jpg', NULL, NULL, 4, '3450.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (305, 263, '2460.00000', '', 999999, 0, 'NWTH_Weighing_Scale.jpg', NULL, NULL, 4, '2460.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (306, 263, '0.00000', '', 999999, 1, '068.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (307, 264, '1850.00000', '', 999999, 0, '84d21dfdcd93c931627211cca91ed712.jpg', NULL, NULL, 4, '1850.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (308, 265, '2320.00000', '', 999999, 0, 'ed54e6aa6c7e48fd9c0dd6a9c42bf387.jpg', NULL, NULL, 4, '2320.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (309, 266, '1850.00000', '', 999999, 0, '43870086_w640_h640_image019.jpg', NULL, NULL, 4, '1850.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (311, 268, '0.00000', '', 999999, 0, 'ep50_big-500x500.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (312, 269, '0.00000', '', 999999, 0, 'printer-pechati-chekov-uniq-tp61.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (313, 270, '0.00000', '', 999999, 0, '703301_w640_h640_jo4y3vr3x7.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (314, 271, '0.00000', '', 999999, 0, '0b2682275ff2fabe2c3bc22f81b1a1f2.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (315, 272, '0.00000', '', 999999, 0, 'c071341d0560a2dfe43139f4a08ed803.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (319, 276, '0.00000', '', 999999, 0, '50ecbc00c5762477ab7f6ea89a28d51e.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (318, 275, '0.00000', '', 999999, 0, 'dzwonek-kl-100.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (320, 277, '0.00000', '', 999999, 0, 'aa837615e4ae328b78962aee392aeb07.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (321, 278, '1.00000', '', 999999, 0, '79d9ca18228d63d779f92ca7545610bd.jpg', NULL, NULL, 4, '1.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (322, 279, '11352.00000', '', 999999, 0, '52483130_w640_h640_minifp815.jpg', NULL, NULL, 4, '11352.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (323, 280, '2100.00000', '', 999999, 0, '1.jpg', NULL, NULL, 4, '2100.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (324, 281, '3800.00000', '', 999999, 0, '39d9380c315c8905e46728a5db9be4a6.jpg', NULL, NULL, 4, '3800.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (325, 281, '3800.00000', '', 999999, 1, '92196063d1a90f8db0165cbea5d64e7e.jpg', NULL, NULL, 4, '3800.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (326, 282, '0.00000', '', 999999, 0, 'c127a79a6edc630d7256183bf0acc3a5.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (327, 283, '2600.00000', '', 999999, 0, '5609226d199979e53bac001d31ec3f50.jpg', NULL, NULL, 4, '2600.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (328, 284, '4300.00000', '', 999999, 0, '8011b9158b38a8570cc939db27869cca.jpg', NULL, NULL, 4, '4300.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (329, 285, '0.00000', '', 999999, 0, '015f85649d664f0dcf50f9167a9abf06.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (330, 286, '0.00000', '', 999999, 0, 'dc7688ba638b556284d46d54f13fb36b.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (331, 287, '2130.00000', '', 999999, 0, '26eadfb94b8de8d86392e1afae481965.jpg', NULL, NULL, 4, '2130.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (332, 288, '0.00000', '', 999999, 0, '2d9c5817da35b0387587074e76ca68b0.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (333, 289, '0.00000', '', 999999, 0, '02636fa3f058256e9892d4dfbd4bc269.jpeg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (334, 290, '0.00000', '', 999999, 0, '7ef8ddbb88136c979c668d6cbe89f892.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (335, 291, '0.00000', '', 999999, 0, 'a6ba07e9775c65b4bf254441913c56ce.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (336, 292, '0.00000', '', 999999, 0, 'bbfc71dbe6b3e6a096a013bb01177cc6.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (337, 292, '0.00000', '', 999999, 1, 'fc1d1e50d5b6d868504e9c477efadfbd.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (338, 292, '3900.00000', '', 999999, 2, '7acfdc56635b6ad9ce5e18cbcfcfcea6.jpg', NULL, NULL, 4, '3900.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (339, 292, '0.00000', '', 999999, 3, 'f9fd0d50c0b6b63c91534136c047538c.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (340, 292, '0.00000', '', 999999, 4, '2fe929ad582f978c6027b6e6c623306d.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (341, 292, '0.00000', '', 999999, 5, '70ae6d9201c5df0ab96217deb0a14a2c.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (342, 292, '0.00000', '', 999999, 6, 'e7db5d0808d87068fed9acc632e0579f.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (343, 292, '0.00000', '', 999999, 7, '9201639cba82d417fa39bf22344f27ab.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (344, 292, '0.00000', '', 999999, 8, 'c24fa7a40587b64f046e645b68f649db.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (345, 292, '0.00000', '', 999999, 9, '99acf147ea7409744a3ebfd4ab033c83.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (346, 292, '0.00000', '', 999999, 10, 'ac245eea3019be698cea44a0ddd2f4f3.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (347, 292, '0.00000', '', 999999, 11, '74189d9736efd554b70c4eaa149d1694.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (348, 292, '0.00000', '', 999999, 12, 'e68c320ae85dc0bce8d4dedb8205e799.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (349, 292, '0.00000', '', 999999, 13, 'bbc917b099e2846a9ff559606912a325.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (350, 293, '2580.00000', '', 999999, 0, '3ca7858e2ac1a6dfa052a6338c7a660a.jpg', NULL, NULL, 4, '2580.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (351, 294, '0.00000', '', 999999, 0, 'c8f478d5ee1901cf4655ce8f0f0183e1.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (352, 295, '0.00000', '', 999999, 0, 'b4f37ae48fde322de2e131e8c8957875.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (353, 296, '0.00000', '', 999999, 0, '0305cf6941de5f9d958a53c5c2a564eb.png', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (354, 297, '4200.00000', '', 999999, 0, 'vest_60_s3.jpg', NULL, NULL, 4, '4200.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (355, 298, '4250.00000', '', 999999, 0, 'b28ccb2d21ae67bf0e51b94a8bc5d434.png', NULL, NULL, 4, '4250.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (357, 297, '0.00000', '', 999999, 1, 'vest_a15.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (358, 297, '0.00000', '', 999999, 2, 'vest_60_s3.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (359, 297, '5700.00000', '', 999999, 3, 'vest_a15.jpg', NULL, NULL, 4, '5700.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (360, 297, '0.00000', '', 999999, 4, 'vest_a15.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (363, 299, '0.00000', '', 999999, 0, '0cf98ae928059843d82c8e0e0b1c1825.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (364, 258, '0.00000', '', 999999, 1, 'cas-ad-448.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (365, 300, '0.00000', '', 999999, 0, 'ms9520.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (366, 301, '0.00000', '', 999999, 0, 'ld-60a-500x500.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (367, 302, '0.00000', '', 999999, 0, 'Deko50.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (368, 303, '0.00000', '', 999999, 0, '1828_2644.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (369, 304, '4550.00000', '', 999999, 0, '1d6afd82b9d8fc2edecfac586d6d605b.jpg', NULL, NULL, 4, '4550.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (370, 305, '0.00000', '', 999999, 0, '99b451a2f44130412a1690f4f33baf8c.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (371, 305, '0.00000', '', 999999, 1, 'a8903c7b8db09c04795808f7b444eed6.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (372, 305, '0.00000', '', 999999, 2, '65cfdf388af978e7c4fe88f6b08fa4f5.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (373, 306, '14300.00000', '', 999999, 0, '304_1.jpg', NULL, NULL, 4, '14300.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (374, 307, '14550.00000', '', 999999, 0, '0f28dc76fd65a8c6342ac6edbf13eca5.jpg', NULL, NULL, 4, '14550.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (375, 308, '0.00000', '', 999999, 0, 'Mettler_Toledo_Tiger_NEW.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (376, 309, '12600.00000', '', 999999, 0, '733c5cc298ea8915d2f0106e82db7333.jpg', NULL, NULL, 4, '12600.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (377, 310, '0.00000', '', 999999, 0, '3138537.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (378, 311, '1.00000', '', 999999, 0, 'PA130127.jpg', NULL, NULL, 4, '1.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (379, 311, '1.00000', '', 999999, 1, 'PA130127.jpg', NULL, NULL, 4, '1.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (380, 312, '0.00000', '', 999999, 0, 'PA130125.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (381, 313, '0.00000', '', 999999, 0, 'Preprint2.jpg', NULL, NULL, 4, '0.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (382, 314, '6500.00000', '', 1, 0, '11.jpg', NULL, NULL, 4, '6500.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (384, 315, '17820.00000', '', 1, 0, '88-500x500.jpg', NULL, NULL, 4, '17820.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (385, 316, '1.00000', '', 1, 0, '495399.jpg', NULL, NULL, 4, '1.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (386, 317, '1.00000', '', 1, 0, '8994664c91a08a8c551ae6d5de7d8aa1.jpg', NULL, NULL, 4, '1.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (387, 318, '1.00000', '', 1, 0, '8994664c91a08a8c551ae6d5de7d8aa1.jpg', NULL, NULL, 4, '1.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (388, 319, '1.00000', '', 1, 0, '20-500x500.jpg', NULL, NULL, 4, '1.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (389, 320, '13100.00000', '', 1, 0, 'datecs-fp-320.jpg', NULL, NULL, 4, '13100.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (390, 321, '5661.00000', '', 1, 0, 'e845fb35b9466b8bfcf0d1df790aea61.jpg', NULL, NULL, 4, '5661.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (391, 322, '5715.00000', '', 1, 0, '6fde3771d536320dc5079ca4338388fc.jpg', NULL, NULL, 4, '5715.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (392, 323, '6430.00000', '', 1, 0, '0f25486d9495903acf878215ab28ff5b.jpg', NULL, NULL, 4, '6430.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (393, 324, '5895.00000', '', 1, 0, 'kassovyy-apparat-eksellio-dp-45.jpg', NULL, NULL, 4, '5895.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (394, 325, '8424.00000', '', 1, 0, 'exellio-fpu-550-es-500x500.jpg', NULL, NULL, 4, '8424.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (395, 256, '6536.00000', '', 1, 1, 'ICS.jpg', NULL, NULL, 4, '6536.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (396, 326, '5370.00000', '', 1, 0, '670cb9a05891e62dd708c3c48c07313d.png', NULL, NULL, 4, '5370.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (397, 327, '5200.00000', '', 1, 0, '8e9e8cc31c4f89daf574161835827068.jpg', NULL, NULL, 4, '5200.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (399, 329, '1570.00000', '', 1, 0, '4dd6c14b3d0625a1cc1eaea6f08f76b2.jpg', NULL, NULL, 4, '1570.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (400, 330, '2304.00000', '', 1, 0, '3adbb48b60ac88224b59a081742868a3.jpg', NULL, NULL, 4, '2304.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (401, 331, '13365.00000', '', 1, 0, 'd21d5d021e499a9ddc4383245b6f6541.png', NULL, NULL, 4, '13365.00000');


#
# TABLE STRUCTURE FOR: shop_product_variants_i18n
#

DROP TABLE IF EXISTS shop_product_variants_i18n;

CREATE TABLE `shop_product_variants_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `name` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`,`locale`),
  KEY `shop_product_variants_i18n_I_1` (`name`(333))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (227, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (226, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (228, 'ru', 'РРО MINI-N51.01 EM з КСЕФ');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (229, 'ru', 'РРО MINI-T61.01 EFM з КСЕФ');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (230, 'ru', 'РРО MINI-N51.01 EGM з КСЕФ');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (231, 'ru', 'РРО MINI-N51.01 EGMR з КСЕФ');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (396, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (233, 'ru', 'РРО MINI-T61.01 EFGM з КСЕФ');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (234, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (235, 'ru', 'РРО МІНІ-ФП54.01 Ethernet з КСЕФ');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (236, 'ru', 'РРО МІНІ-ФП54.01 Ethernet+GPRS з КСЕФ');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (237, 'ru', 'РРО МІНІ-ФП54.01 Ethernet+GPRS+Bluetooth з КСЕФ');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (238, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (239, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (240, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (241, 'ru', 'Ваги торгові CAMRY світлодіодні');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (242, 'ru', 'Ваги торгові CAMRY рідкокристалічна');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (243, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (244, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (245, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (246, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (247, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (248, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (249, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (250, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (251, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (252, 'ru', ' РРО NEON Ethernet');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (253, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (254, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (255, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (310, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (257, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (258, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (259, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (260, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (264, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (262, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (263, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (265, 'ru', 'Чекодрукуючі ваги CAS LP фасовочні');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (266, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (267, 'ru', 'Чекодрукуючі ваги ШТРИХ-ПРИНТ фасовочні');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (268, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (269, 'ru', 'Чекодрукуючі ваги CAS LP торгові');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (270, 'ru', 'Чекодрукуючі ваги ШТРИХ-ПРИНТ торгові');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (271, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (272, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (273, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (274, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (275, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (276, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (277, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (278, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (279, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (280, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (281, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (282, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (283, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (284, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (285, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (286, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (287, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (288, 'ru', 'Термострічка 57.5мм 19м');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (289, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (290, 'ru', 'Термострічка 80мм 21м');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (291, 'ru', 'Термострічка 80мм 80м');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (292, 'ru', 'Термострічка 57.5мм 60м');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (293, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (294, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (295, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (296, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (297, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (298, 'ru', 'РРО IKC-M510 Ethernet з КСЕФ');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (299, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (300, 'ru', 'Ваги фасовочні CAS AD');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (301, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (302, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (303, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (304, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (305, 'ru', 'Ваги фасовочні NWTH');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (306, 'ru', 'Ваги фасовочні NWTH (D)');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (307, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (308, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (309, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (311, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (312, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (313, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (314, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (315, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (319, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (318, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (320, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (321, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (322, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (323, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (324, 'ru', 'Ваги торгові МК-ТВ21');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (325, 'ru', 'Ваги торгові МК-ТН21');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (326, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (327, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (328, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (329, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (330, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (331, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (332, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (333, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (334, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (335, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (336, 'ru', 'Ваги лабораторні ТВЕ-12-0,2');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (337, 'ru', 'Ваги лабораторні ТВЕ-12-0,5');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (338, 'ru', 'Ваги лабораторні ТВЕ-24-0,5');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (339, 'ru', 'Ваги лабораторні ТВЕ-30-0,2');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (340, 'ru', 'Ваги лабораторні ТВЕ-30-0,5');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (341, 'ru', 'Ваги лабораторні ТВЕ-50-1');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (342, 'ru', 'Ваги лабораторні ТВЕ-60-1');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (343, 'ru', 'Ваги лабораторні ТВЕ-60-2');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (344, 'ru', 'Ваги лабораторні ТВЕ-120-5');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (345, 'ru', 'Ваги лабораторні ТВЕ-120-2');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (346, 'ru', 'Ваги лабораторні ТВЕ-150-5');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (347, 'ru', 'Ваги лабораторні ТВЕ-300-5');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (348, 'ru', 'Ваги лабораторні ТВЕ-500-10');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (349, 'ru', 'Ваги лабораторні ТВЕ-600-10');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (350, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (351, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (352, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (353, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (354, 'ru', 'Ваги товарні ВЕСТ-150');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (355, 'ru', 'Ваги товарні ЗЕВС ВПЕ-200');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (357, 'ru', 'Ваги товарні ВЕСТ-200');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (358, 'ru', 'Ваги товарні ВЕСТ-250');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (359, 'ru', 'Ваги товарні ВЕСТ-300');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (360, 'ru', 'Ваги товарні ВЕСТ-600');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (363, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (364, 'ru', 'Ваги фасовочні CAS AD-H');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (365, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (366, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (367, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (368, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (369, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (370, 'ru', 'Ваги фасовочні Штрих-Слим 3-0,5');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (371, 'ru', 'Ваги фасовочні Штрих-Слим 6-1');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (372, 'ru', 'Ваги фасовочні Штрих-Слим 15-2/5');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (373, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (374, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (375, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (376, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (377, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (378, 'ru', 'Термоетикетка 58х30 TECO 700шт.');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (379, 'ru', 'Термоетикетка 58х30 TECO');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (380, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (381, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (382, 'ru', 'РРО NEON-W');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (384, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (385, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (386, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (387, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (388, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (389, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (390, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (391, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (392, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (393, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (394, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (395, 'ru', 'РРО IKC-M510 GPRS з КСЕФ');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (397, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (399, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (400, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (401, 'ru', '');


#
# TABLE STRUCTURE FOR: shop_products
#

DROP TABLE IF EXISTS shop_products;

CREATE TABLE `shop_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `hit` tinyint(1) DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `related_products` varchar(255) DEFAULT NULL,
  `mainImage` varchar(255) DEFAULT NULL,
  `smallImage` varchar(255) DEFAULT NULL,
  `created` int(11) NOT NULL,
  `updated` int(11) NOT NULL,
  `old_price` float(10,2) DEFAULT NULL,
  `views` int(11) DEFAULT '0',
  `hot` tinyint(1) DEFAULT NULL,
  `action` tinyint(1) DEFAULT NULL,
  `added_to_cart_count` int(11) DEFAULT NULL,
  `enable_comments` tinyint(1) DEFAULT '1',
  `external_id` varchar(255) DEFAULT NULL,
  `mainModImage` varchar(255) DEFAULT NULL,
  `smallModImage` varchar(255) DEFAULT NULL,
  `tpl` varchar(250) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_products_I_2` (`url`),
  KEY `shop_products_I_3` (`brand_id`),
  KEY `shop_products_I_4` (`category_id`),
  KEY `shop_products_I_1` (`url`),
  KEY `external_id` (`external_id`)
) ENGINE=MyISAM AUTO_INCREMENT=332 DEFAULT CHARSET=utf8;

INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (197, 'rro-mini-50002me', 0, 1, 0, 79, '', NULL, NULL, 1386280800, 1390573142, '0.00', 7, 1, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (196, 'rro-mimi-t400me', NULL, 1, 0, 79, '', NULL, NULL, 1386280800, 1425556029, '0.00', 5, 0, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (198, 'rro-mini-t5101', 1, NULL, 0, 79, '', NULL, NULL, 1386280800, 1430201749, '0.00', 109, 0, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (199, 'rro-mini-t6101', 1, NULL, 0, 79, '', NULL, NULL, 1386280800, 1430202592, '0.00', 115, 0, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (200, 'rro-mini-t400-me-z-ksef', 1, 1, 0, 79, '', NULL, NULL, 1386367200, 1455704948, '0.00', 198, 0, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (201, '201', 1, NULL, 0, 79, '', NULL, NULL, 1386367200, 1390590115, '0.00', 113, 0, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (254, 'fiskalnii-reestrator-datecs-fp-t260', 1, NULL, 0, 79, '', NULL, NULL, 1386885600, 1454068266, '0.00', 38, NULL, 1, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (202, 'rro-datecs-mp-550t', 0, NULL, 0, 79, '', NULL, NULL, 1386712800, 1386968319, '0.00', 7, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (203, 'rro-datecs-mp-50-junior', 0, NULL, 0, 79, '', NULL, NULL, 1386712800, 1386762464, '0.00', 5, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (204, 'rro-eksellio-dmp-55l', 0, NULL, 0, 79, '', NULL, NULL, 1386712800, 1386762510, '0.00', 4, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (205, 'vagi-torgovi-camry', 1, 0, 0, 78, '', NULL, NULL, 1386712800, 1455089394, '0.00', 119, NULL, 1, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (206, 'vagi-torgovi-cas-er-junior', 0, NULL, 0, 78, '', NULL, NULL, 1386712800, 1386960349, '0.00', 81, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (207, 'vagi-tovarni-cas-db-1h', 1, NULL, 0, 78, '', NULL, NULL, 1386712800, 1386959441, '0.00', 151, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (208, 'vagi-tovarni-camry', 1, 1, 0, 78, '', NULL, NULL, 1386712800, 1458122030, '0.00', 200, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (209, 'vagi-torgovi-cas-ap-m', 1, NULL, 0, 78, '', NULL, NULL, 1386712800, 1386959467, '0.00', 94, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (210, 'vagi-torgovi-cas-ap-mlt', 1, NULL, 0, 78, '', NULL, NULL, 1386712800, 1386970752, '0.00', 99, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (211, 'groshova-skrinka-uniq-cb3501', 1, NULL, 0, 81, '', NULL, NULL, 1386712800, 1386780826, NULL, 100, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (212, 'groshova-skrinka-uniq-cb4101', 1, NULL, 0, 81, '', NULL, NULL, 1386712800, 1386782184, '0.00', 98, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (213, 'groshova-skrinka-mini', 1, NULL, 0, 81, '', NULL, NULL, 1386712800, 1386782289, '0.00', 103, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (214, 'groshova-skrinka-hs-410', 1, NULL, 0, 81, '', NULL, NULL, 1386712800, 1386781203, NULL, 109, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (215, 'rro-neon', 0, NULL, 0, 79, '', NULL, NULL, 1386712800, 1387870935, '0.00', 10, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (216, 'groshova-skrinka-hpc-460-ft', 1, NULL, 0, 81, '', NULL, NULL, 1386712800, 1386781526, NULL, 110, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (217, 'pos-terminal-uns-mpos2', 1, NULL, 0, 81, '', NULL, NULL, 1386712800, 1388346655, '0.00', 169, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (218, '218', 0, NULL, 0, 81, '', NULL, NULL, 1386712800, 1386962743, '0.00', 90, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (267, 'zchituvach-magnitnih-kart-posiflex-mr-2000', 1, NULL, 0, 81, '', NULL, NULL, 1386885600, 1386963652, '0.00', 84, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (220, 'ruchnii-skaner-shtrih-koda-zebex-z-3010', 1, NULL, 0, 81, '', NULL, NULL, 1386712800, 1390588180, '0.00', 88, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (221, 'ruchnii-lazernii-skaner-shtrih-kodu-zebex-z-3151hs', 1, NULL, 0, 81, '', NULL, NULL, 1386712800, 1390591947, '0.00', 88, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (222, 'ruchnii-pzs-skaner-shtrih-kodu-z-3190', 1, 1, 0, 81, '', NULL, NULL, 1386712800, 1390588090, '0.00', 142, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (223, 'vagi-laboratorni-elektronni-btu', 1, NULL, 0, 78, '', NULL, NULL, 1386712800, 1386787101, '0.00', 115, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (224, 'vagi-laboratorni-axis-seriyi-a', 1, NULL, 0, 78, '', NULL, NULL, 1386712800, 1386786777, '0.00', 145, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (225, 'vagi-laboratorni-elektronni-axis-seriyi-ad', 1, NULL, 0, 78, '', NULL, NULL, 1386712800, 1386786848, NULL, 120, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (226, 'vagi-analitichni-elektronni-axis-seriyi-angs', 1, NULL, 0, 78, '', NULL, NULL, 1386712800, 1386786969, '0.00', 154, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (227, 'chekodrukuiuchi-vagi-cas-seriyi-lp', 1, NULL, 0, 78, '', NULL, NULL, 1386712800, 1386959515, '0.00', 102, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (228, 'chekodrukuiuchi-vagi-digi-sm-100-i-digi-sm-100plus', 1, NULL, 0, 78, '', NULL, NULL, 1386712800, 1386959498, '0.00', 99, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (229, 'chekodrukuiuchi-vagi-shtrih-print', 1, NULL, 0, 78, '', NULL, NULL, 1386712800, 1386800319, '0.00', 96, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (230, 'chekodrukuiuchi-vagi-mettler-toledo-tiger', 1, NULL, 0, 78, '', NULL, NULL, 1386712800, 1386788165, NULL, 93, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (231, 'terminal-zboru-danih-bitatek-it9000-revo', 1, NULL, 0, 81, '', NULL, NULL, 1386799200, 1390591804, '0.00', 86, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (232, 'terminal-zboru-danih-cipher-cpt-8001-laser', 1, NULL, 0, 81, '', NULL, NULL, 1386799200, 1386800680, NULL, 90, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (233, 'terminal-zboru-danih-argox-pt-60', 1, NULL, 0, 81, '', NULL, NULL, 1386799200, 1386800835, NULL, 76, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (234, 'printer-dlia-druku-chekiv-uns-tp5102', 1, 1, 0, 81, '', NULL, NULL, 1386799200, 1390590264, '0.00', 142, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (235, 'printer-shtrih-kodu-tsc-tdp-225', 1, NULL, 0, 81, '', NULL, NULL, 1386799200, 1386801510, NULL, 94, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (236, 'printer-shtrih-kodu-argox-os-2130d', 1, NULL, 0, 81, '', NULL, NULL, 1386799200, 1386801639, NULL, 86, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (237, 'printer-shtrih-kodu-zebra-lp-2824-plus', 1, NULL, 0, 81, '', NULL, NULL, 1386799200, 1386801827, NULL, 86, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (238, 'odnoriadnii-etiket-pistolet-open-ph', 1, NULL, 0, 81, '', NULL, NULL, 1386799200, 1409653279, '0.00', 85, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (239, 'odnoriadnii-etiket-pistolet-open-m6', 1, NULL, 0, 81, '', NULL, NULL, 1386799200, 1409653303, '0.00', 80, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (240, 'rro-eksellio-dmp-55b', 0, NULL, 0, 79, '', NULL, NULL, 1386799200, 1390587697, '0.00', 4, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (241, 'detektor-valiut-deko-50', 1, NULL, 0, 83, '', NULL, NULL, 1386885600, 1387383697, '0.00', 108, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (242, 'detektor-valiut-spektr-5-a4-m', 1, NULL, 0, 83, '', NULL, NULL, 1386885600, 1386934033, NULL, 88, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (243, 'infrachervonii-detektor-spektr-video-k', 1, NULL, 0, 83, '', NULL, NULL, 1386885600, 1386934702, '0.00', 88, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (244, '244', 1, NULL, 0, 83, '', NULL, NULL, 1386885600, 1390591624, '0.00', 116, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (245, '245', 1, NULL, 0, 83, '', NULL, NULL, 1386885600, 1390591183, '0.00', 110, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (246, 'lichilnik-banknot-magner-75-d', 1, NULL, 0, 83, '', NULL, NULL, 1386885600, 1390591429, '0.00', 92, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (247, 'lichilnik-banknot-magner-35s', 1, NULL, 0, 83, '', NULL, NULL, 1386885600, 1390591244, '0.00', 81, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (248, 'termostrichka-575-mm', 1, NULL, 0, 80, '', NULL, NULL, 1386885600, 1388081740, '0.00', 95, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (249, 'termostrichka-495-mm', 1, NULL, 0, 80, '', NULL, NULL, 1386885600, 1386938022, '0.00', 84, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (250, 'termostrichka-80-mm', 1, NULL, 0, 80, '', NULL, NULL, 1386885600, 1409654404, '0.00', 130, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (251, 'termostrichka-595-mm', 1, NULL, 0, 80, '', NULL, NULL, 1386885600, 1386938330, NULL, 90, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (252, 'termoetiketka-24h14-2000', 1, NULL, 0, 106, '', NULL, NULL, 1386885600, 1388081848, '0.00', 78, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (253, 'termoetiketka-30h20ttor-2000', 1, NULL, 0, 80, '', NULL, NULL, 1386885600, 1386939061, NULL, 75, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (255, 'fiskalnii-reestrator-mini-fp-6', 1, NULL, 0, 79, '', NULL, NULL, 1386885600, 1454073602, '0.00', 27, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (256, 'rro-ikc-m510-z-ksef', 1, 1, 0, 79, '', NULL, NULL, 1386885600, 1457963693, '0.00', 177, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (257, 'vagi-torgoi-cas-er-plus', 1, NULL, 0, 78, '', NULL, NULL, 1386885600, 1386971403, '0.00', 106, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (258, 'vagi-fasovochni-cas-ad', 1, 0, 0, 78, '', NULL, NULL, 1386885600, 1388352903, '0.00', 92, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (259, 'vagi-fasovochni-jadever-jkh', 1, NULL, 0, 78, '', NULL, NULL, 1386885600, 1388352646, '0.00', 105, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (260, 'vagi-fasovochni-vtne', 1, 1, 0, 78, '', NULL, NULL, 1386885600, 1386961035, '0.00', 106, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (261, 'vagi-fasovochni-digi-ds-673', 1, 1, 0, 78, '', NULL, NULL, 1386885600, 1458123721, '0.00', 89, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (262, 'vagi-fasovochni-cas-sw', 1, 0, 0, 78, '', NULL, NULL, 1386885600, 1388353195, '0.00', 164, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (263, 'vagi-fasovochni-nwth', 1, NULL, 0, 78, '', NULL, NULL, 1386885600, 1386961903, '0.00', 97, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (264, 'vagi-torgovi-jpl-n', 1, NULL, 0, 78, '', NULL, NULL, 1386885600, 1455089245, '0.00', 110, 0, 1, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (265, 'vagi-torgovi-jpl-n1', 1, NULL, 0, 78, '', NULL, NULL, 1386885600, 1455089272, '0.00', 91, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (266, 'vagi-torgovi-jpl', 1, NULL, 0, 78, '', NULL, NULL, 1386885600, 1455089345, '0.00', 98, 0, 1, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (268, 'termo-printer-eksellio-ep-50', 1, NULL, 0, 81, '', NULL, NULL, 1386885600, 1386964581, '0.00', 89, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (269, 'termo-printer-uniq-tp61', 1, NULL, 0, 81, '', NULL, NULL, 1386885600, 1386963902, NULL, 87, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (270, 'termo-printer-posiflex-aura-6900', 1, NULL, 0, 81, '', NULL, NULL, 1386885600, 1386964061, NULL, 80, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (271, 'termo-printer-sewoo-lukhan-lk-t200', 1, NULL, 0, 81, '', NULL, NULL, 1386885600, 1386964148, NULL, 91, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (272, 'kuhonnii-dzvinok-sewoo-lukhan-mb-1000', 1, NULL, 0, 81, '', NULL, NULL, 1386885600, 1386964496, '0.00', 109, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (276, 'zchituvach-posiflex-mr-2100', 1, NULL, 0, 81, '', NULL, NULL, 1386885600, 1386964804, NULL, 96, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (275, 'kuhonnii-dzvinok-posiflex-kl-100', 1, NULL, 0, 81, '', NULL, NULL, 1386885600, 1386964691, NULL, 100, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (277, 'zchituvach-posiflex-serii-sd-200', 1, NULL, 0, 81, '', NULL, NULL, 1386885600, 1386964929, NULL, 77, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (278, 'fiskalnii-reestrator-iks-e260t', 1, NULL, 0, 79, '', NULL, NULL, 1386885600, 1454324479, '0.00', 7, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (279, 'fiskalnii-reestrator-mini-fp8101', 1, NULL, 0, 79, '', NULL, NULL, 1386885600, 1386968097, '0.00', 89, 0, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (280, 'vagi-elektronni-vtne', 1, NULL, 0, 78, '', NULL, NULL, 1386885600, 1455089362, '0.00', 102, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (281, 'vagi-torgovi-mk-t', 1, NULL, 0, 78, '', NULL, NULL, 1386885600, 1386971615, '0.00', 137, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (282, 'skaner-shtrihkodiv-honeywell-ms-5145-eclipse', 1, NULL, 0, 81, '', NULL, NULL, 1386972000, 1390592250, '0.00', 85, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (283, 'skaner-shtrihkodiv-vega-v-1030', 1, NULL, 0, 81, '', NULL, NULL, 1386972000, 1387032390, '0.00', 120, NULL, 1, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (284, 'skaner-shtrihkodiv-honeywell-voyager-1200g', 1, NULL, 0, 81, '', NULL, NULL, 1386972000, 1390592031, '0.00', 87, NULL, 1, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (285, 'skaner-shtrihkodiv-honeywell-ms-3580-quantum-usb', 1, NULL, 0, 81, '', NULL, NULL, 1386972000, 1387032941, NULL, 76, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (286, 'skaner-shtrihkodiv-datalogic-magellan-1000i', 1, NULL, 0, 81, '', NULL, NULL, 1386972000, 1390588588, '0.00', 88, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (287, 'skaner-shtrihkodiv-argox-as-8000', 1, 1, 0, 81, '', NULL, NULL, 1386972000, 1390588032, '0.00', 156, NULL, 1, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (288, 'printer-shtrih-kodu-tsc-ttp-246m-p', 1, NULL, 0, 81, '', NULL, NULL, 1386972000, 1387042017, '0.00', 85, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (289, 'printer-shtrih-kodu-termoprinter-zebra-gk-420-d-t', 1, NULL, 0, 81, '', NULL, NULL, 1386972000, 1387042244, NULL, 85, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (290, 'vagi-laboratorni-tve', 1, NULL, 0, 78, '', NULL, NULL, 1386972000, 1387042742, NULL, 81, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (291, 'vagi-analitichni-as-x', 1, NULL, 0, 78, '', NULL, NULL, 1386972000, 1387042875, NULL, 116, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (292, 'vagi-laboratorni-tve-12-150-kg', 1, NULL, 0, 78, '', NULL, NULL, 1386972000, 1387045076, '0.00', 107, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (293, 'vagi-fasovochni-certus-base-svs-i-svsd', 1, NULL, 0, 78, '', NULL, NULL, 1386972000, 1387047534, NULL, 96, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (294, 'vagi-torgovi-digi-ds-788pm', 0, NULL, 0, 78, '', NULL, NULL, 1386972000, 1388352440, '0.00', 72, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (295, 'vagi-fasovochni-digi-ds-708-bm', 0, NULL, 0, 78, '', NULL, NULL, 1386972000, 1387894889, '0.00', 91, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (296, 'vagi-tovarni-jbs-700m', 0, NULL, 0, 78, '', NULL, NULL, 1387058400, 1387094709, NULL, 90, 0, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (297, 'vagi-tovarni-vest-150', 1, NULL, 0, 78, '', NULL, NULL, 1387058400, 1458121440, '0.00', 93, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (298, 'vagi-tovarni-zevs-vpe', 1, 0, 0, 78, '', NULL, NULL, 1387058400, 1458121636, '0.00', 115, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (299, 'vagi-fasovochni-vte-tsentroves-t3b', 0, NULL, 0, 78, '', NULL, NULL, 1387058400, 1387138235, NULL, 93, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (300, 'skaner-shtrihkodiv-honeywell-voyager-ms-9540', 1, 0, 0, 81, '', NULL, NULL, 1387317600, 1390588427, '0.00', 77, NULL, 0, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (301, 'lichilnik-banknot-speed-ld-60a', 1, NULL, 0, 83, '', NULL, NULL, 1387317600, 1390591495, '0.00', 91, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (302, 'detektor-valiut-deko-60', 1, NULL, 0, 83, '', NULL, NULL, 1387317600, 1387383623, NULL, 80, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (303, 'termoetiketka-40h25teco-2000', 1, NULL, 0, 80, '', NULL, NULL, 1387317600, 1387392636, NULL, 79, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (304, 'vagi-tovarni-bdu', 1, NULL, 0, 78, '', NULL, NULL, 1387836000, 1387870301, '0.00', 130, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (305, 'vagi-fasovochni-shtrih-slim', 1, NULL, 0, 78, '', NULL, NULL, 1387836000, 1387871552, '0.00', 88, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (306, 'fiskalnii-reestrator-mariia-304t', 1, NULL, 0, 79, '', NULL, NULL, 1390168800, 1454067815, '0.00', 103, 0, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (307, 'fiskalnii-reestrator-iks-e810t', 1, NULL, 0, 79, '', NULL, NULL, 1390168800, 1454073644, '0.00', 110, 0, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (308, 'vagi-torgovi-mettler-toledo-new', 1, NULL, 0, 78, '', NULL, NULL, 1390428000, 1390463146, '0.00', 80, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (309, 'fiskalnii-reestrator-eksellio-fp2000', 1, NULL, 0, 79, '', NULL, NULL, 1390514400, 1390909019, '0.00', 93, 0, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (310, 'skaner-shtrihkodu-proton-ims-3190', 1, 1, 0, 81, '', NULL, NULL, 1390773600, 1390849486, '0.00', 127, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (311, 'termoetiketka-58h30-teco', 1, NULL, 0, 80, '', NULL, NULL, 1390773600, 1409654374, '0.00', 86, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (312, 'termoetiketka-58h40-eco', 1, NULL, 0, 80, '', NULL, NULL, 1390773600, 1390850423, '0.00', 90, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (313, 'termoetiketka-58h40-pr-eco', 1, NULL, 0, 80, '', NULL, NULL, 1390773600, 1390850333, '0.00', 89, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (314, 'rro-neon-w', 1, NULL, 0, 79, '', NULL, NULL, 1409605200, 1458111863, '0.00', 109, 0, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (315, 'fiskalnii-reestrator-datecs-fp-t88', 1, NULL, 0, 79, '', NULL, NULL, 1409605200, 1416581322, '0.00', 102, 0, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (316, 'etiket-pistolet-open-c20', 1, NULL, 0, 81, '', NULL, NULL, 1409605200, 1409654184, '0.00', 86, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (317, 'etiket-pistolet-blitz-ph', 1, NULL, 0, 81, '', NULL, NULL, 1409605200, 1409653679, '0.00', 75, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (318, 'etiket-pistolet-blitz-m6', 1, NULL, 0, 81, '', NULL, NULL, 1409605200, 1409653609, '0.00', 78, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (319, 'etiket-pistolet-blitz-c20', 1, NULL, 0, 81, '', NULL, NULL, 1409605200, 1409653740, '0.00', 78, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (320, 'fiskalnii-reestrator-datecs-fp-t320', 1, NULL, 0, 79, '', NULL, NULL, 1416520800, 1416581215, '0.00', 101, 0, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (321, 'rro-eksellio-dp-25', 1, 1, 0, 79, '', NULL, NULL, 1425506400, 1429859485, '0.00', 193, 0, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (322, 'rro-eksellio-dp-05', 1, 1, 0, 79, '', NULL, NULL, 1425506400, 1429859465, '0.00', 161, 0, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (323, 'rro-eksellio-dp-35', 1, NULL, 0, 79, '', NULL, NULL, 1425506400, 1429859511, '0.00', 1, 0, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (324, 'rro-eksellio-dp-45', 0, NULL, 0, 79, '', NULL, NULL, 1429822800, 1430203184, '0.00', 88, 0, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (325, 'fiskalnii-reestrator-eksellio-fpu-550es', 1, NULL, 0, 79, '', NULL, NULL, 1429822800, 1454067795, '0.00', 106, 0, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (326, 'rro-mg-v545t', 1, NULL, 0, 79, '', NULL, NULL, 1454018400, 1455798740, '0.00', 28, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (327, 'rro-datecs-mr-01', 1, NULL, 0, 79, '', NULL, NULL, 1454018400, 1455705132, '0.00', 30, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (329, 'vagi-torgovi-vtd-el', 1, NULL, 0, 78, '', NULL, NULL, 1455055200, 1455089557, '0.00', 26, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (330, 'vagi-torgovi-pt', 1, NULL, 0, 78, '', NULL, NULL, 1455055200, 1458125896, '0.00', 22, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (331, 'fiskalnii-reestrator-eksellio-fp700', 1, NULL, 0, 79, '', NULL, NULL, 1457992800, 1458030034, '0.00', 8, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL);


#
# TABLE STRUCTURE FOR: shop_products_i18n
#

DROP TABLE IF EXISTS shop_products_i18n;

CREATE TABLE `shop_products_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `name` varchar(500) NOT NULL,
  `short_description` text,
  `full_description` text,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`locale`),
  KEY `shop_products_i18n_I_1` (`name`(333))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (196, 'ru', 'РРО MINI T400ME', '<p style=\"text-align: justify;\"><span><strong>MINI-T 400МЕ - портативний касовий апарат з можливостями передачі даних по бездротових каналах зв\'язку (GPRS).</strong></span><br /><span>Касовий апарат MINI-T400МЕ має чіткий графічний екран, надійний механізм друку (SEIKO, Японія), клавіатуру з підвищеною зносостійкістю та акумуляторну батарею, що забезпечує тривалу роботу без підключення до електромережі.</span><br /><span>Система команд касового апарату MINI-T 400МЕ максимально наближена до тієї, яка реалізована в MINI-500.02ME.</span><br /><span>Для MINI-T 400МЕ розроблена прикладна програма, яка дозволяє через ПК виконувати настройки і програмування касового апарату (додавати базу товарів, змінювати базові налаштування та ін)</span></p>', '<p><span>Головна особливість касового апарату MINI-T 400МЕ - вбудований GSM / GPRS-модем, що відкриває перед користувачами нові можливості:</span></p>\n<ul>\n<li><span>дистанційно керувати і контролювати роботу касового апарата;</span></li>\n<li><span>приймати безготівкову оплату товарів і послуг пластиковими картами Visa і MasterCard (потрібне підключення зчитувача магнітних карт);</span></li>\n<li><span>приймати миттєві платежі (поповнення рахунків мобільних операторів, оплата послуг провайдерів інтернет, кабельного телебачення та інше).</span></li>\n</ul>\n<p><strong><span>Віддалене управління і контроль</span></strong><br /><span>Касовий апарат MINI-T 400МЕ оснащений вбудованим GSM / GPRS-модемом.</span><br /><span>Підключивши касовий апарат MINI-T 400МЕ до системи видаленого управління і контролю, можна віддалено стежити за станом справ на торгових точках та контролювати їх роботу. Веб-інтерфейс системи простий і зрозумілий, з ним легко і зручно працювати.</span><br /><span>Вбудований GSM / GPRS-модем дозволяє встановити зв\'язок з обліковою системою підприємства, передавати і приймати дані. У фоновому режимі, без участі касира, відбувається оновлення цін на товари та пересилання звітів.</span><span>На комп\'ютер керуючого надходить інформація від касових апаратів: зміст кожного чека, підсумкові дані за зміну та інша інформація.</span><br /><span>Система віддаленого управління і контролю одночасно може обслуговувати десятки і сотні касових апаратів. Вона надійно захищена від втрати інформації і несанкціонованого доступу.</span><br /><strong><span>Функції платіжного термінала</span></strong><br /><span>Завдяки вбудованому GSM / GPRS-модему, касовий апарат MINI-T 400МЕ може виконувати функції платіжного термінала.</span><br /><span>Підключивши до касового апарату MINI-T 400МЕ зовнішній зчитувач магнітних карт, можна приймати безготівкову оплату товарів і послуг картами стандарту Visa і MasterCard.</span><br /><span>Підключивши касовий апарат MINI-T 400МЕ до платіжної системи, можна приймати миттєві платежі та отримувати додатковий дохід - комісійні від провайдерів мобільного зв\'язку, Інтернет, кабельного телебачення та інших послуг.</span><br /><strong><span>Сфери застосування касового апарату MINI-T 400МЕ:</span></strong><br /><span>Касовий апарат MINI-T 400МЕ може використовуватися в якості універсального касового апарату або спеціалізованого - для поштових відділень, автовокзалів, підприємств з оподаткуванням за двома податковими ставками.</span><br /><span>Поштові відділення. На поштових відділеннях зв\'язку касовий апарат MINI-T 400МЕ може виконувати широкий спектр операцій: реєструвати поштові відправлення, електронні повідомлення і телеграми; обслуговувати операції прийому грошових переказів, виплати пенсій, оформлення підписок.</span></p>\n<p><span>Автовокзали та автостанції. Володіючи функцією друку квитків, багажних квитанцій та інших проїзних документів, касовий апарат MINI-T 400МЕ з успіхом може використовуватися на автовокзалах.</span><br /><span>Підприємства з подвійним оподаткуванням.</span><br /><span>Реалізований в MINI-T 400МЕ алгоритм розрахунку другий податок дозволяє використовувати цей касовий апарат як для розрахунку місцевих (наприклад, туристичного збору), так і загальнодержавних податків (таких як збір на обов\'язкове пенсійне страхування). Таким чином, касовий апарат MINI-T 400МЕ може використовуватися у сферах, для яких передбачено подвійне оподаткування (продаж ювелірних виробів, приймання платежів за послуги стільникового мобільного зв\'язку, послуги ломбардів і т.п.).</span></p>\n<p><span>Портативний касовий апарат MINI-T 400МЕ внесений до Державного реєстру РРО і сертифікований відповідно до вимог до радіообладнання.</span></p>\n<p><span>Технічні характеристики</span></p>\n<table style=\"height: 218px; width: 735px;\" border=\"0\" align=\"center\">\n<tbody>\n<tr>\n<td>Тип касового апарату</td>\n<td>портативний</td>\n</tr>\n<tr>\n<td>Версія ПЗ</td>\n<td>4101-1</td>\n</tr>\n<tr>\n<td colspan=\"2\">Функціональні характеристики</td>\n</tr>\n<tr>\n<td>Кількість програмованих товарів</td>\n<td>&nbsp;5120</td>\n</tr>\n<tr>\n<td>Кількість відділів</td>\n<td>64</td>\n</tr>\n<tr>\n<td>Кількість касирів</td>\n<td>8</td>\n</tr>\n<tr>\n<td>Швидкість друку, рядків / с</td>\n<td>8</td>\n</tr>\n<tr>\n<td>Ширина стрічки, мм</td>\n<td>58</td>\n</tr>\n<tr>\n<td>Максимальний діаметр рулону паперу, мм</td>\n<td>40</td>\n</tr>\n</tbody>\n</table>\n<table style=\"height: 146px; width: 737px;\" border=\"0\" align=\"center\">\n<tbody>\n<tr>\n<td>Кількість символів в найменуванні товару</td>\n<td>48</td>\n</tr>\n<tr>\n<td>Символів в рядку</td>\n<td>32</td>\n</tr>\n<tr>\n<td colspan=\"2\">Податкові групи та додаткові збори</td>\n</tr>\n<tr>\n<td>Податкові групи з позитивним підсумком</td>\n<td>5</td>\n</tr>\n<tr>\n<td>Податкові групи з негативним підсумком</td>\n<td>5</td>\n</tr>\n<tr>\n<td>Додаткові збори з позитивним підсумком</td>\n<td>4</td>\n</tr>\n</tbody>\n</table>\n<table style=\"height: 302px; width: 737px;\" border=\"0\" align=\"center\">\n<tbody>\n<tr>\n<td>Додаткові збори з негативним підсумком</td>\n<td>4</td>\n</tr>\n<tr>\n<td colspan=\"2\">Дисплей</td>\n</tr>\n<tr>\n<td>Кількість</td>\n<td>1</td>\n</tr>\n<tr>\n<td>Тип дисплея</td>\n<td>ЖК графічний 128х64 (8 рядків)</td>\n</tr>\n<tr>\n<td>Підсвічування дисплея</td>\n<td>&nbsp;є</td>\n</tr>\n<tr>\n<td>&nbsp;Додатково</td>\n<td>&nbsp;&nbsp;відображення заряду акумулятора, режиму підключення до ПК, необхідність зняття Z-звіту, активації подвійного оподаткування, рівня GSM-сигналу</td>\n</tr>\n<tr>\n<td colspan=\"2\">&nbsp;GPRS-зв\'язок&nbsp;</td>\n</tr>\n<tr>\n<td>&nbsp;Стандарт</td>\n<td>&nbsp;&nbsp;850/900/1800/1900</td>\n</tr>\n<tr>\n<td>&nbsp;Антена</td>\n<td>&nbsp;&nbsp;зовнішня</td>\n</tr>\n<tr>\n<td>&nbsp;Клас GPRS</td>\n<td>&nbsp;12</td>\n</tr>\n<tr>\n<td>&nbsp;Кількість SIM-карт</td>\n<td>&nbsp;2</td>\n</tr>\n</tbody>\n</table>\n<table style=\"height: 302px; width: 735px;\" border=\"0\" align=\"center\">\n<tbody>\n<tr>\n<td>Додаткові збори з негативним підсумком</td>\n<td>4</td>\n</tr>\n<tr>\n<td colspan=\"2\">Дисплей</td>\n</tr>\n<tr>\n<td>Кількість</td>\n<td>1</td>\n</tr>\n<tr>\n<td>Тип дисплея</td>\n<td>ЖК графічний 128х64 (8 рядків)</td>\n</tr>\n<tr>\n<td>Підсвічування дисплея</td>\n<td>&nbsp;є</td>\n</tr>\n<tr>\n<td>&nbsp;Додатково</td>\n<td>&nbsp;&nbsp;відображення заряду акумулятора, режиму підключення до ПК, необхідність зняття Z-звіту, активації подвійного оподаткування, рівня GSM-сигналу</td>\n</tr>\n<tr>\n<td colspan=\"2\">&nbsp;GPRS-зв\'язок&nbsp;</td>\n</tr>\n<tr>\n<td>&nbsp;Стандарт</td>\n<td>&nbsp;&nbsp;850/900/1800/1900</td>\n</tr>\n<tr>\n<td>&nbsp;Антена</td>\n<td>&nbsp;&nbsp;зовнішня</td>\n</tr>\n<tr>\n<td>&nbsp;Клас GPRS</td>\n<td>&nbsp;12</td>\n</tr>\n<tr>\n<td>&nbsp;Кількість SIM-карт</td>\n<td>&nbsp;2</td>\n</tr>\n</tbody>\n</table>\n<table style=\"height: 242px; width: 736px;\" border=\"0\" align=\"center\">\n<tbody>\n<tr>\n<td>Підзарядка акумулятора</td>\n<td>через блок живлення</td>\n</tr>\n<tr>\n<td colspan=\"2\">Інтерфейс</td>\n</tr>\n<tr>\n<td>RS232</td>\n<td>&nbsp;4х</td>\n</tr>\n<tr>\n<td colspan=\"2\">Підключаються зовнішні пристрої</td>\n</tr>\n<tr>\n<td>Сканер</td>\n<td>так</td>\n</tr>\n<tr>\n<td>Ваги</td>\n<td>так</td>\n</tr>\n<tr>\n<td>Платіжний термінал</td>\n<td>так</td>\n</tr>\n<tr>\n<td>Модем</td>\n<td>вбудований</td>\n</tr>\n<tr>\n<td>Грошовий ящик</td>\n<td>немає</td>\n</tr>\n<tr>\n<td>Зчитувач магнітних карт</td>\n<td>так</td>\n</tr>\n</tbody>\n</table>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (197, 'ru', 'РРО MINI 500.02ME', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (198, 'ru', 'РРО MINI-T51.01', '<p><span>Касовий апарат&nbsp;<strong>MINI-T51.01</strong>&nbsp;має контрольну стрічку в електронній формі і відповідає вимогам щодо передачі звітної інформації в податкові служби.</span></p>\n<p><span><strong>Касовий апарат MINI-T51.01</strong>&nbsp;має два канали доступу в інтернет: через вбудований GSM / GPRS-модем і Ethernet-підключення.</span></p>\n<p><span><span class=\"notranslate\">Підключивши MINI-T51 до системи віддаленого управління роботою торгових точок, користувач може отримувати повну інформацію про обсяги продажів товарів і послуг, залишки продукції, грошовому обороті, електронну контрольну стрічку, а також віддалено завантажувати в касу довідник товарів.</span>&nbsp;<span class=\"notranslate\">Всі операції здійснюються в автоматичному режимі, без участі касира.</span></span></p>', '<p><span>Касовий апарат&nbsp;<strong>MINI-T51.01</strong>&nbsp;має контрольну стрічку в електронній формі і відповідає вимогам щодо передачі звітної інформації в податкові служби.</span></p>\n<p><span><strong>Касовий апарат MINI-T51.01</strong>&nbsp;має два канали доступу в інтернет: через вбудований GSM / GPRS-модем і Ethernet-підключення.</span></p>\n<p><span><span class=\"notranslate\">Підключивши MINI-T51 до системи віддаленого управління роботою торгових точок, користувач може отримувати повну інформацію про обсяги продажів товарів і послуг, залишки продукції, грошовому обороті, електронну контрольну стрічку, а також віддалено завантажувати в касу довідник товарів.</span>&nbsp;<span class=\"notranslate\">Всі операції здійснюються в автоматичному режимі, без участі касира.</span></span></p>\n<p><span><span class=\"notranslate\"><strong>Касовий апарат MINI-T51.01</strong>&nbsp;може виконувати функції платіжного POS-терміналу: для безготівкової оплати товарів магнітними картами, а також прийому миттєвих платежів.</span>&nbsp;<span class=\"notranslate\">Він має вбудований зчитувач магнітних карт, опціонально - зчитувач RFID / NFC, SMART-карт.</span></span></p>\n<p><span><strong>Портативний касовий апарат MINI-T51.01</strong>&nbsp;ідеально підходить для виїзної торгівлі і може використовуватися на стаціонарних торгових точках, де немає доступу до електромережі - вбудований літій-полімерний акумулятор забезпечує автономну роботу протягом всього дня.</span></p>\n<p><span><span class=\"notranslate\">Касиру комфортно працювати з&nbsp;<strong>MINI-T51.01</strong>&nbsp;завдяки ергономічному дизайну, легкій вазі, пило-та вологозахищеній силіконової клавіатурі цього апарата.</span>&nbsp;<span class=\"notranslate\">На графічному дисплеї відображається інформація в зручному для читання вигляді.</span></span></p>\n<h4><span><span class=\"notranslate\">Основні характеристики та особливості касового апарату&nbsp;<strong>MINI-T51.01:</strong></span></span></h4>\n<ul>\n<li><span>Контрольна стрічка в електронній формі</span></li>\n<li><span>Надійний механізм термодруку SEIKO (Японія)</span></li>\n<li><span>Висока швидкість друку</span></li>\n<li><span>Графічний дисплей касира</span></li>\n<li><span>Вбудований модем</span></li>\n<li><span>Ethernet-підключення</span></li>\n<li><span>Вбудований зчитувач магнітних карт</span></li>\n<li><span>Легке завантаження паперу</span></li>\n<li><span>Малі габарити і вага</span></li>\n<li><span>Тривалий час автономної роботи</span></li>\n<li><span>Можливість підключення ПК, ваг, сканера штрихкодів, грошового ящика</span></li>\n</ul>\n<h4><span><span class=\"notranslate\">Сфери застосування касового апарату&nbsp;<strong>MINI-T51.01:</strong></span></span></h4>\n<ul>\n<li><span>роздрібна та оптова торгівля</span></li>\n<li><span>стаціонарні та виїзні торгові точки</span></li>\n<li><span>кіоски, магазини</span></li>\n<li><span>аптеки</span></li>\n<li><span>сфера послуг</span></li>\n<li><span>кафе, бари, ресторани</span></li>\n<li><span>відділення поштового зв\'язку</span></li>\n<li><span>автовокзали і автостанції</span></li>\n<li><span>миттєві платежі</span></li>\n</ul>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (199, 'ru', 'РРО MINI-T61.01', '<p><span>Касовий апарат&nbsp;<strong>MINI-T61.01</strong>&nbsp;має контрольну стрічку в електронній формі і відповідає вимогам щодо передачі звітної інформації в податкові служби.</span></p>\n<p><span><strong>Касовий апарат MINI-T61.01</strong>&nbsp;має два канали доступу в інтернет: через вбудований GSM / GPRS-модем і Ethernet-підключення.</span></p>\n<p><span><span class=\"notranslate\">Підключивши&nbsp;<strong>MINI-T61.01</strong>&nbsp;до системи віддаленого управління роботою торгових точок, користувач може отримувати повну інформацію про обсяги продажів товарів і послуг, залишки продукції, грошовому обороті, електронну контрольну стрічку, а також віддалено завантажувати в касу довідник товарів.</span>&nbsp;<span class=\"notranslate\">Всі операції здійснюються в автоматичному режимі, без участі касира.</span></span></p>', '<p><span>Касовий апарат&nbsp;<strong>MINI-T61.01</strong>&nbsp;має контрольну стрічку в електронній формі і відповідає вимогам щодо передачі звітної інформації в податкові служби.</span></p>\n<p><span><strong>Касовий апарат MINI-T61.01</strong>&nbsp;має два канали доступу в інтернет: через вбудований GSM / GPRS-модем і Ethernet-підключення.</span></p>\n<p><span><span class=\"notranslate\">Підключивши&nbsp;<strong>MINI-T61.01</strong>&nbsp;до системи віддаленого управління роботою торгових точок, користувач може отримувати повну інформацію про обсяги продажів товарів і послуг, залишки продукції, грошовому обороті, електронну контрольну стрічку, а також віддалено завантажувати в касу довідник товарів.</span>&nbsp;<span class=\"notranslate\">Всі операції здійснюються в автоматичному режимі, без участі касира.</span></span></p>\n<p><span><span class=\"notranslate\"><strong>Касовий апарат MINI-T61.01</strong>&nbsp;може виконувати функції платіжного POS-терміналу: для безготівкової оплати товарів магнітними картами, а також прийому миттєвих платежів.</span>&nbsp;<span class=\"notranslate\">Він має вбудований зчитувач магнітних карт, опціонально - зчитувач RFID / NFC, SMART-карт.</span></span></p>\n<p><span><span class=\"notranslate\">Зручна ергономічна клавіатура з програмованими клавішами швидкого доступу значно спрощує і прискорює процес продажів.</span>&nbsp;<span class=\"notranslate\">На графічному дисплеї відображається інформація в зручному для читання вигляді.</span>&nbsp;<span class=\"notranslate\">Крім того, касовий апарат оснащений знакосінтезірующіх дисплеєм покупця (2 х 16) з підсвічуванням.</span></span></p>\n<p><span>Касовий апарат займає мало місця і може протягом доби працювати автономно від вбудованого акумулятора.</span></p>\n<h4><span>Основні характеристики та особливості касового апарату MINI-T61.01:</span></h4>\n<ul>\n<li><span>Контрольна стрічка в електронній формі</span></li>\n<li><span>Надійний механізм термодруку SEIKO (Японія)</span></li>\n<li><span>Висока швидкість друку</span></li>\n<li><span>Графічний дисплей касира</span></li>\n<li><span>Вбудований дисплей покупця</span></li>\n<li><span>Вбудований модем</span></li>\n<li><span>Ethernet-порт підключення до інтернет</span></li>\n<li><span>Вбудований зчитувач магнітних карт</span></li>\n<li><span>Легке завантаження паперу</span></li>\n<li><span>База товарів - понад 12 тис. позицій</span></li>\n<li><span>17 програмованих клавіш</span></li>\n<li><span>Тривалий час автономної роботи</span></li>\n<li><span>Можливість підключення ПК, ваг, сканера штрихкодів, грошового ящика</span></li>\n</ul>\n<h4><span>Сфери застосування касового апарату MINI-T61.01:</span></h4>\n<ul>\n<li><span>роздрібна та оптова торгівля</span></li>\n<li><span>стаціонарні та виїзні торгові точки</span></li>\n<li><span>кіоски, магазини</span></li>\n<li><span>аптеки</span></li>\n<li><span>сфера послуг</span></li>\n<li><span>кафе, бари, ресторани</span></li>\n<li><span>відділення поштового зв\'язку</span></li>\n<li><span>автовокзали і автостанції</span></li>\n<li><span>миттєві платежі</span></li>\n</ul>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (200, 'ru', 'РРО MINI T400 ME з КСЕФ', '<p><span><strong>MINI-T 400МЕ - портативний касовий апарат з можливостями передачі даних по бездротових каналах зв\'язку (GPRS).</strong></span><br /><span>Касовий апарат MINI-T400МЕ має чіткий графічний екран, надійний механізм друку (SEIKO, Японія), клавіатуру з підвищеною зносостійкістю та акумуляторну батарею, що забезпечує тривалу роботу без підключення до електромережі.</span><br /><span>Система команд касового апарату MINI-T 400МЕ максимально наближена до тієї, яка реалізована в MINI-500.02ME.</span><br /><span>Для MINI-T 400МЕ розроблена прикладна програма, яка дозволяє через ПК виконувати настройки і програмування касового апарату (додавати базу товарів, змінювати базові налаштування та ін)</span></p>\n<p><span>Головна особливість касового апарату MINI-T 400МЕ - вбудований GSM / GPRS-модем, що відкриває перед користувачами нові можливості:</span></p>', '<p><span><strong>MINI-T 400МЕ - портативний касовий апарат з можливостями передачі даних по бездротових каналах зв\'язку (GPRS).</strong></span><br /><span>Касовий апарат MINI-T400МЕ має чіткий графічний екран, надійний механізм друку (SEIKO, Японія), клавіатуру з підвищеною зносостійкістю та акумуляторну батарею, що забезпечує тривалу роботу без підключення до електромережі.</span><br /><span>Система команд касового апарату MINI-T 400МЕ максимально наближена до тієї, яка реалізована в MINI-500.02ME.</span><br /><span>Для MINI-T 400МЕ розроблена прикладна програма, яка дозволяє через ПК виконувати настройки і програмування касового апарату (додавати базу товарів, змінювати базові налаштування та ін)</span></p>\n<p><span>Головна особливість касового апарату MINI-T 400МЕ - вбудований GSM / GPRS-модем, що відкриває перед користувачами нові можливості:</span></p>\n<p><span><strong><span>Віддалене управління і контроль</span></strong><br /><span>Касовий апарат MINI-T 400МЕ оснащений вбудованим GSM / GPRS-модемом.</span><br /><span>Підключивши касовий апарат MINI-T 400МЕ до системи видаленого управління і контролю, можна віддалено стежити за станом справ на торгових точках та контролювати їх роботу. Веб-інтерфейс системи простий і зрозумілий, з ним легко і зручно працювати.</span><br /><span>Вбудований GSM / GPRS-модем дозволяє встановити зв\'язок з обліковою системою підприємства, передавати і приймати дані. У фоновому режимі, без участі касира, відбувається оновлення цін на товари та пересилання звітів.</span><br /><span>На комп\'ютер керуючого надходить інформація від касових апаратів: зміст кожного чека, підсумкові дані за зміну та інша інформація.</span><br /><span>Система віддаленого управління і контролю одночасно може обслуговувати десятки і сотні касових апаратів. Вона надійно захищена від втрати інформації і несанкціонованого доступу.</span></span></p>\n<p>&nbsp;</p>\n<p><strong><span>Функції платіжного термінала</span></strong><br /><span>Завдяки вбудованому GSM / GPRS-модему, касовий апарат MINI-T 400МЕ може виконувати функції платіжного термінала.</span><br /><span>Підключивши до касового апарату MINI-T 400МЕ зовнішній зчитувач магнітних карт, можна приймати безготівкову оплату товарів і послуг картами стандарту Visa і MasterCard.</span><br /><span>Підключивши касовий апарат MINI-T 400МЕ до платіжної системи, можна приймати миттєві платежі та отримувати додатковий дохід - комісійні від провайдерів мобільного зв\'язку, Інтернет, кабельного телебачення та інших послуг.</span><br /><strong><span>Сфери застосування касового апарату MINI-T 400МЕ:</span></strong><br /><span>Касовий апарат MINI-T 400МЕ може використовуватися в якості універсального касового апарату або спеціалізованого - для поштових відділень, автовокзалів, підприємств з оподаткуванням за двома податковими ставками.</span><br /><span>Поштові відділення. На поштових відділеннях зв\'язку касовий апарат MINI-T 400МЕ може виконувати широкий спектр операцій: реєструвати поштові відправлення, електронні повідомлення і телеграми; обслуговувати операції прийому грошових переказів, виплати пенсій, оформлення підписок.</span><br /><span>Автовокзали та автостанції. Володіючи функцією друку квитків, багажних квитанцій та інших проїзних документів, касовий апарат MINI-T 400МЕ з успіхом може використовуватися на автовокзалах.</span><br /><span>Підприємства з подвійним оподаткуванням.</span><br /><span>Реалізований в MINI-T 400МЕ алгоритм розрахунку другий податок дозволяє використовувати цей касовий апарат як для розрахунку місцевих (наприклад, туристичного збору), так і загальнодержавних податків (таких як збір на обов\'язкове пенсійне страхування). Таким чином, касовий апарат MINI-T 400МЕ може використовуватися у сферах, для яких передбачено подвійне оподаткування (продаж ювелірних виробів, приймання платежів за послуги стільникового мобільного зв\'язку, послуги ломбардів і т.п.).</span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (201, 'ru', 'Фіскальний реєстратор МІНІ-ФП54.01', '<p><span class=\"notranslate\"><strong>Фіскальний реєстратор МІНІ-ФП54.01</strong>&nbsp;має контрольну стрічку в електронній формі (КСЕФ) і відповідає всім вимогам законодавства України до РРО.</span><span>&nbsp;</span><br /><br /><span class=\"notranslate\">Вбудований GSM / GPRS-модем і Ethernet-підключення забезпечують передачу даних по бездротових й провідних каналах зв\'язку.</span><span>&nbsp;</span><br /><br /><span class=\"notranslate\">Фіскальний реєстратор&nbsp;<strong>МІНІ-ФП54.01</strong>&nbsp;відрізняється невеликими розмірами, надійністю, широкими функціональними можливостями і високою швидкістю друку.</span><span>&nbsp;</span></p>', '<p><span class=\"notranslate\"><strong>Фіскальний реєстратор МІНІ-ФП54.01</strong>&nbsp;має контрольну стрічку в електронній формі (КСЕФ) і відповідає всім вимогам законодавства України до РРО.</span><span>&nbsp;</span><br /><br /><span class=\"notranslate\">Вбудований GSM / GPRS-модем і Ethernet-підключення забезпечують передачу даних по бездротових й провідних каналах зв\'язку.</span><span>&nbsp;</span><br /><br /><span class=\"notranslate\">Фіскальний реєстратор&nbsp;<strong>МІНІ-ФП54.01</strong>&nbsp;відрізняється невеликими розмірами, надійністю, широкими функціональними можливостями і високою швидкістю друку.</span><span>&nbsp;</span></p>\n<p><span><span class=\"notranslate\">У фіскальному реєстраторі&nbsp;<strong>МІНІ-ФП54.01</strong>&nbsp;реалізований розрахунок всіх алгоритмів оподаткування, передбачених законами України.</span>&nbsp;<span class=\"notranslate\">Він може використовуватися у всіх сферах торгівлі, в тому числі в ювелірних магазинах і салонах мобільного зв\'язку.</span>&nbsp;<br /><br /><span class=\"notranslate\"><strong>МІНІ-ФП54.01</strong>&nbsp;має вбудовану акумуляторну батарею і вбудований дисплей покупця.</span>&nbsp;<span class=\"notranslate\">Це дає можливість комфортно працювати на невеликих торгових точках і при виїзній торгівлі, коли відсутнє живлення від електромережі і площа робочого місця продавця обмежена.</span>&nbsp;<br /><br /><span class=\"notranslate\">Опціонально&nbsp;<strong>МІНІ-ФП54.01</strong>&nbsp;може мати вбудований зчитувач магнітних карт або RFID / NFC-зчитувач.</span></span></p>\n<h4><span>Сфери застосування фіскального реєстратора МІНІ-ФП54.01:</span></h4>\n<ul>\n<li><span>Роздрібна та оптова торгівля</span></li>\n<li><span>Стаціонарні та виїзні торгові точки</span></li>\n<li><span>Кіоски, магазини</span></li>\n<li><span>Аптеки</span></li>\n<li><span>Сфера послуг</span></li>\n<li><span>Кафе, бари, ресторани</span></li>\n<li><span>Миттєві платежі</span></li>\n</ul>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (202, 'ru', 'РРО Datecs MP-550T', '<p><span>&nbsp;</span><strong><span>Касовий апарат Datecs MP-550T&nbsp;</span></strong><span>призначений для використання у сфері роздрібної торгівлі, громадського харчування та сфери послуг. Наприклад:</span></p>\n<ul>\n<li><span>Міні-і супермаркети;</span></li>\n<li><span>Бутіки;</span></li>\n<li><span>Ломбарди;</span></li>\n<li><span>Ресторани, бари, кафе;</span></li>\n<li><span>Аптеки;</span></li>\n<li><span>Магазини мобільного зв\'язку.</span></li>\n</ul>', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (203, 'ru', 'РРО Datecs MP-50 Junior', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (204, 'ru', 'РРО Екселліо DMP-55L', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (205, 'ru', 'Ваги торгові CAMRY', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (206, 'ru', 'Ваги торгові CAS ER Junior', '<p><span><strong>Торгові ваги CAS ER-Junior</strong>&nbsp;з двома діапазонами зважування, рідко-кристалічним дисплеєм і з вбудованим акумулятором призначені для визначення ваги товару, обчислення його вартості за введеною ціною і&nbsp;відображення результатів на двосторонньому табло.</span></p>\n<p><span><strong>Ососбливості моделі ваг CAS ER-Junior:</strong></span></p>\n<ul>\n<li><span>2 модифікації: базова модель (С) і модель із стійкою (СU).</span></li>\n<li><span>Тривалість роботи від акумулятора збільшена до 180 годин (без підствітки).</span></li>\n<li><span>Підсвічування дисплея.</span></li>\n</ul>\n<ul>\n<li><span>Платформа з нержавіючої сталі.</span></li>\n<li><span>Пряма пам&rsquo;ять на 4 товари.</span></li>\n<li><span>Розрахунок вартості товару.</span></li>\n<li><span>Віднімання маси тари.</span></li>\n<li><span>Підсумовування вартості покупки з декількох товарів і розрахунок здачі.</span></li>\n<li><span>Мембранна клавіатура.</span></li>\n<li><span>Автоматичне відключення живлення при перервах в роботі.</span></li>\n</ul>', '<p><strong>Торгові ваги CAS ER-Junior</strong>&nbsp;з двома діапазонами зважування, рідко-кристалічним дисплеєм і з вбудованим акумулятором призначені для визначення ваги товару, обчислення його вартості за введеною ціною і&nbsp;відображення результатів на двосторонньому табло.</p>\n<p><strong>Ососбливості моделі ваг CAS ER-Junior:</strong></p>\n<ul>\n<li>2 модифікації: базова модель (С) і модель із стійкою (СU).</li>\n<li>Тривалість роботи від акумулятора збільшена до 180 годин (без підствітки).</li>\n<li>Підсвічування дисплея.</li>\n</ul>\n<ul>\n<li>Платформа з нержавіючої сталі.</li>\n<li>Пряма пам&rsquo;ять на 4 товари.</li>\n<li>Розрахунок вартості товару.</li>\n<li>Віднімання маси тари.</li>\n<li>Підсумовування вартості покупки з декількох товарів і розрахунок здачі.</li>\n<li>Мембранна клавіатура.</li>\n<li>Автоматичне відключення живлення при перервах в роботі.</li>\n</ul>\n<p><span><strong>Тенічні характеристики CAS ER-Junior:</strong>&nbsp;</span></p>\n<table border=\"1\" cellspacing=\"1\" cellpadding=\"1\">\n<tbody>\n<tr>\n<td width=\"257\">\n<p align=\"center\"><span><strong>Модель</strong></span></p>\n</td>\n<td colspan=\"3\" valign=\"bottom\" width=\"276\">\n<p align=\"center\"><span><strong>ER-JR E(без стійки)</strong></span></p>\n<p align=\"center\"><span><strong>ER-JR E(зі стійкою)</strong></span></p>\n</td>\n</tr>\n<tr>\n<td width=\"257\">\n<p align=\"center\"><span>Макс. гр. зваж.</span></p>\n</td>\n<td width=\"92\">\n<p lang=\"uk-UA\" align=\"center\"><span>6&nbsp;<span lang=\"ru-RU\">кг</span></span></p>\n</td>\n<td width=\"83\">\n<p lang=\"uk-UA\" align=\"center\"><span><span lang=\"ru-RU\">15 кг</span></span></p>\n</td>\n<td width=\"87\">\n<p lang=\"uk-UA\" align=\"center\"><span><span lang=\"ru-RU\">30 кг</span></span></p>\n</td>\n</tr>\n<tr>\n<td width=\"257\">\n<p lang=\"uk-UA\" align=\"center\"><span>Дискретність</span></p>\n</td>\n<td width=\"92\">\n<p lang=\"ru-RU\" align=\"center\"><span>1г (0..3 кг)</span></p>\n<p lang=\"ru-RU\" align=\"center\"><span>2г (3..6к кг)</span></p>\n</td>\n<td width=\"83\">\n<p lang=\"ru-RU\" align=\"center\"><span>2г (0..6 кг)</span></p>\n<p lang=\"ru-RU\" align=\"center\"><span>5г (6..15 кг)</span></p>\n</td>\n<td width=\"87\">\n<p lang=\"ru-RU\" align=\"center\"><span>5г (0..3 кг)</span></p>\n<p lang=\"ru-RU\" align=\"center\"><span>10г (15..30 кг)</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"257\">\n<p lang=\"uk-UA\" align=\"center\"><span>Вибірка ваги тари</span></p>\n</td>\n<td width=\"92\">\n<p lang=\"ru-RU\" align=\"center\"><span>2,999 кг</span></p>\n</td>\n<td width=\"83\">\n<p lang=\"ru-RU\" align=\"center\"><span>5,998 кг</span></p>\n</td>\n<td width=\"87\">\n<p lang=\"ru-RU\" align=\"center\"><span>14,955 кг</span></p>\n</td>\n</tr>\n</tbody>\n</table>\n<table style=\"height: 240px; width: 542px;\" border=\"0\">\n<tbody>\n<tr>\n<td width=\"49%\"><span>Тип дисплея</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>Рідкокристалічний, двостронній</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Індикатори дисплея (к-ть знаків)</span></td>\n<td valign=\"middle\">\n<p align=\"center\"><span>6&nbsp;(вага) 6 (ціна) 6 (вартість)</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Розміри платформи</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>209х290 мм</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Живлення</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>~240В, 49~51Гц (можливе живлення від батарей)</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Діапазон робочих температур</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>-10&deg;С - +40&deg;С</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Габаритні розміри (ШхДхВ)</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>304 х 324 х 112 (висота зі стійкою 419 мм)</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Вага, кг</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>не більше 3,5</span></p>\n</td>\n</tr>\n</tbody>\n</table>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (207, 'ru', 'Ваги товарні CAS DB-1H', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (208, 'ru', 'Ваги товарні CAMRY', '<p>Клас точності &mdash; середній<br />Якісне виконання на надійність<br />Рідкокристалічний дисплей (LСD)<br />Робота від аккумулятора 500 годин (21 день)<br />Індикація розряду батареї &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br />Ваги внесені в ДержреєстрУкраїни під номером У3289-12 ДСТУ EN 45501</p>\n<p>Дискретність - 50г</p>', '<p>Клас точності &mdash; середній<br />Якісне виконання на надійність<br />Рідкокристалічний дисплей (LСD)<br />Робота від аккумулятора 500 годин (21 день)<br />Індикація розряду батареї &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br />Ваги внесені в ДержреєстрУкраїни під номером У3289-12 ДСТУ EN 45501</p>\n<p>Дискретність - 50г</p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (209, 'ru', 'Ваги торгові CAS AP-M', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (210, 'ru', 'Ваги торгові CAS AP-MLT', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (211, 'ru', 'Грошова скринька UNIQ-CB35.01', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (212, 'ru', 'Грошова скринька UNIQ-CB41.01', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (213, 'ru', 'Грошова скринька Міні', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (214, 'ru', 'Грошова скринька HS-410', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (215, 'ru', ' РРО NEON', '<p><strong>NEON</strong><span>&nbsp;- універсальний контрольно-касовий апарат середнього рівня для торгівлі, сфери послуг, підприємств громадського харчування з можливістю оподаткування двома податковими ставками, в якому наші інженери застосували компонентну базу з найсучаснішими технологіями, що дозволить Вам використовувати його спільно з будь-якою технікою використовуваної в торговому залі, обмінюватися даними з комп\'ютерами та мережами різними способами, працювати ефективніше завдяки високому рівню зручності, функціональності та ергономіки. Багата функціональність, яка дозволяє робити при обслуговуванні клієнтів магазину чи ресторану всі необхідні операції, відповідно до чинних стандартів, що сприяє формуванню правильної фінансової звітності, повністю забезпечуючи цілісність та зберігання інформації. Сучасний ергономічний дизайн, не великі розміри і вбудований акумулятор, дозволять розмістити апарат практично на будь-якому прилавку і комфортно працювати протягом робочого дня.</span></p>', '<p><strong>NEON</strong><span>&nbsp;- універсальний контрольно-касовий апарат середнього рівня для торгівлі, сфери послуг, підприємств громадського харчування з можливістю оподаткування двома податковими ставками, в якому наші інженери застосували компонентну базу з найсучаснішими технологіями, що дозволить Вам використовувати його спільно з будь-якою технікою використовуваної в торговому залі, обмінюватися даними з комп\'ютерами та мережами різними способами, працювати ефективніше завдяки високому рівню зручності, функціональності та ергономіки. Багата функціональність, яка дозволяє робити при обслуговуванні клієнтів магазину чи ресторану всі необхідні операції, відповідно до чинних стандартів, що сприяє формуванню правильної фінансової звітності, повністю забезпечуючи цілісність та зберігання інформації. Сучасний ергономічний дизайн, не великі розміри і вбудований акумулятор, дозволять розмістити апарат практично на будь-якому прилавку і комфортно працювати протягом робочого дня.<br /></span></p>\n<ul>\n<li><strong><span>Переваги NEON</span></strong></li>\n<li><span>Зручне та просте програмування і робота з касовим апаратом</span></li>\n<li><span>8-ми рядковий графічний індикатор (128 Х 64 пікселів) з висновком додаткової інформації та підсвічуванням</span></li>\n<li><span>40-ка клавішна розширена символьно-цифрова клавіатура з 10-ма програмованими клавішами прямого доступу</span></li>\n<li><span>Можливість друку штрих-коду та логотипу в чеку</span></li>\n<li><span>Регулювання висоти шрифту, можливість використання режиму з стислій печаткою інформації для економії витратних матеріалів</span></li>\n<li><span>Швидка і тиха печатку зі швидкістю 12-14 рядків / сек з 32-ма символами в рядку</span></li>\n<li><span>Можливість для клієнтів розрахуватися готівкою, карткою, чеком і в кредит</span></li>\n<li><span>Робота апарату з двома податковими ставками</span></li>\n<li><span>Зручність підключення до персонального комп\'ютера за допомогою порту RS-232 зі швидкістю до 115 200 біт / сек або USB, RS485, оптронного інтерфейсу</span></li>\n<li><span>Інтерфейси для підключення вагів, сканера штрих-коду, грошового ящика</span></li>\n<li><span>Можливість запису і зчитування інформації з флеш карти SD (miniSD, microSD)</span></li>\n<li><span>що розширює можливості передачі інформації</span></li>\n<li><span>Можливість побудови мережі з касових апаратів</span></li>\n<li><span>Можливість підключення зовнішнього GSM модему для обміну даними</span></li>\n<li><span>Потужний акумулятор на 3200 мА * год, що дозволить надрукувати до 4000 чеків на одній зарядці&nbsp;</span></li>\n</ul>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (216, 'ru', 'Грошова скринька HPC-460 FT', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (217, 'ru', 'POS-термінал UNS mPOS2', '<p><strong>UNS mPOS2.01</strong><span>&nbsp;- компактний повнофункціональний&nbsp;</span><strong>POS-термінал</strong><span>&nbsp;з вбудованим GSM / GPRS модемом і безвентиляторною системою охолодження. Призначений для автоматизації спрощеного обліку в магазинах, кафе, барах, аптеках та інших торгових підприємствах.</span></p>', '<p><strong>UNS mPOS2.01</strong><span>&nbsp;- компактний повнофункціональний&nbsp;</span><strong>POS-термінал</strong><span>&nbsp;з вбудованим GSM / GPRS модемом і безвентиляторною системою охолодження. Призначений для автоматизації спрощеного обліку в магазинах, кафе, барах, аптеках та інших торгових підприємствах.</span></p>\n<p><span><strong>POS-термінал UNS mPOS2.01</strong><span>&nbsp;призначений для автоматизації спрощеного обліку на підприємствах сфери торгівлі та послуг. Дозволяє застосовувати різноманітні дисконтні системи та повністю замінює комп\'ютер на робочому місці касира.</span></span></p>\n<p>&nbsp;</p>\n<p>Можливості&nbsp;<strong>POS-терміналу UNS mPOS2.01</strong>:</p>\n<ul>\n<li>Підключення GSM-GPRS модему</li>\n<li>Розмежування прав користувачів</li>\n<li>Редагування бази даних товарів</li>\n<li>Робота з дисконтними програмами</li>\n<li>Пошук товару і відображення залишків</li>\n<li>Робота з ваговими штрихкодами</li>\n<li>Одночасна робота з двома принтерами</li>\n<li>прихід товару</li>\n<li>партійний облік</li>\n<li>Робота з дробовим кількістю товару</li>\n<li>\n<table style=\"height: 395px; width: 798px;\" border=\"0\" cellspacing=\"1\">\n<tbody>\n<tr>\n<td class=\"th\" colspan=\"2\">\n<h4>Процесор</h4>\n</td>\n</tr>\n<tr>\n<td>Тип процесора</td>\n<td>AT91SAM7</td>\n</tr>\n<tr>\n<td>Частота процесора, ГГц</td>\n<td>&mdash;</td>\n</tr>\n<tr>\n<td class=\"th\" colspan=\"2\">\n<h4>Пам\'ять</h4>\n</td>\n</tr>\n<tr>\n<td>Тип</td>\n<td>&mdash;</td>\n</tr>\n<tr>\n<td>Об\'єм пам\'яті, ГБ</td>\n<td>64 КБ</td>\n</tr>\n<tr>\n<td class=\"th\" colspan=\"2\">\n<h4>Пристрій зберігання даних</h4>\n</td>\n</tr>\n<tr>\n<td>Тип диска</td>\n<td>Flash-диск</td>\n</tr>\n<tr>\n<td>Об\'єм диска, ГБ</td>\n<td>0,002 з можливістю розширення до 4 ГБ</td>\n</tr>\n<tr>\n<td class=\"th\" colspan=\"2\">\n<h4>Дисплей</h4>\n</td>\n</tr>\n<tr>\n<td>Екран</td>\n<td>LCD</td>\n</tr>\n<tr>\n<td>Діагональ</td>\n<td>7,5</td>\n</tr>\n<tr>\n<td>Максимальна роздільна здатність</td>\n<td>202 х 32</td>\n</tr>\n<tr>\n<td>Яскравість, лк</td>\n<td>&mdash;</td>\n</tr>\n</tbody>\n</table>\n</li>\n<li>\n<table style=\"height: 418px; width: 797px;\" border=\"0\" cellspacing=\"1\">\n<tbody>\n<tr>\n<td class=\"th\" colspan=\"2\">\n<h4>Експлуатаційні характеристики</h4>\n</td>\n</tr>\n<tr>\n<td>Живлення</td>\n<td>AC адаптер: 15В, 400мА</td>\n</tr>\n<tr>\n<td>Підтримка операційних систем</td>\n<td>CT_OS</td>\n</tr>\n<tr>\n<td class=\"th\" colspan=\"2\">\n<h4>Роз\'єми підключення</h4>\n</td>\n</tr>\n<tr>\n<td>Послідовний порт</td>\n<td>4хRJ-12</td>\n</tr>\n<tr>\n<td>USB-порт</td>\n<td>немає</td>\n</tr>\n<tr>\n<td>PS/2</td>\n<td>1х (клавіатура)</td>\n</tr>\n<tr>\n<td>LAN-порт</td>\n<td>10/100 Мб</td>\n</tr>\n<tr>\n<td class=\"th\" colspan=\"2\">\n<h4>Условия эксплуатации</h4>\n</td>\n</tr>\n<tr>\n<td>Температура</td>\n<td>0&deg;C &hellip; +40&deg;C</td>\n</tr>\n<tr>\n<td>Относительная влажность</td>\n<td>20&ndash;80%</td>\n</tr>\n<tr>\n<td class=\"th\" colspan=\"2\">\n<h4>Фізичні характеристики</h4>\n</td>\n</tr>\n<tr>\n<td>Габаритні розміри (ШхГхВ), мм</td>\n<td>240 х 145 х 225</td>\n</tr>\n<tr>\n<td>Маса, кг</td>\n<td>1,2</td>\n</tr>\n<tr>\n<td>Колір</td>\n<td>білий</td>\n</tr>\n</tbody>\n</table>\n</li>\n</ul>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (218, 'ru', 'POS-термінал Posiflex JIVA KS-6715G', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (267, 'ru', 'Зчитувач магнітних карт Posiflex MR-2000', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (220, 'ru', 'Ручний сканер штрих-коду ZEBEX Z-3010 ', '<p><strong>Ручні контактні (ПЗЗ) сканери штрих-коду</strong><span>&nbsp;зчитують інформацію з маркування товару при повному контакті з поверхнею штрих-коду або на незначній відстані від поверхні.</span></p>', '<p><strong>Ручні контактні (ПЗЗ) сканери штрих-коду</strong><span>&nbsp;зчитують інформацію з маркування товару при повному контакті з поверхнею штрих-коду або на незначній відстані від поверхні.</span></p>\n<p><span><span><strong>Сканер штрих-коду Z-3010</strong>&nbsp;- легка, зручна та надійна модель з дуже низьким електроспоживанням в сплячому режимі, має ергономічний дизайн і може передавати дані в ПК або POS-систему по інтерфейсу USB.&nbsp;Швидкість сканування&nbsp;складає до 100 сканувань в секунду. Успішне зчитування підтверджується включенням відповідного світлодіода і звуковим сигналом з програмованою тональністю.&nbsp;Вбудований декодер дозволяє автоматично розпізнавати і декодувати більшість популярних штрих-кодів.&nbsp;Сканер може передавати дані по кожному з інтерфейсів - RS-232C, емуляції клавіатури і USB.&nbsp;Зміна інтерфейсу передачі даних відбувається шляхом заміни кабелю і перепрограмування сканера.&nbsp;Z-3010 здатний зчитувати штрих-код з дозволом від 0.127мм і з відстані до 20мм.&nbsp;Сканування відбувається при наближенні до штрих-коду або при контакті зі штрих-кодової міткою.</span></span></p>\n<p><strong>Контактний ручний сканер Zebex Z-3010</strong></p>\n<ul>\n<li><span><span><span><span class=\"notranslate\"><span>Змінні кабелі - RS-232, \'розрив клавіатури\', Wand Emulation / USB</span></span></span></span></span></li>\n<li><span><span><span><span class=\"notranslate\"><span>Висока роздільна здатність та швидкість сканування</span></span></span></span></span></li>\n<li><span><span><span><span class=\"notranslate\"><span>Автоматичне розпізнавання всіх популярних штрихових кодів</span></span></span></span></span></li>\n<li><span><span><span><span class=\"notranslate\"><span>Добре помітний світловий індикатор і програмований джерело звукового сигналу</span></span></span></span></span></li>\n<li><span><span><span><span class=\"notranslate\"><span>Довговічні кнопкові перемикачі</span></span></span></span></span></li>\n<li><span><span><span><span class=\"notranslate\"><span>Дуже низьке енергоспоживання</span></span></span></span></span></li>\n<li><span><span><span><span class=\"notranslate\"><span>Корпус з ударостійкого пластику</span></span></span></span></span></li>\n<li><span><span><span><span class=\"notranslate\"><span>Простота і надійність</span></span></span></span></span></li>\n</ul>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (221, 'ru', 'Ручний лазерний сканер штрих-коду Zebex Z-3151HS', '<p><span>Компанія Zebex Ind. представляє новий вдосконалений високошвидкісний ручний лазерний сканер Z-3151HS для зчитування штрихового коду. Модель Zebex Z-3151 прийшла на зміну популярній моделі лазерного сканера штрих-коду Zebex Z-3051. Лазерний сканер штрих-коду Zebex Z-3151 HS, з високою швидкістю сканування - 500 скан / сек, забезпечує найбільш ефективну роботу в порівнянні з іншими ручними сканерами штрих-коду.</span></p>', '<p><span>Компанія Zebex Ind. представляє новий вдосконалений високошвидкісний ручний лазерний сканер Z-3151HS для зчитування штрихового коду. Модель Zebex Z-3151 прийшла на зміну популярній моделі лазерного сканера штрих-коду Zebex Z-3051. Лазерний сканер штрих-коду Zebex Z-3151 HS, з високою швидкістю сканування - 500 скан / сек, забезпечує найбільш ефективну роботу в порівнянні з іншими ручними сканерами штрих-коду.</span></p>\n<p><span>Ця модель має вбудовану технологію Z-скан, що дозволяє зчитувати і декодувати всі популярні одноплоскостние штрих-коди в реальному часі. У сканері штрих-коду Zebex Z-3151 HS застосована лазерна скануюча система Symbol (США), що гарантує точне і швидке сканування, що робить цей сканер неперевершеним за своїми можливостями в порівнянні з аналогічною продукцією конкурентів.</span></p>\n<p><span>Корпус сканера Zebex Z3151 HS виконаний з пластика підвищеної міцності з урахуванням будови долоні, а тримач підставки може приймати різні положення, що забезпечує додаткову зручність використання. Його тригер (кнопка) розрахований на часте використання, що забезпечується підвищеною стійкістю. Оптична система сканера Zebex Z-3151 HS надійно екранована від механічних пошкоджень.</span></p>\n<p><span>Сканер штрих-коду Zebex Z-3151HS легко зчитує всі популярні одномірні штрих-коди як у ручному режимі, так і в автоматичному (перебуваючи на підставці), що може істотно полегшити роботу оператора. Для сигналізації оператору про результати зчитування штрих-коду сканер Zebex Z3151 HS оснащений світлодіодними індикаторами (червоний і зелений) і системою звукового оповіщення. Візуальна і звукова індикація може бути запрограмована користувачем за своїм розсудом.</span></p>\n<p><span>Серія має мультиінтерфейсний разєм і підтримує в одній моделі всі популярні інтерфейси: RS-232, КВ \"розрив клавіатури\", USB. Сканер штрих-коду Zebex Z 3151 добре підходить для будь-якої конструкції касового терміналу. Дана серія ідеально підходить для експлуатації в роздрібних торгових точках, на складах; може бути ефективно використана в сфері логістики, банківській сфері, при керуванні документообігом.</span></p>\n<p><span>Особливості Zebex Z-3151HS:</span></p>\n<ul>\n<li><span>&nbsp;декодує більшість одновимірних штрих-кодів, включаючи GS1 DataBar і PDF 417</span></li>\n<li><span>Чудова якість сканування</span></li>\n<li><span>Технологія Z-SCAN + власної розробки компанії Zebex</span></li>\n<li><span>Міцний і ергономічний корпус</span></li>\n<li><span>мультиінтерфейсним роз\'єм&nbsp;</span>\n<table border=\"0\">\n<tbody>\n<tr>\n<td colspan=\"2\">\n<p><span>Робочі характеристики&nbsp;&nbsp;</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>&nbsp;Джерело світла</span></p>\n</td>\n<td>\n<p><span>&nbsp;Лазерний діод видимого спектру, довжина хвилі 650 нм</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>&nbsp;Мікропроцесор</span></p>\n</td>\n<td>\n<p><span>&nbsp;32-розрядний</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>&nbsp;Глибина поля сканування</span></p>\n</td>\n<td>\n<p><span>&nbsp;35-200 мм (розпізнавання 100% символів коду UPC / EAN, PCS = 90%)</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>&nbsp;Кут сканування</span></p>\n</td>\n<td>\n<p><span>&nbsp;52 &deg;</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>&nbsp;Швидкість сканування</span></p>\n</td>\n<td>\n<p><span>&nbsp;500 скан / с</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>&nbsp;Кут прод. накл. / попер.накл. / скосу</span></p>\n</td>\n<td>\n<p><span>&nbsp;65 &deg; / 30 &deg; / 65 &deg;</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>&nbsp;Мін. ширина штриха</span></p>\n</td>\n<td>\n<p><span>&nbsp;0,125 мм (5 міл) при PCS = 90% (Code 39)</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>&nbsp;Контрастність етикетки</span></p>\n</td>\n<td>\n<p><span>&nbsp;30% при розпізнаванні 100% символів коду UPC / EAN</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>&nbsp;Індикатори (світлодіоди)</span></p>\n</td>\n<td>\n<p><span>&nbsp;Триколірний світлодіод (зелений, червоний і синій)</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>&nbsp;Звуковий сигнал</span></p>\n</td>\n<td>\n<p><span>&nbsp;Програмовані тон і тривалість звукового сигналу</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>&nbsp;Системні інтерфейси</span></p>\n</td>\n<td>\n<p><span>&nbsp;Клавіатура, RS-232, HID USB, USB Virtual COM, Wand</span></p>\n</td>\n</tr>\n<tr>\n<td colspan=\"2\">\n<p><span>&nbsp;Фізичні характеристики&nbsp;</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>&nbsp;Габарити</span></p>\n</td>\n<td>\n<p><span>&nbsp;106,7 &times; 58,0 &times; 155,0 мм (тільки пристрій)</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>&nbsp;Маса</span></p>\n</td>\n<td>\n<p><span>&nbsp;148 г (без тримача)</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>&nbsp;Кабель</span></p>\n</td>\n<td>\n<p><span>&nbsp;Стандартний прямий, 2 м</span></p>\n</td>\n</tr>\n<tr>\n<td colspan=\"2\">\n<p><span>&nbsp;Умови експлуатації</span>&nbsp;</p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>&nbsp;Робоча температура</span></p>\n</td>\n<td>\n<p><span>&nbsp;0 &deg; C - +40 &deg; C (32 &deg; F - 104 &deg; F)</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>&nbsp;Температура зберігання</span></p>\n</td>\n<td>\n<p><span>&nbsp;-20 &deg; C - +60 &deg; C (-4 &deg; F - 140 &deg; F)</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>&nbsp;Вологість</span></p>\n</td>\n<td>\n<p><span>&nbsp;Від. вологість 5-95% (без утворення конденсату)</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>Рівні освітленості</span></p>\n</td>\n<td>\n<p><span>4500 люкс (люмінесцентне)</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>Ударостійкість при падінні</span></p>\n</td>\n<td>\n<p><span>Конструкція допускає падіння з висоти 1м</span></p>\n</td>\n</tr>\n</tbody>\n</table>\n</li>\n</ul>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (222, 'ru', 'Ручний ПЗС-сканер штрих-коду Z-3190', '<p><span><span><span class=\"notranslate\"><span><strong>Z-3190</strong>&nbsp;- вдосконалений ручний ПЗС-сканер зі світлостійкістю 100 000 і міцним корпусом у вигляді пістолета, ідеально відповідний для інтенсивної роботи у важких умовах.</span></span>&nbsp;<span class=\"notranslate\"><span>Завдяки високошвидкісного і точному декодуванню, він здатний оптимізувати ваш бізнес і підвищити ефективність роботи.</span></span></span></span></p>\n<ul>\n<li><span><span><span class=\"notranslate\"><span>Технологія декодування</span>&nbsp;<span><em><strong>Ultrascan</strong></em></span></span></span></span></li>\n<li><span><span><span class=\"notranslate\"><span>32-розрядний мікропроцесор</span></span></span></span></li>\n<li><span><span><span class=\"notranslate\"><span>Можливість декодування штрих-кодів GS1 DataBar</span></span></span></span></li>\n<li><span><span><span class=\"notranslate\"><span>Аналогова технологія захоплення зображення</span></span></span></span></li>\n<li><span><span><span class=\"notranslate\"><span>Витримує падіння з висоти 1,5 м</span></span></span></span></li>\n</ul>', '<p><span><span><span class=\"notranslate\"><span><strong>Z-3190</strong>&nbsp;- вдосконалений ручний ПЗС-сканер зі світлостійкістю 100 000 і міцним корпусом у вигляді пістолета, ідеально відповідний для інтенсивної роботи у важких умовах.</span></span>&nbsp;<span class=\"notranslate\"><span>Завдяки високошвидкісного і точному декодуванню, він здатний оптимізувати ваш бізнес і підвищити ефективність роботи.</span></span></span></span></p>\n<ul>\n<li><span><span><span class=\"notranslate\"><span>Технологія декодування</span>&nbsp;<span><em><strong>Ultrascan</strong></em></span></span></span></span></li>\n<li><span><span><span class=\"notranslate\"><span>32-розрядний мікропроцесор</span></span></span></span></li>\n<li><span><span><span class=\"notranslate\"><span>Можливість декодування штрих-кодів GS1 DataBar</span></span></span></span></li>\n<li><span><span><span class=\"notranslate\"><span>Аналогова технологія захоплення зображення</span></span></span></span></li>\n<li><span><span><span class=\"notranslate\"><span>Витримує падіння з висоти 1,5 м</span></span></span></span></li>\n</ul>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (223, 'ru', ' Ваги лабораторні електронні серії BTU', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (224, 'ru', ' Ваги лабораторні AXIS серії А', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (225, 'ru', ' Ваги лабораторні електронні AXIS серії AD', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (226, 'ru', ' Ваги аналітичні електронні AXIS серії ANG...С', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (227, 'ru', 'Чекодрукуючі ваги CAS серії LP', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (228, 'ru', 'Чекодрукуючі ваги DIGI SM-100 і DIGI SM-100Plus', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (229, 'ru', 'Чекодрукуючі ваги ШТРИХ-ПРИНТ', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (230, 'ru', 'Чекодрукуючі ваги METTLER TOLEDO TIGER', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (231, 'ru', 'Термінал збору даних BitaTek IT9000 Revo', '<p><strong>&nbsp;Термінал збору даних BitaTek IT9000 Revo</strong>&nbsp;- компактний і продуктивний термінал збору даних початкового рівня під управлінням Windows CE.</p>\n<p><strong>&nbsp; &nbsp;Bitatek IT9000 REVO</strong>&nbsp;можна описати так: висока продуктивність в компактному ергономічному корпусі і за оптимальною ціною.</p>', '<p><strong>&nbsp;Термінал збору даних BitaTek IT9000 Revo</strong>&nbsp;- компактний і продуктивний термінал збору даних початкового рівня під управлінням Windows CE.</p>\n<p><strong>&nbsp; &nbsp;Bitatek IT9000 REVO</strong>&nbsp;можна описати так: висока продуктивність в компактному ергономічному корпусі і за оптимальною ціною.</p>\n<p>Зручна і знайома всім операційна система Windows CE5.0, великий обсяг пам\'яті, збільшується з допомогою SD-карт пам\'яті, далекобійний лазерний сканер штрих-коду від Motorola, підтримка інтерфейсів USB, Bluetooth, Wi-Fi і невелика вага - ось основні відмінності даної моделі .</p>\n<p><strong>&nbsp; Термінал збору даних Bitatek IT9000</strong>&nbsp;може оснащуватися акумулятором ємністю 1100 mAh (близько 8:00 автономної роботи), а можна замовити з акумулятором збільшеної ємності 2000 mAh (опція).</p>\n<p>ТСД IT9000 REVO відповідає класу захисту від пилу і вологи IP54. Термінал має корпус з удароміцного пластика, витримує падіння з висоти 120 см на бетон і працює при температурах від-10С.</p>\n<p><strong>Особливості:</strong></p>\n<ul>\n<li>Продуктивний сканер штрихкодів Motorola SE955</li>\n<li>Операційна система Windows CE.</li>\n<li>Можливість вибору комунікаційних можливостей терміналу (синхронізація даних через USB-кабель або за допомогою бездротових інтерфейсів).</li>\n<li>Ергономічність. Термінал компактний, зручно розташовується в руці. Функціональні клавіші - великі, з чітким пружним натисканням.</li>\n<li>Термінал виконаний з високоякісного удароміцного пластика.</li>\n<li>ТСД Bitetek IT9000 Revo надзвичайно легкий - всього 170г.</li>\n</ul>\n<p>У стандартну комплектацію входить все необхідне для роботи: термінал, 1 акумулятор (1100mAh), блок живлення з кабелем (EU), USB кабель (Y-Cable), стилус, диск з SDK і документацією, а також базове прикладне програмне забезпечення \"ЕТС склад \",\" ЕТС інвентаризація \".</p>\n<table border=\"1\" cellspacing=\"0\" cellpadding=\"0\">\n<tbody>\n<tr>\n<td width=\"307\">\n<p><strong>роцесор</strong></p>\n</td>\n<td>\n<p>Intel PXA270 312Mhz</p>\n</td>\n</tr>\n<tr>\n<td width=\"307\">\n<p><strong>Об\'єм пам\'яті</strong></p>\n</td>\n<td>\n<p>64Mb/64Mb Flash, слот для MicroSD (до 2Gb)</p>\n</td>\n</tr>\n<tr>\n<td width=\"307\">\n<p><strong>Дисплей</strong></p>\n</td>\n<td>\n<p>2.4&rdquo; TFT QVGA (240x320) кольоровий, сенсорний, з підсвіткою</p>\n</td>\n</tr>\n<tr>\n<td width=\"307\">\n<p><strong>Сканер штрих-кода</strong></p>\n</td>\n<td>\n<p>Лазерний (Motorola SE955)</p>\n</td>\n</tr>\n<tr>\n<td width=\"307\">\n<p><strong>Штрих-коди</strong></p>\n</td>\n<td>\n<p>Всі стандартні лінійні штри-коди</p>\n</td>\n</tr>\n<tr>\n<td width=\"307\">\n<p><strong>Інтерфейси</strong></p>\n</td>\n<td>\n<p>USB, Wi-Fi (802.11 b/g, WPA и WPA2, Cisco), BlueTooth (Class 2, 10 м)</p>\n</td>\n</tr>\n<tr>\n<td width=\"307\">\n<p><strong>Операційна система</strong></p>\n</td>\n<td>\n<p>Windows CE 5.0 Professional, SDK&nbsp;</p>\n</td>\n</tr>\n<tr>\n<td width=\"307\">\n<p><strong>Клас захисту</strong></p>\n</td>\n<td>\n<p>IP54 по захисту від вологи та пилу<br />Витримує падіння з 1,2 м на бетон</p>\n</td>\n</tr>\n<tr>\n<td width=\"307\">\n<p><strong>Розміри</strong></p>\n</td>\n<td>\n<p>135 x 50 x 25 мм</p>\n</td>\n</tr>\n<tr>\n<td width=\"307\">\n<p><strong>Вага</strong></p>\n</td>\n<td>\n<p>170 гр (з стандартним акумулятором 1100 mAh)<br />190 гр (з акумулятором підвищеної ємності 2000 mAh)</p>\n</td>\n</tr>\n<tr>\n<td width=\"307\">\n<p><strong>Робоча температура</strong></p>\n</td>\n<td>\n<p>От &ndash;10&deg; C до 50&deg; C</p>\n</td>\n</tr>\n</tbody>\n</table>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (232, 'ru', 'Термінал збору даних CIPHER CPT-8001 LASER', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (233, 'ru', 'Термінал збору даних Argox PT-60', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (234, 'ru', ' Принтер для друку чеків UNS-TP51.02', '<p><span>Портативний</span><strong>&nbsp;чековий принтер UNIQ-TP51.02</strong><span>&nbsp;являє собою POS-принтер економкласу. Відрізняється високою якістю друку тексту та графіки, підтримує друк штрихкодів. Ширина паперу 58 мм. Інтерфейси: RS232 або USB.</span></p>', '<p><span>Портативний</span><strong>&nbsp;чековий принтер UNIQ-TP51.02</strong><span>&nbsp;являє собою POS-принтер економкласу. Відрізняється високою якістю друку тексту та графіки, підтримує друк штрихкодів. Ширина паперу 58 мм. Інтерфейси: RS232 або USB.</span></p>\n<div><strong>UNIQ-TP51.02</strong>&nbsp;має компактні розміри і невелику вагу і рекомендований для використання на підприємствах дрібної та середньої роздрібної торгівлі, де потрібно друкувати чеки, текстову або графічну інформацію. Принтер сумісний з різними операційними системами.</div>\n<div>&nbsp;</div>\n<div>В залежності від потреб клієнтів, чековий принтер може поставлятися з інтерфейсом USB або RS232.</div>\n<div>&nbsp;</div>\n<div>Конструкція принтера UNIQ-TP51.02 дозволяє швидко і зручно робити заміну паперу.</div>\n<div>&nbsp;</div>\n<div><strong>Основні характеристики і особливості портативного принтера UNIQ-TP51.02:</strong></div>\n<ul>\n<li>Принтер має компактні розміри і характеризується низьким рівнем шуму і високою надійністю</li>\n<li>Висока якість друку (8 точок / мм) дозволяє друкувати текстову і графічну інформацію з великим ступенем деталізації</li>\n<li>Підтримка друку штрихкодів дає можливість використовувати принтер в спеціалізованих сферах застосування: складському обліку, логістики, мерчандайзингу та ін</li>\n<li>Легке завантаження паперу і великий діаметр рулону скорочують час, необхідний касиру для заміни паперу</li>\n<li>Наявність порту RJ45 розширює сфери застосування UNIQ-TP51.02, дозволяючи підключати додаткові периферійні пристрої, такі як грошовий ящик, кухонний дзвінок та інші</li>\n<li>Драйвери термопринтера забезпечують його сумісність з операційними системами Windows 98, 2000, 2003, XP, Vista, Seven</li>\n</ul>\n<div><strong>Сфери застосування UNIQ-TP51.02:</strong></div>\n<ul>\n<li>Підприємства торгівлі</li>\n<li>Відділення поштового зв\'язку</li>\n<li>Ресторани, кафе, бари</li>\n<li>Банки</li>\n<li>Медицина</li>\n<li>Виїзна торгівля</li>\n<li>Мерчандайзинг</li>\n<li>Складський облік</li>\n<li>Логістика</li>\n</ul>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (235, 'ru', 'Принтер штрих-коду TSC TDP-225', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (236, 'ru', 'Принтер штрих-коду Argox OS 2130D', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (237, 'ru', 'Принтер штрих-коду ZEBRA LP 2824 Plus', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (238, 'ru', 'Етикет-пістолет Open PH', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (239, 'ru', 'Етикет-пістолет Open M6', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (240, 'ru', 'РРО Екселліо DMP-55B', '<p lang=\"uk-UA\" align=\"JUSTIFY\"><span><span><span><span><span><strong>&laquo;Екселліо&nbsp;</strong></span></span></span></span><span><span><span><span lang=\"en-US\"><span><strong>DMP</strong></span></span></span></span></span><span><span><span><span><strong>-55</strong></span></span></span></span><span><span><span><span lang=\"en-US\"><span><strong>B</strong></span></span></span></span></span><span><span><span><span><strong>&raquo;</strong></span></span></span></span><span><span><span>&nbsp;&ndash; портативний касовий апарат для застосування на стаціонарних торгівельних об&rsquo;єктах. При виробництві застосовуються високоякісні матеріали, що гарантує необхідну надійність та довговічність під час експлуатації. При цьому функціональні можливості касового апарата не менш вражаючі і включають в себе останні технологічні досягнення які забезпечують максимальну комфортність та зручність у використанні.</span></span></span></span></p>\n<p lang=\"uk-UA\" align=\"JUSTIFY\"><span>Виробництво касового апарата сертифіковано відповідно стандартів&nbsp;</span><span><span lang=\"en-US\"><strong>ISO</strong></span></span><span><strong>&nbsp;9001:2000</strong></span><span>, що гарантує контроль всіх етапів цього процесу та належну якість продукції. Обладнання внесено до Державного реєстру реєстраторів розрахункових операцій.</span></p>', '<p lang=\"uk-UA\" align=\"JUSTIFY\"><span><span><span><span><span><strong>&laquo;Екселліо&nbsp;</strong></span></span></span></span><span><span><span><span lang=\"en-US\"><span><strong>DMP</strong></span></span></span></span></span><span><span><span><span><strong>-55</strong></span></span></span></span><span><span><span><span lang=\"en-US\"><span><strong>B</strong></span></span></span></span></span><span><span><span><span><strong>&raquo;</strong></span></span></span></span><span><span><span>&nbsp;&ndash; портативний касовий апарат для застосування на стаціонарних торгівельних об&rsquo;єктах. При виробництві застосовуються високоякісні матеріали, що гарантує необхідну надійність та довговічність під час експлуатації. При цьому функціональні можливості касового апарата не менш вражаючі і включають в себе останні технологічні досягнення які забезпечують максимальну комфортність та зручність у використанні.</span></span></span></span></p>\n<p lang=\"uk-UA\" align=\"JUSTIFY\"><span>Виробництво касового апарата сертифіковано відповідно стандартів&nbsp;</span><span><span lang=\"en-US\"><strong>ISO</strong></span></span><span><strong>&nbsp;9001:2000</strong></span><span>, що гарантує контроль всіх етапів цього процесу та належну якість продукції. Обладнання внесено до Державного реєстру реєстраторів розрахункових операцій.</span></p>\n<p lang=\"uk-UA\" align=\"JUSTIFY\"><span><span>Клавіатура&nbsp;</span><span><span><span><strong>&laquo;Екселліо&nbsp;</strong></span></span></span><span><span><span lang=\"en-US\"><span><strong>DMP</strong></span></span></span></span><span><span><span><strong>-55</strong></span></span></span><span><span><span lang=\"en-US\"><span><strong>B</strong></span></span></span></span><span><span><span><strong>&raquo;</strong></span></span></span><span>&nbsp;виробництва японської фірми&nbsp;</span><span><span><span lang=\"en-US\">CITIZEN</span></span></span><span>&nbsp;являє собою унікальне поєднання чудової ергономіки та витонченого сучасного дизайну. Клавіші клавіатури чітко та легко фіксують натискання, що зі зручною розкладкою дозволяє невимушено та комфортно працювати.</span></span></p>\n<p lang=\"uk-UA\" align=\"JUSTIFY\">&nbsp;</p>\n<p lang=\"uk-UA\" align=\"JUSTIFY\"><span><span><span>В апарат встановлено двостроковий буквено-цифровий дисплей, який забезпечить Вам наглядне відображення назви товару, що значно спрощує програмування апарата та допомагає касирові не помилятися при відпуску товару. Нова функція &ndash;&nbsp;</span></span><span><span><span><strong>підсвітка індикатора</strong></span></span></span><span><span>&nbsp;&ndash; дозволить працювати в недостатньо освітлених місцях.</span></span></span></p>\n<ul>\n<li>\n<p lang=\"uk-UA\" align=\"JUSTIFY\"><span><span><span><strong>Принтер.</strong></span></span></span></p>\n</li>\n</ul>\n<p lang=\"uk-UA\" align=\"JUSTIFY\"><span><span><span>Принтер японської фірми&nbsp;</span></span><span><span><span lang=\"en-US\"><em>CITIZEN</em></span></span></span><span><span><em>&nbsp;&laquo;MLT-288HL&raquo;</em></span></span><span><span>&nbsp;забезпечує безшумний та якісний друк. Такий механізм, зарекомендувавши себе з найкращої сторони, масово використовується на ринку України. В порівнянні зі звичайним метражем стрічки, можливість застосовувати стрічку 60м призводить до значної</span></span><span><span>економії коштів та часу. Швидкість друку &ndash; 12 рядків за секунду.</span></span></span></p>\n<ul>\n<li>\n<p lang=\"uk-UA\" align=\"JUSTIFY\"><span><span><span><strong>Акумулятор.</strong></span></span></span></p>\n</li>\n</ul>\n<p lang=\"uk-UA\" align=\"JUSTIFY\"><span><span><span>Апарат оснащений акумулятором Li-ion 7,4 В, ємкістю 2000 мA</span></span><span><span></span></span><span><span>год, що дозволяє роздруковувати до 30&nbsp;000 рядків без його перезарядки.</span></span></span></p>\n<p lang=\"uk-UA\"><span><a name=\"OLE_LINK1\"></a><span><span><em><span><strong>Підключення:</strong></span></em></span></span></span></p>\n<p lang=\"uk-UA\">&nbsp;</p>\n<p lang=\"uk-UA\" align=\"JUSTIFY\"><span><span><span>РРО&nbsp;</span></span><span><span><span><strong>&laquo;Екселліо&nbsp;</strong></span></span></span><span><span><span lang=\"en-US\"><span><strong>DMP</strong></span></span></span></span><span><span><span><strong>-55</strong></span></span></span><span><span><span lang=\"en-US\"><span><strong>B</strong></span></span></span></span><span><span><span><strong>&raquo;</strong></span></span></span><span><span>&nbsp;має можливість підключення таких пристроїв, що забезпечує швидкий та простий доступ до інформації:</span></span></span></p>\n<p lang=\"uk-UA\" align=\"JUSTIFY\">&nbsp;</p>\n<div id=\"Раздел1\" dir=\"LTR\">\n<ul>\n<li>\n<p lang=\"uk-UA\" align=\"JUSTIFY\"><span><span><span><span lang=\"en-US\"><strong>GPRS</strong></span></span></span><span><span><strong>&nbsp;модем</strong></span></span></span></p>\n</li>\n</ul>\n<p lang=\"uk-UA\" align=\"JUSTIFY\"><br /><span><span><span>Для РРО&nbsp;</span></span><span><span><span><strong>&laquo;Екселліо&nbsp;</strong></span></span></span><span><span><span lang=\"en-US\"><span><strong>DMP</strong></span></span></span></span><span><span><span><strong>-55</strong></span></span></span><span><span><span lang=\"en-US\"><span><strong>B</strong></span></span></span></span><span><span><span><strong>&raquo;</strong></span></span></span><span><span>&nbsp;створено спеціальний модем</span></span><span><span>&nbsp;для роботи по&nbsp;</span></span><span><span><span lang=\"en-US\">GSM</span></span></span><span><span><span lang=\"ru-RU\">/</span></span></span><span><span><span lang=\"en-US\">GPRS</span></span></span><span><span>&nbsp;каналу зв&rsquo;язку.</span></span></span></p>\n<p lang=\"uk-UA\" align=\"JUSTIFY\">&nbsp;</p>\n<p lang=\"\" align=\"JUSTIFY\"><span>Таке рішення дозволяє забезпечити віддалений зв\'язок центрального офісу з касовими апаратами торгових підприємств не тільки по всій країні, але й по всьому світу. Ця технологія дозволяє програмувати та зчитувати інформацію з апаратів, і таким чином, одержувати оперативні дані.</span></p>\n<ul>\n<li>\n<p lang=\"uk-UA\" align=\"JUSTIFY\"><span><span><span><strong>ПК</strong></span></span></span></p>\n</li>\n</ul>\n<p lang=\"uk-UA\" align=\"JUSTIFY\"><span><span><span>Підключення апарата&nbsp;</span></span><span><span><span><strong>&laquo;Екселліо&nbsp;</strong></span></span></span><span><span><span lang=\"en-US\"><span><strong>DMP</strong></span></span></span></span><span><span><span><strong>-55</strong></span></span></span><span><span><span lang=\"en-US\"><span><strong>B</strong></span></span></span></span><span><span><span><strong>&raquo;</strong></span></span></span><span><span>&nbsp;до персонального комп&rsquo;ютера забезпечує комфорт при програмуванні та роботі з РРО.</span></span></span></p>\n<ul>\n<li>\n<p lang=\"uk-UA\" align=\"JUSTIFY\"><span><span><span><strong>Ваги</strong></span></span></span></p>\n</li>\n</ul>\n<p lang=\"uk-UA\"><span><img src=\"http://exellio.com.ua/images/DMP-55B_html_m68e3d793.jpg\" alt=\"\" name=\"Графический объект4\" width=\"72\" height=\"57\" align=\"LEFT\" border=\"0\" hspace=\"12\" /></span></p>\n<p lang=\"uk-UA\" align=\"JUSTIFY\"><span><span>Уникнення помилок та максимально швидке обслуговування клієнтів забезпечить підключення&nbsp;</span></span></p>\n<p lang=\"uk-UA\"><span><span><span><span><strong>&laquo;Екселліо&nbsp;</strong></span></span></span><span><span><span lang=\"en-US\"><span><strong>DMP</strong></span></span></span></span><span><span><span><strong>-55</strong></span></span></span><span><span><span lang=\"en-US\"><span><strong>B</strong></span></span></span></span><span><span><span><strong>&raquo;</strong></span></span></span><span><span>&nbsp;до ваг.</span></span></span></p>\n<p lang=\"uk-UA\" align=\"JUSTIFY\">&nbsp;</p>\n<ul>\n<li>\n<p lang=\"uk-UA\" align=\"JUSTIFY\"><span><span><span><strong>Сканер</strong></span></span></span></p>\n</li>\n</ul>\n<p lang=\"uk-UA\" align=\"JUSTIFY\"><span><span>До апарата можливо підключити практично будь-який сканер, що максимально прискорює процес відпуску товару та робить безпомилковою роботу оператора.</span></span></p>\n</div>\n<div id=\"Раздел2\" dir=\"LTR\">\n<p align=\"JUSTIFY\"><span>Із врахуванням всієї функціональності, апарат можна назвати&nbsp;</span><span><span><span>&laquo;розумним помічником&raquo;</span></span></span><span>&nbsp; в самому позитивному значенні.</span></p>\n<p lang=\"uk-UA\">&nbsp;</p>\n<p lang=\"uk-UA\" align=\"CENTER\"><span><span><span><em><span><strong>Технічні характеристики &laquo;Екселліо&nbsp;</strong></span></em></span></span><span><span><span lang=\"en-US\"><em><span><strong>DMP</strong></span></em></span></span></span><span><span><em><span><strong>-55</strong></span></em></span></span><span><span><span lang=\"en-US\"><em><span><strong>B</strong></span></em></span></span></span><span><span><em><span><strong>&raquo;.</strong></span></em></span></span></span></p>\n<p lang=\"uk-UA\">&nbsp;</p>\n</div>\n<table style=\"width: 471px;\" border=\"1\" cellspacing=\"2\" cellpadding=\"2\" align=\"center\">\n<tbody>\n<tr>\n<td>\n<p><span>Назва параметра</span></p>\n</td>\n<td>\n<p><span>Значення параметра</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>Кількість програмованих товарів (послуг)</span></p>\n</td>\n<td>\n<p><span>&ndash;&nbsp;5000</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>Найменування товарів</span></p>\n</td>\n<td>\n<p><span>&ndash;&nbsp;22 знаки</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>Ціна товару</span></p>\n</td>\n<td>\n<p><span>&ndash;&nbsp;8 розрядів</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>Кількість груп товарів, що оподатковуються:</span></p>\n<p><span>&ndash;&nbsp;з додатним підсумком розрахунків;</span></p>\n<p><span>&ndash;&nbsp;з від`ємним підсумком розрахунків</span></p>\n</td>\n<td>\n<p>&nbsp;</p>\n<p><span>&ndash;&nbsp;5</span></p>\n<p><span>&ndash;&nbsp;5</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>Кількість груп товарів</span></p>\n</td>\n<td>\n<p><span>&ndash;&nbsp;10</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>Кількість відділів</span></p>\n</td>\n<td>\n<p><span>&ndash;&nbsp;4</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>Кількість операторів</span></p>\n</td>\n<td>\n<p><span>&ndash;&nbsp;30</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>Кількість копій чеків</span></p>\n</td>\n<td>\n<p><span>до 4</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>Кількість службових чеків</span></p>\n</td>\n<td>\n<p><span>до 4</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>Тип обслуговування</span></p>\n</td>\n<td>\n<p><span>&ndash;&nbsp;апарат на виході з об`єкта;</span></p>\n<p><span>&ndash;&nbsp;апарат обслуговує один відділ;</span></p>\n<p><span>&ndash;&nbsp;апарат обслуговує декілька відділів (до 4).</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>Види оплати</span></p>\n</td>\n<td>\n<p><span>&ndash;&nbsp;готівкою;</span></p>\n<p><span>&ndash;&nbsp;чеком;</span></p>\n<p><span>&ndash;&nbsp;карткою;</span></p>\n<p><span>&ndash;&nbsp;в кредит.</span></p>\n</td>\n</tr>\n</tbody>\n</table>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (241, 'ru', 'Детектор валют ДЕКО-50', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (242, 'ru', 'Детектор валют Спектр-5-А4/М', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (243, 'ru', 'Інфрачервоний детектор Спектр-Відео-К', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (244, 'ru', 'Лічильник банкнот SPEED LD-52 A', '<p><strong>Лічильник банкнот Speed LD-52</strong><span>&nbsp;призначений для точного перерахунку банкнот різних країн світу, в тому числі і українських гривень.</span><br /><span>Його унікальна конструкція, що включає всі переваги&nbsp;</span><strong>лічильників банкнот</strong><span>&nbsp;як із заднім, так і з переднім завантаженням, надійний механізм і передове&nbsp;</span><strong>програмне забезпечення</strong><span>&nbsp;- все це дозволяє інтенсивно експлуатувати лічильники в різних умовах із збільшеною ресурсоємкостью.</span></p>', '<p><strong>Лічильник банкнот Speed LD-52</strong><span>&nbsp;призначений для точного перерахунку банкнот різних країн світу, в тому числі і українських гривень.</span><br /><span>Його унікальна конструкція, що включає всі переваги&nbsp;</span><strong>лічильників банкнот</strong><span>&nbsp;як із заднім, так і з переднім завантаженням, надійний механізм і передове&nbsp;</span><strong>програмне забезпечення</strong><span>&nbsp;- все це дозволяє інтенсивно експлуатувати лічильники в різних умовах із збільшеною ресурсоємкостью.</span></p>\n<p><span><strong>Функціональні можливості:</strong></span></p>\n<ul>\n<li><span>Автоматичний старт;</span></li>\n<li><span>Система самодіагностики;</span></li>\n<li><span>Режим фасовки від 0 до 999;</span></li>\n<li><span>Режим підсумовування;</span></li>\n<li><span>Підсумовування в режимі фасовки.</span></li>\n</ul>\n<p><span><strong>&nbsp;</strong></span></p>\n<p><span><strong>Типи детекції:</strong></span></p>\n<ul>\n<li><span>Ультрафіолетова детекція;</span></li>\n<li><span>Детекція цілісності банкнот;</span></li>\n<li><span>Детекція ланцюжка банкнот;</span></li>\n<li><span>Детекція на здвоєну;</span></li>\n<li><span><span>Детекція за розміром.</span></span>\n<p><span><strong>Технічні характеристики Speed LD-52A:</strong></span></p>\n<table border=\"1\" cellspacing=\"1\" cellpadding=\"1\">\n<tbody>\n<tr>\n<td width=\"249\">\n<p lang=\"uk-UA\"><span>Швидкість рахунку</span></p>\n</td>\n<td width=\"264\">\n<p lang=\"uk-UA\" align=\"center\"><span>1000 банкнот в хвилину</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"249\">\n<p lang=\"uk-UA\"><span>Дисплей рахунку</span></p>\n</td>\n<td width=\"264\">\n<p lang=\"uk-UA\" align=\"center\"><span>4-х розр. світлодіодна матриця</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"249\">\n<p lang=\"uk-UA\"><span>Дисплей фасовки</span></p>\n</td>\n<td width=\"264\">\n<p lang=\"uk-UA\" align=\"center\"><span>3-х розр. світлодіодна матриця</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"249\">\n<p lang=\"uk-UA\"><span>Завантажувальний лоток</span></p>\n</td>\n<td width=\"264\">\n<p lang=\"uk-UA\" align=\"center\"><span>400 нових банкнот</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"249\">\n<p lang=\"uk-UA\"><span>Приймальний лоток</span></p>\n</td>\n<td width=\"264\">\n<p lang=\"uk-UA\" align=\"center\"><span>300 нових банкнот</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"249\">\n<p lang=\"uk-UA\"><span>Живлення</span></p>\n</td>\n<td width=\"264\">\n<p lang=\"uk-UA\" align=\"center\"><span>220в</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"249\">\n<p lang=\"uk-UA\"><span>Габарити</span></p>\n</td>\n<td width=\"264\">\n<p align=\"center\"><span>266х295х206 мм</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"249\">\n<p lang=\"uk-UA\"><span>Вага</span></p>\n</td>\n<td width=\"264\">\n<p lang=\"uk-UA\" align=\"center\"><span>5&nbsp;кг</span></p>\n</td>\n</tr>\n</tbody>\n</table>\n</li>\n</ul>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (245, 'ru', 'Лічильник банкнот  SPEED LD-60', '<p><span>Лічильники банкнот SPEED LD-60 є точними, надійними, високошвидкісними автоматичними машинами. Вони були розроблені для об\'єднання багатьох корисних якостей, для простоти використання і обслуговування. Можливість підключення виносного дисплея, робить лічильник дуже зручним для роботи операторів з клієнтами.</span></p>', '<p><span>Лічильники банкнот SPEED LD-60 є точними, надійними, високошвидкісними автоматичними машинами. Вони були розроблені для об\'єднання багатьох корисних якостей, для простоти використання і обслуговування. Можливість підключення виносного дисплея, робить лічильник дуже зручним для роботи операторів з клієнтами.</span></p>\n<div><strong><span><span>Основні переваги SPEED LD-60:</span></span></strong></div>\n<div>&nbsp;</div>\n<ul>\n<li><span><span>Посилена механічна конструкція, вільна від мастила протягом тривалого часу.</span></span></li>\n<li><span><span>Розширені підкидають ролики, що забезпечує рівномірне перегортання банкнот.</span></span></li>\n<li><span><span>Використання в перегортає механізмі поліуретанових роликів і накладок, що забезпечує довгу роботу цих вузлів без обслуговування.</span></span></li>\n<li><span><span>Використання високоякісної гуми на всіх транспортних роликах.</span></span></li>\n<li><span><span>Використання високоякісної пластмаси для деталей корпусу.</span></span></li>\n<li><span><span>Цифрове управління (FUZZY LOGIC).</span></span></li>\n<li><span><span>Просте використання регулювання перегортає механізму за допомогою регулювального болта, що забезпечує додаткову зручність оператора без залучення сервісного інженера.</span></span></li>\n<li><span><span>Налаштування всіх детекцій оператором, знаючи інструкцію налаштувань, досвідченим шляхом, без залучення сервісного інженера.</span></span></li>\n<li><span><span>Вологостійка панель управління.</span></span></li>\n<li><span><span>Можливість підключення виносного дисплея.</span></span></li>\n<li><span><span>Саме тестування при включенні.</span></span></li>\n<li><span><span>Перевірка справжності купюри по оптичній щільності і на здвоєність.</span></span></li>\n<li><span><span>Перевірка справжності купюри по її розміром.</span></span></li>\n</ul>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (246, 'ru', 'Лічильник банкнот Magner 75 D', '<p><span class=\"notranslate\">Високоякісний, надійний настільний лічильник банкнот Magner 75 відрізняється рядом технологічних переваг перед своїми попередниками і лічильниками, виробленими іншими компаніями.</span><span>&nbsp;</span><span class=\"notranslate\">Так, спеціальне екранування магнітного поля лічильника Magner 75 дозволяє добитися максимальної точності при прочитуванні магнітних міток з банкнот, а автоматичне коректування настройок чутливості магнітних і оптичних датчиків скорочує кількість операцій по обслуговуванню лічильника Magner 75.</span></p>', '<p><span class=\"notranslate\">Високоякісний, надійний настільний лічильник банкнот Magner 75 відрізняється рядом технологічних переваг перед своїми попередниками і лічильниками, виробленими іншими компаніями.</span><span>&nbsp;</span><span class=\"notranslate\">Так, спеціальне екранування магнітного поля лічильника Magner 75 дозволяє добитися максимальної точності при прочитуванні магнітних міток з банкнот, а автоматичне коректування настройок чутливості магнітних і оптичних датчиків скорочує кількість операцій по обслуговуванню лічильника Magner 75.</span></p>\n<p><span><span class=\"notranslate\">Вимірювання щільності (оптичною) банкноти на лічильнику Magner 75 проводиться на 4-х рівнях.</span>&nbsp;<span class=\"notranslate\">На першому рівні лічильником здійснюється найжорсткіший контроль, тобто&nbsp;</span><span class=\"notranslate\">відбраковуються банкноти, які мають незначний ступінь забрудненості.</span>&nbsp;<span class=\"notranslate\">Другий і третій рівні є проміжними, а на четвертому рівні лічильники банкнот Magner 75 прораховують всі банкноти, незалежно від ступеня їх забрудненості.</span></span></p>\n<p><span><span class=\"notranslate\">Розмір фасовки пачки виставляється довільно за бажанням оператора із зупинкою Magner 75 на кожній сотні (заводська установка).</span>&nbsp;<span class=\"notranslate\">Можливий розмір пачки - від 1 до 999 банкнот.</span></span></p>\n<p><span><span class=\"notranslate\">Існуючий режим накопичення дозволяє лічильнику Magner 75 додавати до вже прорахованих банкнотам нову кількість.</span></span></p>\n<p><span><span class=\"notranslate\"><strong>Механізм подачі купюри:</strong>&nbsp;ролики фрикційного типу</span>&nbsp;<br /><span class=\"notranslate\"><strong>Дисплей:</strong>&nbsp;рідкокристалічний, для відображення показань рахунку і установок пачки</span>&nbsp;<br /><span class=\"notranslate\"><strong>Повідомлення про помилку:</strong>&nbsp;здвоєна або склеєна банкнота, \"Ланцюг\" (немає зазору між двома проходять одна за одною банкнотами), половина банкноти, застрягання банкноти</span>&nbsp;<br /><span class=\"notranslate\"><strong>За детекції:</strong>&nbsp;підозріла банкнота, розмір, ширина.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (247, 'ru', 'Лічильник банкнот Magner 35S', '<p><span class=\"notranslate\">Лічильник банкнот, який призначений для перерахунку банкнот різних валют.&nbsp;<strong>Magner 35S</strong>&nbsp;вже більше 12 років є однією з найбільш популярних моделей лічильників банкнот з продажу.</span><span>&nbsp;</span><br /><span class=\"notranslate\">Приваблива ціна і простота управління вигідно відрізняють дану модель.</span><span>&nbsp;</span><br /><span class=\"notranslate\">У лічильнику банкнот Magner 35S використовуються металеві шасі, що забезпечує його високу надійність при обробці будь-якої маси готівки.</span></p>', '<p><span class=\"notranslate\">Лічильник банкнот, який призначений для перерахунку банкнот різних валют.&nbsp;<strong>Magner 35S</strong>&nbsp;вже більше 12 років є однією з найбільш популярних моделей лічильників банкнот з продажу.</span><span>&nbsp;</span><br /><span class=\"notranslate\">Приваблива ціна і простота управління вигідно відрізняють дану модель.</span><span>&nbsp;</span><br /><span class=\"notranslate\">У лічильнику банкнот Magner 35S використовуються металеві шасі, що забезпечує його високу надійність при обробці будь-якої маси готівки.</span></p>\n<p><span><span class=\"notranslate\"><strong>Функціональні можливості:</strong></span></span></p>\n<ul>\n<li><span><span class=\"notranslate\">Перемикання ручного або автоматичного старту перерахунку</span></span></li>\n<li><span><span class=\"notranslate\">Яскравий світлодіодний дисплей зеленого свічення</span></span></li>\n<li><span><span class=\"notranslate\">Установка одного з 7 рівнів щільності для роботи з різними банкнотами: від нових і чистих до старих і забруднених</span></span></li>\n<li><span><span class=\"notranslate\">Підсумовування результатів перерахунку</span></span></li>\n<li><span><span class=\"notranslate\">Відлік фіксованої кількості банкнот (пачка)</span></span></li>\n<li><span><span class=\"notranslate\">Завдання будь-якого числа банкнот в пачці: від 1 до 999</span></span></li>\n<li><span><span class=\"notranslate\">Зупинка з вказівкою коду конкретної помилки у разі виявлення злиплих, дуже забруднених, складених банкнот або половини від банкноти</span></span></li>\n</ul>\n<p><span><span class=\"notranslate\">Використовуючи можливість трьохшвидкісного режиму рахунку (1300, 1000 і 500 банкнот / хв.) Оператор може працювати з максимальною продуктивністю при перерахунку нових купюр (1300 банкнот / хв.), А також робити точний підрахунок старих купюр (600 банкнот / хв.).</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (248, 'ru', 'Термострічка 57.5 мм', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (249, 'ru', 'Термострічка 49,5 мм', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (250, 'ru', 'Термострічка 80 мм', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (251, 'ru', 'Термострічка 59,5 мм', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (252, 'ru', 'Термоетикетка 24х14/2000', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (253, 'ru', 'Термоетикетка 30х20ТТОР/2000', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (254, 'ru', 'Фіскальний реєстратор Datecs FP-101 Smart', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (255, 'ru', 'Фіскальний реєстратор IKC-A8800', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (256, 'ru', 'РРО IKC-M510 з КСЕФ', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (326, 'ru', 'РРО MG-V545T', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (330, 'ru', 'Ваги торгові PT', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (331, 'ru', 'Фіскальний реєстратор Екселліо FP700', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (257, 'ru', 'Ваги торгові CAS ER-Plus', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (258, 'ru', 'Ваги фасовочні CAS AD, AD-H', '<p><span><strong>Настільні ваги CAS AD / AD-H</strong><a title=\"CAS-AD\" href=\"http://luks.com.ua/wp-content/uploads/cas-ad.jpg\"><br /></a></span></p>\n<ul>\n<li><span>Клас точності по ГОСТ 29329 - середній</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Вибірка маси тари з діапазону зважування</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Діагностика несправностей</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Мембранна клавіатура</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Платформа з нержавіючої сталі</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Живлення від мережі</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Інтерфейс RS-232C&nbsp;&nbsp;</span></li>\n</ul>\n<p><span><strong>&nbsp;</strong></span></p>', '<p><span><strong>Настільні ваги CAS AD / AD-H</strong><a title=\"CAS-AD\" href=\"http://luks.com.ua/wp-content/uploads/cas-ad.jpg\"><br /></a></span></p>\n<ul>\n<li><span>Клас точності по ГОСТ 29329 - середній</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Вибірка маси тари з діапазону зважування</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Діагностика несправностей</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Мембранна клавіатура</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Платформа з нержавіючої сталі</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Живлення від мережі</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Інтерфейс RS-232C&nbsp;&nbsp;</span></li>\n</ul>\n<p><span><strong>Технічні характеристики ваги CAS AD / AD-H:</strong></span></p>\n<table style=\"height: 130px; width: 863px;\" border=\"0\">\n<tbody>\n<tr>\n<td width=\"120\">\n<p align=\"center\"><span>Модель</span></p>\n</td>\n<td width=\"92\">\n<p align=\"center\"><span lang=\"ru-RU\">AD-2,5</span></p>\n</td>\n<td valign=\"bottom\" width=\"112\">\n<p align=\"center\"><span lang=\"ru-RU\">AD-5,0</span></p>\n</td>\n<td valign=\"bottom\" width=\"96\">\n<p align=\"center\"><span lang=\"ru-RU\">AD-10</span></p>\n</td>\n<td valign=\"bottom\" width=\"92\">\n<p align=\"center\"><span lang=\"ru-RU\">AD-25</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"120\">\n<p align=\"center\"><span>Макс. гр. зваж.</span></p>\n</td>\n<td width=\"92\">\n<p lang=\"uk-UA\" align=\"center\"><span>2,5кг</span></p>\n</td>\n<td width=\"112\">\n<p lang=\"uk-UA\" align=\"center\"><span lang=\"uk-UA\">5кг</span></p>\n</td>\n<td width=\"96\">\n<p lang=\"uk-UA\" align=\"center\"><span lang=\"uk-UA\">10кг</span></p>\n</td>\n<td width=\"92\">\n<p lang=\"uk-UA\" align=\"center\"><span lang=\"uk-UA\">25кг</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"120\">\n<p lang=\"uk-UA\" align=\"center\"><span>Дискретність</span></p>\n</td>\n<td width=\"92\">\n<p lang=\"uk-UA\" align=\"center\"><span>0,5г</span></p>\n</td>\n<td width=\"112\">\n<p lang=\"uk-UA\" align=\"center\"><span>1г</span></p>\n</td>\n<td width=\"96\">\n<p lang=\"uk-UA\" align=\"center\"><span>2г</span></p>\n</td>\n<td width=\"92\">\n<p lang=\"uk-UA\" align=\"center\"><span>5г</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"120\">\n<p lang=\"uk-UA\" align=\"center\"><span>Вибірка ваги тари</span></p>\n</td>\n<td width=\"92\">\n<p lang=\"uk-UA\" align=\"center\"><span>2,5кг</span></p>\n</td>\n<td width=\"112\">\n<p lang=\"uk-UA\" align=\"center\"><span>5кг</span></p>\n</td>\n<td width=\"96\">\n<p lang=\"uk-UA\" align=\"center\"><span>9,98кг</span></p>\n</td>\n<td width=\"92\">\n<p lang=\"uk-UA\" align=\"center\"><span>9,95кг</span></p>\n</td>\n</tr>\n</tbody>\n</table>\n<table style=\"height: 130px; width: 864px;\" border=\"0\">\n<tbody>\n<tr>\n<td width=\"120\">\n<p align=\"center\"><span><strong>Модель</strong></span></p>\n</td>\n<td valign=\"bottom\" width=\"134\">\n<p lang=\"ru-RU\" align=\"center\"><span><strong>AD-5,0Н</strong></span></p>\n</td>\n<td valign=\"bottom\" width=\"129\">\n<p lang=\"ru-RU\" align=\"center\"><span><strong>AD-10Н</strong></span></p>\n</td>\n<td valign=\"bottom\" width=\"136\">\n<p lang=\"ru-RU\" align=\"center\"><span><strong>AD-20Н&nbsp;&nbsp;<br /></strong></span></p>\n</td>\n</tr>\n<tr>\n<td width=\"120\">\n<p align=\"center\"><span>Макс. гр. зваж.</span></p>\n</td>\n<td width=\"134\">\n<p lang=\"uk-UA\" align=\"center\"><span>5кг</span></p>\n</td>\n<td width=\"129\">\n<p lang=\"uk-UA\" align=\"center\"><span>10кг</span></p>\n</td>\n<td width=\"136\">\n<p lang=\"uk-UA\" align=\"center\"><span>20кг</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"120\">\n<p lang=\"uk-UA\" align=\"center\"><span>Дискретність</span></p>\n</td>\n<td width=\"134\">\n<p lang=\"uk-UA\" align=\"center\"><span>0,5г</span></p>\n</td>\n<td width=\"129\">\n<p lang=\"uk-UA\" align=\"center\"><span>1г</span></p>\n</td>\n<td width=\"136\">\n<p lang=\"uk-UA\" align=\"center\"><span>2г</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"120\">\n<p lang=\"uk-UA\" align=\"center\"><span>Вибірка ваги тари</span></p>\n</td>\n<td width=\"134\">\n<p lang=\"uk-UA\" align=\"center\"><span>5кг</span></p>\n</td>\n<td width=\"129\">\n<p lang=\"uk-UA\" align=\"center\"><span>10кг</span></p>\n</td>\n<td width=\"136\">\n<p lang=\"uk-UA\" align=\"center\"><span>20кг</span></p>\n</td>\n</tr>\n</tbody>\n</table>\n<table style=\"height: 290px; width: 865px;\" border=\"0\">\n<tbody>\n<tr>\n<td width=\"49%\"><span>Число рядків індикатора</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>5</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Тип вимірювання</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>Тензометричний</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Тип дисплея</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>Флуоресцентний</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Розміри платформи</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>340х215 мм</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Живлення</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>110~240 В, 49~51 Гц</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Споживана потужність, Вт, не більше</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>7</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Діапазон робочих температур</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>-10&deg;С - +40&deg;С</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Габаритні розміри, мм</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>350 x 325 x 105</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Вага, кг</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>не більше 4,7</span></p>\n</td>\n</tr>\n</tbody>\n</table>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (259, 'ru', 'Ваги фасовочні Jadever JKH', '<ul>\n<li><span><strong>Портативні&nbsp;ваги</strong>&nbsp;з автономним (батареї) і мережевим (220В) живленням. Призначені для широкого застосування в технологічних процесах. Платформа виготовлена з неіржавіючої сталі, тип дисплея - рідкокристалічний.</span></li>\n</ul>\n<p><span><strong>&nbsp; &nbsp; &nbsp; Основні функції і технічні характеристики ваги Jadever JKH:</strong><br /></span></p>\n<ul>\n<li><span>&nbsp;вибірка маси тари до 100 % від НПВ;</span></li>\n<li><span>&nbsp;функція підрахунку</span></li>\n</ul>', '<ul>\n<li><span><strong>Портативні&nbsp;ваги</strong>&nbsp;з автономним (батареї) і мережевим (220В) живленням. Призначені для широкого застосування в технологічних процесах. Платформа виготовлена з неіржавіючої сталі, тип дисплея - рідкокристалічний.</span></li>\n</ul>\n<p><span><strong>&nbsp; &nbsp; &nbsp; Основні функції і технічні характеристики ваги Jadever JKH:</strong><br /></span></p>\n<ul>\n<li><span>&nbsp;вибірка маси тари до 100 % від НПВ;</span></li>\n<li><span>&nbsp;функція підрахунку</span>\n<table border=\"0\">\n<tbody>\n<tr>\n<td width=\"196\">\n<p align=\"center\"><span><strong>Модель</strong></span></p>\n</td>\n<td width=\"158\">\n<p lang=\"uk-UA\" align=\"center\"><span><strong>JKH-500</strong></span></p>\n</td>\n<td width=\"153\">\n<p lang=\"uk-UA\" align=\"center\"><span><strong>JKH-1000</strong></span></p>\n</td>\n</tr>\n<tr>\n<td width=\"196\">\n<p lang=\"uk-UA\" align=\"left\"><span>Найбільша межа зважування, г</span></p>\n</td>\n<td width=\"158\">\n<p lang=\"uk-UA\" align=\"center\"><span>500</span></p>\n</td>\n<td width=\"153\">\n<p lang=\"uk-UA\" align=\"center\"><span>1000</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"196\">\n<p lang=\"uk-UA\" align=\"left\"><span>Дискретність відліку, г</span></p>\n</td>\n<td width=\"158\">\n<p lang=\"uk-UA\" align=\"center\"><span>0,1</span></p>\n</td>\n<td width=\"153\">\n<p lang=\"uk-UA\" align=\"center\"><span>0,2</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"196\">\n<p lang=\"uk-UA\" align=\"left\"><span>Розмір платформи, мм</span></p>\n</td>\n<td colspan=\"2\" width=\"318\">\n<p lang=\"uk-UA\" align=\"center\"><span>140 х 140</span></p>\n</td>\n</tr>\n</tbody>\n</table>\n</li>\n</ul>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (260, 'ru', 'Ваги фасовочні ВТНЕ', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (261, 'ru', 'Ваги фасовочні Днепровес', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (262, 'ru', 'Ваги фасовочні CAS SW', '<p><span>&nbsp;Прості і надійні&nbsp;<strong>ваги</strong>, краще співвідношення ціна-якість серед конкурентів.<br /></span></p>\n<ul>\n<li><span>&nbsp; Клас точності - середній</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Віднімання маси тари</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Рахунковий режим і режим дозування (тільки для моделей SW-C)</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Усереднювання&nbsp;показів маси при нестабільному навантаженні (тільки для моделей SW)</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Зважування в заданих межах(тільки для моделей SW-C)</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Мембранна клавіатура</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Індикація розрядки батарей</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Діагностика несправностей</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Платформа з пластмаси</span></li>\n</ul>', '<p><span>&nbsp;Прості і надійні&nbsp;<strong>ваги</strong>, краще співвідношення ціна-якість серед конкурентів.<br /></span></p>\n<ul>\n<li><span>&nbsp; Клас точності - середній</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Віднімання маси тари</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Рахунковий режим і режим дозування (тільки для моделей SW-C)</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Усереднювання&nbsp;показів маси при нестабільному навантаженні (тільки для моделей SW)</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Зважування в заданих межах(тільки для моделей SW-C)</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Мембранна клавіатура</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Індикація розрядки батарей</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Діагностика несправностей</span></li>\n</ul>\n<ul>\n<li><span>&nbsp; Платформа з пластмаси</span></li>\n<li><span>Живлення від мережі через адаптер або від батарей (сухих або таких, що перезаряджаються) з автоматичним відключенням в перервах від 0 до 9 хвилин</span></li>\n<li><strong style=\"line-height: 1.4em;\">Опції ваги CAS SW / SW-D:</strong></li>\n<li><span>&nbsp; Другий дисплей на задній стінці</span></li>\n<li><span>Платформа з нержавіючої сталі</span></li>\n<li><span>Платформа у вигляді чаші з нержавіючої сталі (розмір 355х310х55 мм)</span></li>\n<li><span><span>Водонепроникний кожух з прозорого пластика</span></span></li>\n<li><span><span><strong>Технічні характеристики:</strong></span></span></li>\n<li>\n<table style=\"height: 98px; width: 813px;\" border=\"0\">\n<tbody>\n<tr>\n<td width=\"120\">\n<p align=\"center\"><span>Модель</span></p>\n</td>\n<td width=\"92\">\n<p lang=\"ru-RU\" align=\"center\"><span>SW-2</span></p>\n</td>\n<td valign=\"bottom\" width=\"101\">\n<p lang=\"ru-RU\" align=\"center\"><span>SW-5</span></p>\n</td>\n<td valign=\"bottom\" width=\"100\">\n<p lang=\"ru-RU\" align=\"center\"><span>SW-10</span></p>\n</td>\n<td valign=\"bottom\" width=\"99\">\n<p lang=\"ru-RU\" align=\"center\"><span>SW-20</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"120\">\n<p align=\"center\"><span>Макс. гр. зваж., кг</span></p>\n</td>\n<td width=\"92\">\n<p lang=\"uk-UA\" align=\"center\"><span>1/2</span></p>\n</td>\n<td width=\"101\">\n<p lang=\"uk-UA\" align=\"center\"><span>2,5/5</span></p>\n</td>\n<td width=\"100\">\n<p lang=\"uk-UA\" align=\"center\"><span>4/10</span></p>\n</td>\n<td width=\"99\">\n<p lang=\"uk-UA\" align=\"center\"><span>10/20</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"120\">\n<p lang=\"uk-UA\" align=\"center\"><span>Дискретність, г</span></p>\n</td>\n<td width=\"92\">\n<p lang=\"uk-UA\" align=\"center\"><span>0,5/1</span></p>\n</td>\n<td width=\"101\">\n<p lang=\"uk-UA\" align=\"center\"><span>1/2</span></p>\n</td>\n<td width=\"100\">\n<p lang=\"uk-UA\" align=\"center\"><span>2/5</span></p>\n</td>\n<td width=\"99\">\n<p lang=\"uk-UA\" align=\"center\"><span>5/10</span></p>\n</td>\n</tr>\n</tbody>\n</table>\n<table style=\"height: 306px; width: 813px;\" border=\"0\">\n<tbody>\n<tr>\n<td width=\"49%\"><span>Число рядків індикатора</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>5</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Тип вимірювання</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>Тензометричний</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Тип дисплея</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>Рідкокристалічний</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Розміри платформи</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>241х192 мм</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Живлення</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>110~240 В, 49~51 Гц через адаптер або від батарейок</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Споживана потужність, Вт, не більше</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>0,25</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Діапазон робочих температур</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>-10&deg;С - +40&deg;С</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Габаритні розміри, мм</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>260&times;287&times;137</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Вага, кг</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>не більше 2,7</span></p>\n</td>\n</tr>\n</tbody>\n</table>\n</li>\n</ul>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (263, 'ru', 'Ваги фасовочні NWTH', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (264, 'ru', 'Ваги торгові JPL-N', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (265, 'ru', 'Ваги торгові JPL-N 1506', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (266, 'ru', 'Ваги торгові JPL', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (268, 'ru', 'Термо принтер ЕКСЕЛЛІО EP-50', '<p><span title=\"Экселлио ЕР-50 &ndash; проверенный и надежный POS принтер компании DATECS (Болгария), который широко используется на рынке на протяжении уже 10 лет.\">Екселліо ЕР-50 - перевірений і надійний POS принтер компанії DATECS (Болгарія), який широко використовується на ринку протягом&nbsp; 10 років.&nbsp;</span><span title=\"Чековый термопринтер ЕР-50 полностью совместим с POS системами и контрольно-кассовыми аппаратами, имеет интерфейс подключения денежного ящика.\">Чековий термопринтер ЕР-50 повністю сумісний з POS системами та контрольно-касовими апаратами, має інтерфейс підключення грошового ящика.&nbsp;</span><span title=\"Небольшой вес (всего 400 гр.) и размеры (106 x 184 x 110 мм) позволяют легко разместить его на кухне, поэтому как кухонный принтер он широко используется в заведениях общественного питания и сфере бытового обслуживания - в ресторанах, кафе, барах, фаст-\">Невелика вага (всього 400 гр.) І розміри (106 x 184 x 110 мм) дозволяють легко розмістити його на кухні, тому як кухонний принтер він широко використовується в закладах громадського харчування і сфері побутового обслуговування - у ресторанах, кафе, барах, фаст-</span><span title=\"фудах.\">фудах.</span></p>', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (269, 'ru', 'Термо принтер UNIQ-TP61', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (270, 'ru', 'Термо принтер Posiflex AURA-6900', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (271, 'ru', 'Термо принтер Sewoo (Lukhan) LK-T200', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (272, 'ru', 'Кухонний дзвінок Sewoo (Lukhan) MB-1000', '<p><span id=\"result_box\" lang=\"uk\"><span class=\"hps\">Кухонний</span>&nbsp;<span class=\"hps\">дзвінок</span>&nbsp;<span class=\"hps\">Sewoo MB</span>-1000&nbsp;<span class=\"hps\">-</span>&nbsp;<span class=\"hps\">зовнішнє</span>&nbsp;<span class=\"hps alt-edited\">звуковий</span>&nbsp;<span class=\"hps alt-edited\">пристрій</span>&nbsp;<span class=\"hps\">для</span>&nbsp;<span class=\"hps\">автоматизації</span><span class=\"hps\">ресторану</span>&nbsp;<span class=\"hps\">або</span>&nbsp;<span class=\"hps\">кафе</span>.&nbsp;<span class=\"hps\">Він</span>&nbsp;<span class=\"hps\">може бути підключений</span>&nbsp;<span class=\"hps\">до будь</span>&nbsp;<span class=\"hps\">чековий термопринтер</span>,<span class=\"hps\">сумісного</span>&nbsp;<span class=\"hps\">з</span>&nbsp;<span class=\"hps\">протоколом</span>&nbsp;<span class=\"hps\">EPSON</span>.<br /><br /><span class=\"hps\">MB</span>-1000&nbsp;<span class=\"hps\">сигналізує</span>&nbsp;<span class=\"hps\">про надходження</span>&nbsp;<span class=\"hps\">нового замовлення</span>&nbsp;<span class=\"hps\">й</span>&nbsp;<span class=\"hps\">початку</span>&nbsp;<span class=\"hps\">роздруківки</span><span class=\"hps\">його</span>&nbsp;<span class=\"hps\">на</span>&nbsp;<span class=\"hps\">кухонному принтері</span>,&nbsp;<span class=\"hps\">тим самим скорочуючи час</span>&nbsp;<span class=\"hps\">від</span>&nbsp;<span class=\"hps\">прийняття замовлення</span>&nbsp;<span class=\"hps\">офіціантом</span>&nbsp;<span class=\"hps\">до</span>&nbsp;<span class=\"hps\">приготування страв</span>&nbsp;<span class=\"hps\">і</span>&nbsp;<span class=\"hps\">зводячи до мінімуму</span>&nbsp;<span class=\"hps\">можливі помилки</span>&nbsp;<span class=\"hps\">персоналу</span>.<br /><br /><span class=\"hps\">Кухонний</span>&nbsp;<span class=\"hps\">дзвінок</span>&nbsp;<span class=\"hps\">має</span>&nbsp;<span class=\"hps\">гучний</span>&nbsp;<span class=\"hps\">регульований звуковий сигнал</span>,&nbsp;<span class=\"hps\">який</span>&nbsp;<span class=\"hps\">буде добре чутний</span>&nbsp;<span class=\"hps\">в</span>&nbsp;<span class=\"hps\">приміщенні</span>&nbsp;<span class=\"hps\">з підвищеним рівнем шуму</span>,&nbsp;<span class=\"hps\">такому</span>,&nbsp;<span class=\"hps\">наприклад</span>,&nbsp;<span class=\"hps\">як</span>&nbsp;<span class=\"hps\">кухня</span><span class=\"hps\">ресторану</span>.<br /><br /><span class=\"hps\">Для</span>&nbsp;<span class=\"hps\">зручності розміщення</span>&nbsp;<span class=\"hps\">в</span>&nbsp;<span class=\"hps\">конструкції</span>&nbsp;<span class=\"hps\">MB</span>-1000&nbsp;<span class=\"hps\">передбачена можливість кріплення</span>&nbsp;<span class=\"hps\">на</span>&nbsp;<span class=\"hps\">стіну</span>.<br /><span class=\"hps\">Основні</span>&nbsp;<span class=\"hps\">характеристики</span>&nbsp;<span class=\"hps\">кухонного</span>&nbsp;<span class=\"hps\">дзвінок</span>&nbsp;<span class=\"hps\">Sewoo MB</span>-1000:<br /></span></p>\n<ul>\n<li><span id=\"result_box\" lang=\"uk\"><span class=\"hps\">Тривалість</span>&nbsp;<span class=\"hps\">звукового</span>&nbsp;<span class=\"hps\">сигналу</span>&nbsp;<span class=\"hps\">- 6</span>&nbsp;<span class=\"hps alt-edited\">с</span></span></li>\n<li><span id=\"result_box\" lang=\"uk\"><span class=\"hps\">Можливість</span>&nbsp;<span class=\"hps\">регулювання рівня гучності</span>&nbsp;<span class=\"hps\">сигналу</span></span></li>\n<li><span id=\"result_box\" lang=\"uk\"><span class=\"hps\">Інтерфейс підключення</span>:&nbsp;<span class=\"hps\">1xRJ</span><span class=\"atn\">-12 (</span>6P6C)</span></li>\n<li><span id=\"result_box\" lang=\"uk\"><span class=\"hps\">Габаритні розміри</span>&nbsp;<span class=\"hps atn\">(</span>ШхГхВ): 60&nbsp;<span class=\"hps\">х 25</span>&nbsp;<span class=\"hps\">х</span>&nbsp;<span class=\"hps\">80 мм</span></span></li>\n<li><span id=\"result_box\" lang=\"uk\"><span class=\"hps\">Маса</span>&nbsp;<span class=\"hps\">- 0,055</span>&nbsp;<span class=\"hps\">кг</span></span></li>\n</ul>', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (275, 'ru', 'Кухонний дзвінок Posiflex KL-100', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (276, 'ru', 'Зчитувач Posiflex MR-2100', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (277, 'ru', 'Зчитувач Posiflex серии SD-200', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (278, 'ru', 'Фіскальний реєстратор MG-N707TS', '<p><span><strong>Фіскальний реєстратор ІКС-Е260Т&nbsp;</strong>є представником найбільш якісної категорії фіскального обладнання, яке пропонується українським споживачам<strong>.</strong></span></p>\n<div id=\"tabs-wrapper\" class=\"ui-tabs ui-widget ui-widget-content ui-corner-all\">\n<div id=\"tabs-body\">\n<div id=\"desc\" class=\"ui-tabs-panel ui-widget-content ui-corner-bottom\"><span>Електронний контрольно-касовий реєстратор IKC-E260 використовується при готівковому розрахунку з покупцями за продані товари та послуги на підприємствах торгівлі, громадського харчування, в сфері послуг, при внесенні платежів за послуги стільникового зв\'язку мобільних операторів, у ломбардах.</span><span>&nbsp;Фіскальний реєстратор IКС-Е260Т (версії ЕП-06) з модемом IKC-М2 Combi забезпечують передачу контрольно-звітної інформації в електронному вигляді до органів ДПС України, надаючи користувачам вибір використання каналів зв\'язку, як провідний, так і бездротової. Модель внесена до Державного реєстру РРО і відповідає всім вимогам Закону України від 02.10.2010 № 265 &laquo;Про застосування реєстраторів розрахункових операцій у сфері торгівлі, Громадського харчування та послуг&raquo; та Наказу Міністерства Фінансів України від 08.10.2012 № 1057 &laquo;Про ЗАТВЕРДЖЕНЕ Вимоги Щодо Створення контрольної стрічкі в електронній формі у реєстраторах розрахункових операцій та модемів для передачі даніх та Порядку передачі Електрон копій розрахункових документів и фіскальніх звітніх чеків реєстраторів розрахункових операцій дротовімі або бездротовімі каналами зв\'язку до органів державної податкової служби &raquo;.</span></div>\n</div>\n</div>', '<p><span><strong>Фіскальний реєстратор ІКС-Е260Т&nbsp;</strong>є представником найбільш якісної категорії фіскального обладнання, яке пропонується українським споживачам<strong>.</strong></span></p>\n<div id=\"tabs-wrapper\" class=\"ui-tabs ui-widget ui-widget-content ui-corner-all\">\n<div id=\"tabs-body\">\n<div id=\"desc\" class=\"ui-tabs-panel ui-widget-content ui-corner-bottom\"><span>Електронний контрольно-касовий реєстратор IKC-E260 використовується при готівковому розрахунку з покупцями за продані товари та послуги на підприємствах торгівлі, громадського харчування, в сфері послуг, при внесенні платежів за послуги стільникового зв\'язку мобільних операторів, у ломбардах.</span><span>&nbsp;Фіскальний реєстратор IКС-Е260Т (версії ЕП-06) з модемом IKC-М2 Combi забезпечують передачу контрольно-звітної інформації в електронному вигляді до органів ДПС України, надаючи користувачам вибір використання каналів зв\'язку, як провідний, так і бездротової. Модель внесена до Державного реєстру РРО і відповідає всім вимогам Закону України від 02.10.2010 № 265 &laquo;Про застосування реєстраторів розрахункових операцій у сфері торгівлі, Громадського харчування та послуг&raquo; та Наказу Міністерства Фінансів України від 08.10.2012 № 1057 &laquo;Про ЗАТВЕРДЖЕНЕ Вимоги Щодо Створення контрольної стрічкі в електронній формі у реєстраторах розрахункових операцій та модемів для передачі даніх та Порядку передачі Електрон копій розрахункових документів и фіскальніх звітніх чеків реєстраторів розрахункових операцій дротовімі або бездротовімі каналами зв\'язку до органів державної податкової служби &raquo;.</span></div>\n</div>\n</div>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (279, 'ru', 'Фіскальний реєстратор МІНІ­-ФП81.01', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (280, 'ru', 'Ваги електронні ВТНЕ', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (281, 'ru', 'Ваги торгові МК-Т', '<p><span>Торгівельні електронні ваги виробництва Масса-К серії МК настільні використовуються для статичного зважування маси різних товарів, технологічних операцій, фасовки і розрахунку вартості товару. Ваги бувають з верхнім і нижнім розміщенням клавіатури. Працюють від вбудованого акумулятора, так і від мережі.</span></p>', '<p align=\"justify\"><span style=\"color: #000000;\">Торгівельні електронні ваги виробництва Масса-К серії МК настільні використовуються для статичного зважування маси різних товарів, технологічних операцій, фасовки і розрахунку вартості товару. Ваги бувають з верхнім і нижнім розміщенням клавіатури. Працюють від вбудованого акумулятора, так і від мережі.</span></p>\n<p align=\"center\"><strong>Технічні характеристики</strong></p>\n<center>\n<table border=\"0\">\n<tbody>\n<tr class=\"head_red\">\n<td align=\"center\">Модель</td>\n<td align=\"center\">МК-15.2-ТВ20/ТВ22</td>\n<td align=\"center\">МК-15.2-ТН20/ТН22</td>\n</tr>\n<tr class=\"line_grey\">\n<td align=\"left\">Точність, г</td>\n<td colspan=\"2\" align=\"center\">2/5</td>\n</tr>\n<tr class=\"line_grey\">\n<td align=\"left\">Межі зважування, кг</td>\n<td colspan=\"2\" align=\"center\">0,04-15</td>\n</tr>\n<tr class=\"line_grey\">\n<td align=\"left\">Величина тарування, кг</td>\n<td colspan=\"2\" align=\"center\">3</td>\n</tr>\n<tr class=\"line_grey\">\n<td align=\"left\">Габаритні розміри, мм</td>\n<td align=\"center\">340х285х500</td>\n<td align=\"center\">340х375х500</td>\n</tr>\n<tr class=\"line_grey\">\n<td align=\"left\">Розміри платформи, мм</td>\n<td colspan=\"2\" align=\"center\">340х245</td>\n</tr>\n<tr class=\"line_grey\">\n<td align=\"left\">Час зважування, сек</td>\n<td colspan=\"2\" align=\"center\">&lt; 2</td>\n</tr>\n<tr class=\"line_grey\">\n<td align=\"left\">Живлення, В</td>\n<td colspan=\"2\" align=\"center\">220</td>\n</tr>\n<tr class=\"line_grey\">\n<td align=\"left\">Вага, кг</td>\n<td colspan=\"2\" align=\"center\">5.0</td>\n</tr>\n</tbody>\n</table>\n</center>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (282, 'ru', 'Сканер штрихкодів Honeywell MS 5145 Eclipse', '<p><span class=\"hps\">Ручний</span><span>&nbsp;</span><span class=\"hps\">лазерний</span><span>&nbsp;</span><span class=\"hps\">сканер</span><strong>&nbsp;<span class=\"hps\">Metrologic</span>&nbsp;<span class=\"hps\">5145</span></strong><br /><br /><span class=\"hps\">Нова серія</span><span>&nbsp;</span><span class=\"hps\">недорогих</span><span>&nbsp;</span><span class=\"hps\">ручних</span><span>&nbsp;</span><span class=\"hps\">лазерних</span><span>&nbsp;</span><span class=\"hps\">сканерів</span><span>&nbsp;</span><strong>Metrologic Eclipse</strong><span>,&nbsp;</span><span class=\"hps\">зберегла всі</span><span>&nbsp;</span><span class=\"hps\">основні переваги</span><span class=\"hps\">добре</span><span>&nbsp;</span><span class=\"hps\">відомих</span><span>&nbsp;</span><span class=\"hps\">сканерів</span><span>&nbsp;</span><span class=\"hps\">Voyager</span><span>&nbsp;</span><span class=\"hps\">MS95х0</span><span>.</span><br /><br /><span class=\"hps\">Вбудована</span><span>&nbsp;</span><span class=\"hps\">сучасна</span><span>&nbsp;</span><span class=\"hps\">технологія</span><span>&nbsp;</span><strong>CodeGate</strong><span>&nbsp;</span><span class=\"hps\">дозволяє простим</span><span>&nbsp;</span><span class=\"hps\">натисненням</span><span>&nbsp;</span><span class=\"hps\">кнопки</span><span>&nbsp;</span><span class=\"hps\">перемістити</span><span class=\"hps\">лічені</span><span>&nbsp;</span><span class=\"hps\">дані в</span><span>&nbsp;</span><span class=\"hps\">комп\'ютер або інший</span><span>&nbsp;</span><span class=\"hps\">головний пристрій</span><span>:</span><br /><br /><span class=\"hps\">Затемнення</span><span>&nbsp;</span><strong><span class=\"hps\">MS</span>&nbsp;<span class=\"hps\">5145</span></strong><span>,&nbsp;</span><span class=\"hps\">на відміну</span><span>&nbsp;</span><span class=\"hps\">від</span><span>&nbsp;</span><span class=\"hps\">Voyager</span><span>&nbsp;</span><span class=\"hps\">MS95х0</span><span>,&nbsp;</span><span class=\"hps\">поставляється без</span><span>&nbsp;</span><span class=\"hps\">підставки</span><span>&nbsp;</span><span class=\"hps\">(кнопка</span><span class=\"hps\">CodeGate</span><span>&nbsp;</span><span class=\"hps\">відключатися</span><span>&nbsp;</span><span class=\"hps\">не може)</span><span>&nbsp;</span><span class=\"hps\">і цим пояснюється</span><span>&nbsp;</span><span class=\"hps\">порівняльна</span><span>&nbsp;</span><span class=\"hps\">низька вартість</span><span>&nbsp;</span><span class=\"hps\">цієї моделі.</span></p>', '<p><span data-mce-mark=\"1\">Ручний</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">лазерний</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">сканер</span><strong>&nbsp;<span data-mce-mark=\"1\">Metrologic</span>&nbsp;<span data-mce-mark=\"1\">5145</span></strong><br /><br /><span data-mce-mark=\"1\">Нова серія</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">недорогих</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">ручних</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">лазерних</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">сканерів</span><span data-mce-mark=\"1\">&nbsp;</span><strong>Metrologic Eclipse</strong><span data-mce-mark=\"1\">,&nbsp;</span><span data-mce-mark=\"1\">зберегла всі</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">основні переваги</span><span data-mce-mark=\"1\">добре</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">відомих</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">сканерів</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">Voyager</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">MS95х0</span><span data-mce-mark=\"1\">.</span><br /><br /><span data-mce-mark=\"1\">Вбудована</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">сучасна</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">технологія</span><span data-mce-mark=\"1\">&nbsp;</span><strong>CodeGate</strong><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">дозволяє простим</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">натисненням</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">кнопки</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">перемістити</span><span data-mce-mark=\"1\">лічені</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">дані в</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">комп\'ютер або інший</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">головний пристрій</span><span data-mce-mark=\"1\">:</span><br /><br /><span data-mce-mark=\"1\">Затемнення</span><span data-mce-mark=\"1\">&nbsp;</span><strong><span data-mce-mark=\"1\">MS</span>&nbsp;<span data-mce-mark=\"1\">5145</span></strong><span data-mce-mark=\"1\">,&nbsp;</span><span data-mce-mark=\"1\">на відміну</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">від</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">Voyager</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">MS95х0</span><span data-mce-mark=\"1\">,&nbsp;</span><span data-mce-mark=\"1\">поставляється без</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">підставки</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">(кнопка</span><span data-mce-mark=\"1\">CodeGate</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">відключатися</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">не може)</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">і цим пояснюється</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">порівняльна</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">низька вартість</span><span data-mce-mark=\"1\">&nbsp;</span><span data-mce-mark=\"1\">цієї моделі.</span></p>\n<p><span data-mce-mark=\"1\"><span data-mce-mark=\"1\"><span data-mce-mark=\"1\">Підтримує</span>&nbsp;<span data-mce-mark=\"1\">інтерфейси</span>&nbsp;<span data-mce-mark=\"1\">\"</span>розрив клавіатури\",&nbsp;<span data-mce-mark=\"1\">RS232</span>&nbsp;<span data-mce-mark=\"1\">і USB.</span>&nbsp;<span data-mce-mark=\"1\">Легко</span>&nbsp;<span data-mce-mark=\"1\">програмується</span>&nbsp;<span data-mce-mark=\"1\">за допомогою</span><span data-mce-mark=\"1\">штрихових</span>&nbsp;<span data-mce-mark=\"1\">кодів</span>&nbsp;<span data-mce-mark=\"1\">або програмного забезпечення</span>&nbsp;<span data-mce-mark=\"1\">для Windows.</span><br /><br /><span data-mce-mark=\"1\">Міцні гумові</span>&nbsp;<span data-mce-mark=\"1\">\"</span>бампери\" захищають&nbsp;<span data-mce-mark=\"1\">внутрішні</span>&nbsp;<span data-mce-mark=\"1\">оптичні</span>&nbsp;<span data-mce-mark=\"1\">деталі</span>&nbsp;<span data-mce-mark=\"1\">сканера</span>&nbsp;<span data-mce-mark=\"1\">від механічних</span>&nbsp;<span data-mce-mark=\"1\">пошкоджень</span>,<span data-mce-mark=\"1\">тим самим</span>&nbsp;<span data-mce-mark=\"1\">продовжуючи термін</span>&nbsp;<span data-mce-mark=\"1\">його експлуатації.</span><br /><br /><span data-mce-mark=\"1\">Модель</span>&nbsp;<strong><span data-mce-mark=\"1\">Metrologic</span>&nbsp;<span data-mce-mark=\"1\">5145</span>&nbsp;</strong><span data-mce-mark=\"1\">важить всього</span>&nbsp;<span data-mce-mark=\"1\">97г</span>&nbsp;<span data-mce-mark=\"1\">і має</span>&nbsp;<span data-mce-mark=\"1\">оптимальну</span>&nbsp;<span data-mce-mark=\"1\">форму для</span>&nbsp;<span data-mce-mark=\"1\">руки</span>,&nbsp;<span data-mce-mark=\"1\">що</span>&nbsp;<span data-mce-mark=\"1\">мінімізує</span>&nbsp;<span data-mce-mark=\"1\">втому при</span>&nbsp;<span data-mce-mark=\"1\">роботі</span>&nbsp;<span data-mce-mark=\"1\">і підвищує</span>&nbsp;<span data-mce-mark=\"1\">продуктивність.</span></span></span></p>\n<p>&nbsp;</p>\n<h4><span data-mce-mark=\"1\">Технічні характеристики</span><span data-mce-mark=\"1\">:</span></h4>\n<table border=\"0\">\n<tbody>\n<tr class=\"head_red\">\n<td align=\"center\">\n<p><span>Модель&nbsp;</span></p>\n</td>\n<td align=\"center\">\n<p><span>MS 5145 Eclipse&nbsp;</span></p>\n</td>\n</tr>\n<tr class=\"line_grey\">\n<td>\n<p><span>Джерело випромінювання</span></p>\n</td>\n<td align=\"center\">\n<p><span>Лазерний діод 650 нм</span></p>\n</td>\n</tr>\n<tr class=\"line_grey\">\n<td>\n<p><span>Глибина поля сканування</span></p>\n</td>\n<td align=\"center\">\n<p><span>0-140 мм для штрих-кодів 0.330 мм (13 mil)</span></p>\n</td>\n</tr>\n<tr class=\"line_grey\">\n<td>\n<p><span>Швидкість сканування</span></p>\n</td>\n<td align=\"center\">\n<p><span>72 сканування в сек.</span></p>\n</td>\n</tr>\n<tr class=\"line_grey\">\n<td>\n<p><span>Роздільна здатність</span></p>\n</td>\n<td align=\"center\">\n<p><span>0,102 мм</span></p>\n</td>\n</tr>\n<tr class=\"line_grey\">\n<td>\n<p><span>Контрастність</span></p>\n</td>\n<td align=\"center\">\n<p><span>35% різниця відбитогого світла</span></p>\n</td>\n</tr>\n<tr class=\"line_grey\">\n<td>\n<p><span>Схема сканування</span></p>\n</td>\n<td align=\"center\">\n<p><span>Лінійна</span></p>\n</td>\n</tr>\n<tr class=\"line_grey\">\n<td>\n<p><span>Декодовані коди</span></p>\n</td>\n<td align=\"center\">\n<p><span>Всі популярні лінійні штрих-коди</span></p>\n</td>\n</tr>\n<tr class=\"line_grey\">\n<td>\n<p><span>Інтерфейс підключення</span></p>\n</td>\n<td align=\"center\">\n<p><span>RS-232, KBW (в розрив клавіатури), USB, емуляція світового пера</span></p>\n</td>\n</tr>\n<tr class=\"line_grey\">\n<td>\n<p><span>Напруга живлення</span></p>\n</td>\n<td align=\"center\">\n<p><span>5 В &plusmn; 0,25В</span></p>\n</td>\n</tr>\n<tr class=\"line_grey\">\n<td>\n<p><span>Потужність</span></p>\n</td>\n<td align=\"center\">\n<p><span>675 мВт</span></p>\n</td>\n</tr>\n<tr class=\"line_grey\">\n<td>\n<p><span>Габаритні розміри, мм</span></p>\n</td>\n<td align=\"center\">\n<p><span>169x63x3</span></p>\n</td>\n</tr>\n<tr class=\"line_grey\">\n<td>\n<p><span>Вага, г</span></p>\n</td>\n<td align=\"center\">\n<p><span>97</span></p>\n</td>\n</tr>\n<tr class=\"line_grey\">\n<td>\n<p><span>Робоча температура</span></p>\n</td>\n<td align=\"center\">\n<p><span>Від 0&deg;С до + 54&deg;С</span></p>\n</td>\n</tr>\n<tr class=\"line_grey\">\n<td>\n<p><span>Температура зберігання</span></p>\n</td>\n<td align=\"center\">\n<p><span>Від &ndash; 20&deg;С до + 60&deg;С</span></p>\n</td>\n</tr>\n<tr class=\"line_grey\">\n<td>\n<p><span>Вологість</span></p>\n</td>\n<td align=\"center\">\n<p><span>Від 5 до 95% (при відсутності конденсату)</span></p>\n</td>\n</tr>\n<tr class=\"line_grey\">\n<td>\n<p><span>Стійкість до зовнішніх дій</span></p>\n</td>\n<td align=\"center\">\n<p><span>Витримує падіння з висоти 1,5 м</span></p>\n</td>\n</tr>\n</tbody>\n</table>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (283, 'ru', 'Сканер штрихкодів Vega V-1030', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (284, 'ru', 'Сканер штрихкодів Honeywell Voyager ® 1200g', '<p><strong>Honeywell Voyager &reg; 1200g</strong><span>&nbsp;забезпечує високоефективне сканування практично будь-яких лінійних штрихкодів, включаючи штрихкоди низької якості і пошкоджені штрих-коди.</span></p>', '<p><strong>Honeywell Voyager &reg; 1200g</strong><span>&nbsp;забезпечує високоефективне сканування практично будь-яких лінійних штрихкодів, включаючи штрихкоди низької якості і пошкоджені штрих-коди.</span></p>\n<p><span><span><strong>Voyager 1200g</strong>&nbsp;розроблений з урахуванням вимог щодо скорочення часу простою та зниження витрат на обслуговування, тому він містить друковану плату, встановлену на спеціальних амортизаторах, що дозволяє поліпшити захист від ударів. Утоплена кнопка, захищена спеціальним гумовим виступом, знижує ймовірність пошкодження при випадкових падіннях. Додаткова довговічність&nbsp;<strong>сканера</strong>забезпечується захищеним, стійким до подряпин скляним вікном з класом захисту IP42. Витримує множинні падіння з висоти 1,5 м.</span><br /><span><strong>Сканер</strong>&nbsp;має підвищену пропускну здатність завдяки застосуванню функцій виявлення об\'єктів, автоматичного визначення установки на підставку і настройки конфігурації. Підтримує кілька інтерфейсів. Наявність технології&nbsp;<strong>CodeGate &reg;</strong>&nbsp;дозволяє оператору переконатися в правильності сканування потрібного коду до передачі даних, що забезпечує ефективність застосування цього<strong>сканера</strong>&nbsp;для сканування з меню.</span></span></p>\n<p>&nbsp;</p>\n<p><strong><span>Технічні характеристики</span></strong></p>\n<table border=\"0\">\n<tbody>\n<tr>\n<td>\n<p><span>Тип скануючого елементу</span></p>\n</td>\n<td>\n<p><span>світлодіод 650 нм</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>Швидкість сканування</span></p>\n</td>\n<td>\n<p><span>100 ліній / сек</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>Декодовані коди</span></p>\n</td>\n<td>\n<p><span>1D</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>Температура експлуатації</span></p>\n</td>\n<td>\n<p><span>від 0 &deg; С до +50 &deg; С</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>Температура зберігання</span></p>\n</td>\n<td>\n<p><span>від -20 &deg; С до + 60 &deg; С</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>Вологість</span></p>\n</td>\n<td>\n<p><span>0 - 95% без конденсату</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>Інтерфейси</span></p>\n</td>\n<td>\n<p><span>RS232 (TTL +5 В, 4 сигналу), роз\'єм клавіатури,</span></p>\n<p><span>USB (HID / POS, IBM OEM); RS-232C (+ / -12 В) і</span></p>\n<p><span>IBM RS485 (через перехідний кабель)</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>Розміри</span></p>\n</td>\n<td>\n<p><span>66 мм х 180 мм х 97 мм</span></p>\n</td>\n</tr>\n<tr>\n<td>\n<p><span>Вага</span></p>\n</td>\n<td>\n<p><span>125 г</span></p>\n</td>\n</tr>\n</tbody>\n</table>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (285, 'ru', 'Сканер штрихкодів Honeywell MS 3580 Quantum USB', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (286, 'ru', 'Сканер штрихкодів Datalogic Magellan 1100i', '<p><span>&nbsp;Magellan 1000i - це фотозчитувач штрихкодів цілеспрямованної дії. Сканер штрих-кодів Magellan 1000i об\'єднує в собі кращі досягнення світлодіодної і лазерної технології сканування, що забезпечує чудову якість зчитування і високу механічну надійність. За рахунок застосування image технології сканер штрих-кодів Magellan 1000i забезпечує високу швидкість сканування і швидке декодування, як звичайних штрих кодів, так і пошкоджених, що істотно підвищує продуктивність і пропускну здатність.</span></p>', '<p><span><span>&nbsp;Magellan 1000i - це фотозчитувач штрихкодів цілеспрямованної дії. Сканер штрих-кодів Magellan 1000i об\'єднує в собі кращі досягнення світлодіодної і лазерної технології сканування, що забезпечує чудову якість зчитування і високу механічну надійність. За рахунок застосування image технології сканер штрих-кодів Magellan 1000i забезпечує високу швидкість сканування і швидке декодування, як звичайних штрих кодів, так і пошкоджених, що істотно підвищує продуктивність і пропускну здатність.</span></span></p>\n<p>При необхідності сканер можна перевести в режим одноплощинного сканування одним натисненням кнопки на корпусі. Дана функція стає незамінною при необхідності зчитати певний штрих -код з групи близько розташованих один з одним штрих - кодів , наприклад , з допоміжного аркуша з таблицею штрих - кодів на товари, які не мають штрих - коду на упаковці. При натисканні оператором на кнопку , розташовану в верхній частині сканера , сканер формує вузько спрямований пучок світла , який вказує операторові на область зчитування для прискорення і полегшення позиціонування необхідного штрих - коду.</p>\n<p>&nbsp; &nbsp; &nbsp;Сканер має невеликі габаритні розміри , що значно спрощує компоновку касового столу , покращує ергономіку робочого місця і економить робочий простір. Опціонально сканер може кріпитися на стаціонарній підставці. Підтримка сканером всіх поширених інтерфейсів підключення : RS232 , KBW , USB - спрощують інтеграцію сканера в різні системи товарного обліку . Можливе виконання сканера Magellan 1000i у двох колірних рішеннях корпусу - чорний і сірий.</p>\n<table border=\"0\">\n<tbody>\n<tr>\n<td><strong>Властивість</strong></td>\n<td><strong>Значення</strong></td>\n</tr>\n<tr>\n<td>Система зчитування</td>\n<td>Цілеспрямоване фотозчитування</td>\n</tr>\n<tr>\n<td>Швидкість зчитування</td>\n<td>1000</td>\n</tr>\n<tr>\n<td>Дальність сканування</td>\n<td>до 17 см при ширині штрихів 0,5мм</td>\n</tr>\n<tr>\n<td>Інтерфейси під\'єднання</td>\n<td>USB, RS232, KBW</td>\n</tr>\n<tr>\n<td>Зчитувані штрих-коди</td>\n<td>EAN/UPC/JAN+Add-on, Code 93, 128, 39,32, Codabar,Interleaved 2of5,MSI/Plessy. Chinese Post Code, QRCode</td>\n</tr>\n<tr>\n<td>Температура експлуатації</td>\n<td>від&nbsp;0&ordm;C до 40&ordm;С</td>\n</tr>\n<tr>\n<td>Вологість</td>\n<td>5%-95%</td>\n</tr>\n<tr>\n<td>Ударостійкість</td>\n<td>Витримує падіння з висоти 1,5м.</td>\n</tr>\n<tr>\n<td>Клас захисту</td>\n<td>IP 52</td>\n</tr>\n<tr>\n<td>Вага</td>\n<td>198г.</td>\n</tr>\n<tr>\n<td>Розміри</td>\n<td>84 х 71 х 94 мм</td>\n</tr>\n</tbody>\n</table>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (287, 'ru', 'Сканер штрихкодів Argox AS-8000', '<div><span>Модель Argox AS -8000 володіє герметичним корпусом , завдяки чому сканер має високий ступінь захисту від пилу і вологи. Гумова насадка на скануючої частини захищає вікно сканера від пошкоджень і подряпин , а також забезпечує міцність сканера при падіннях на тверду поверхню з висоти до 1,5 метра.</span></div>\n<div><span>Враховуючи всі вищеперелічені особливості , даний сканер можна рекомендувати для застосування в різних сферах торгівлі : на касовому вузлі невеликих по формату магазинів; в POS -системах як другий сканер для зчитування штрих - кодів з великогабаритних товарів в супер-і гіпермаркетах ; в аптеках і ювелірних магазинах для читання високощільних штрих - кодів ; а також на складах або в логістичних центрах.</span></div>', '<div><span>Модель Argox AS -8000 володіє герметичним корпусом , завдяки чому сканер має високий ступінь захисту від пилу і вологи. Гумова насадка на скануючої частини захищає вікно сканера від пошкоджень і подряпин , а також забезпечує міцність сканера при падіннях на тверду поверхню з висоти до 1,5 метра.</span></div>\n<div><span>Враховуючи всі вищеперелічені особливості , даний сканер можна рекомендувати для застосування в різних сферах торгівлі : на касовому вузлі невеликих по формату магазинів; в POS -системах як другий сканер для зчитування штрих - кодів з великогабаритних товарів в супер-і гіпермаркетах ; в аптеках і ювелірних магазинах для читання високощільних штрих - кодів ; а також на складах або в логістичних центрах.</span></div>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (288, 'ru', 'Принтер штрих-коду TSC TTP-246M PRO', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (289, 'ru', 'Принтер штрих-коду Термопринтер ZEBRA GK 420 D / T', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (290, 'ru', 'Ваги лабораторні ТВЕ', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (291, 'ru', 'Ваги аналітичні AS…/X', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (292, 'ru', 'Ваги лабораторні ТВЕ... 12-150 кг', '<p><a href=\"http://www.technowagy.com.ua/products.php?L=Ukr&amp;CategoryID=21\">Ваги лабораторні</a><span>&nbsp;загального призначення електронні ТВЕ призначені для визначення маси об\'єкту зважування у промисловості, сільському господарстві, медицині, науково&ndash;дослідних закладах.&nbsp;</span></p>', '<p><a href=\"http://www.technowagy.com.ua/products.php?L=Ukr&amp;CategoryID=21\">Ваги лабораторні</a><span>&nbsp;загального призначення електронні ТВЕ призначені для визначення маси об\'єкту зважування у промисловості, сільському господарстві, медицині, науково&ndash;дослідних закладах.&nbsp;</span></p>\n<p><span><strong>Переваги:</strong><span>&nbsp;</span><br /><br /><span>Висока точність ваг при великій границі зважування.</span><br /><span>Рідкокристалічний дисплей з підсвіткою.</span><br /><span>Зручність користування.</span><br /><span>Наявність усіх необхідних функцій.</span><br /><span>Час стабілізації показів - 3 сек.</span></span></p>\n<p>&nbsp;</p>\n<p><strong>Технічна інформація:</strong><span>&nbsp;</span><br /><br /><span>Функції ваг:</span><br /><span>- зважування у грамах або каратах;</span><br /><span>- компенсація маси тари;</span><br /><span>- рахування кількості штук;</span><br /><span>- автоматичне тестування та обнулення;</span><br /><span>- автоматичне вимикання дисплею відповідно до заданого часу;</span><br /><span>- зовнішнє калібрування.</span><br /><span>- RS 232, що дозволяє підключати вагу до принтера чи комп&rsquo;ютера.</span></p>\n<p><span>&nbsp;</span></p>\n<table style=\"width: 660px;\" cellspacing=\"0\" cellpadding=\"0\">\n<tbody>\n<tr>\n<td align=\"center\" bgcolor=\"#ebedec\"><strong>Назва ваги</strong></td>\n<td align=\"center\" bgcolor=\"#ebedec\"><strong>Дискретність,г</strong></td>\n<td align=\"center\" bgcolor=\"#ebedec\"><strong>Найменша<br />границя зважування,г</strong></td>\n<td align=\"center\" bgcolor=\"#ebedec\"><strong>Найбільша границя зважування,кг</strong></td>\n<td align=\"center\" bgcolor=\"#ebedec\"><strong>Розмір<br />платформи,мм</strong></td>\n<td align=\"center\" bgcolor=\"#ebedec\"><strong>Клас точності згідно з ГОСТ 24104-88</strong></td>\n<td align=\"center\" bgcolor=\"#ebedec\"><strong>Клас точності згідно з ДСТУ EN 45501</strong></td>\n<td align=\"center\" bgcolor=\"#ebedec\"><strong>Ціна&nbsp;<br />з ПДВ,<br />грн.</strong></td>\n</tr>\n<tr>\n<td align=\"center\">ТВЕ-12-0,2</td>\n<td align=\"center\">0,2</td>\n<td align=\"center\">10</td>\n<td align=\"center\">12</td>\n<td align=\"center\">250х300</td>\n<td align=\"center\">4</td>\n<td align=\"center\">ІІ</td>\n<td align=\"center\">3900</td>\n</tr>\n<tr>\n<td align=\"center\">ТВЕ-12-0,5</td>\n<td align=\"center\">0,5</td>\n<td align=\"center\">25</td>\n<td align=\"center\">12</td>\n<td align=\"center\">250x300</td>\n<td align=\"center\">4</td>\n<td align=\"center\">ІІ</td>\n<td align=\"center\">3600</td>\n</tr>\n<tr>\n<td align=\"center\">ТВЕ-24-0,5</td>\n<td align=\"center\">0,5</td>\n<td align=\"center\">25</td>\n<td align=\"center\">24</td>\n<td align=\"center\">250x300</td>\n<td align=\"center\">4</td>\n<td align=\"center\">ІІ</td>\n<td align=\"center\">3900</td>\n</tr>\n<tr>\n<td align=\"center\">ТВЕ-30-0,2</td>\n<td colspan=\"2\" align=\"center\">10</td>\n<td align=\"center\">30</td>\n<td align=\"center\">250х300</td>\n<td align=\"center\">4</td>\n<td align=\"center\">ІІ</td>\n<td align=\"center\">4800</td>\n</tr>\n<tr>\n<td align=\"center\">ТВЕ-30-0,5</td>\n<td align=\"center\">0,5</td>\n<td align=\"center\">10</td>\n<td align=\"center\">30</td>\n<td align=\"center\">250x300</td>\n<td align=\"center\">4</td>\n<td align=\"center\">ІІ</td>\n<td align=\"center\">4200</td>\n</tr>\n<tr>\n<td align=\"center\">ТВЕ-50-1</td>\n<td align=\"center\">1</td>\n<td colspan=\"2\" align=\"center\">50</td>\n<td align=\"center\">400x400</td>\n<td align=\"center\">4</td>\n<td align=\"center\">ІІ</td>\n<td align=\"center\">4350</td>\n</tr>\n<tr>\n<td align=\"center\">ТВЕ-60-1</td>\n<td align=\"center\">1</td>\n<td align=\"center\">50</td>\n<td align=\"center\">60</td>\n<td align=\"center\">400х400</td>\n<td align=\"center\">&nbsp;</td>\n<td align=\"center\">ІІ</td>\n<td align=\"center\">4620</td>\n</tr>\n<tr>\n<td align=\"center\">ТВЕ-60-2</td>\n<td align=\"center\">2</td>\n<td align=\"center\">100</td>\n<td align=\"center\">60</td>\n<td align=\"center\">400x400</td>\n<td align=\"center\">&nbsp;</td>\n<td align=\"center\">ІІ</td>\n<td align=\"center\">4350</td>\n</tr>\n<tr>\n<td align=\"center\">ТВЕ-120-2</td>\n<td align=\"center\">2</td>\n<td align=\"center\">100</td>\n<td align=\"center\">120</td>\n<td align=\"center\">400x400</td>\n<td align=\"center\">&nbsp;</td>\n<td align=\"center\">ІІ</td>\n<td align=\"center\">4395</td>\n</tr>\n<tr>\n<td align=\"center\">ТВЕ-120-5</td>\n<td align=\"center\">5</td>\n<td align=\"center\">400</td>\n<td align=\"center\">120</td>\n<td align=\"center\">400х400</td>\n<td align=\"center\">&nbsp;</td>\n<td align=\"center\">ІІ</td>\n<td align=\"center\">3900</td>\n</tr>\n<tr>\n<td align=\"center\">ТВЕ-120-2</td>\n<td align=\"center\">2</td>\n<td align=\"center\">250</td>\n<td align=\"center\">120</td>\n<td align=\"center\">400x560</td>\n<td align=\"center\">&nbsp;</td>\n<td align=\"center\">ІІ</td>\n<td align=\"center\">4620</td>\n</tr>\n<tr>\n<td align=\"center\">ТВЕ-150-5</td>\n<td align=\"center\">5</td>\n<td align=\"center\">400</td>\n<td align=\"center\">150</td>\n<td align=\"center\">400x400</td>\n<td align=\"center\">&nbsp;</td>\n<td align=\"center\">ІІ</td>\n<td align=\"center\">4620</td>\n</tr>\n<tr>\n<td align=\"center\">ТВЕ-300-5</td>\n<td align=\"center\">5</td>\n<td align=\"center\">1000</td>\n<td align=\"center\">300</td>\n<td align=\"center\">600х700</td>\n<td align=\"center\">&nbsp;</td>\n<td align=\"center\">ІІ</td>\n<td align=\"center\">6630</td>\n</tr>\n<tr>\n<td align=\"center\">ТВЕ-500-10</td>\n<td align=\"center\">10</td>\n<td align=\"center\">2000</td>\n<td align=\"center\">500</td>\n<td align=\"center\">800х800</td>\n<td align=\"center\">&nbsp;</td>\n<td align=\"center\">ІІ</td>\n<td align=\"center\">7500</td>\n</tr>\n<tr>\n<td align=\"center\">ТВЕ-600-10</td>\n<td align=\"center\">10</td>\n<td align=\"center\">2000</td>\n<td align=\"center\">600</td>\n<td align=\"center\">800х800</td>\n<td align=\"center\">&nbsp;</td>\n<td align=\"center\">ІІ</td>\n<td align=\"center\">8100</td>\n</tr>\n</tbody>\n</table>\n<p>&nbsp;</p>\n<p><strong>Додаткова інформація:</strong><span>&nbsp;</span><br /><br /><span>Робоча температура : від +10 до + 35С.</span><br /><span>Термін виготовлення - 2 дні.</span><br /><span>У ціну ваги&nbsp; входить також вартість повірки та доставки до клієнта.</span><br /><span>Ваги внесені у Держреєстр України за № У 2070-07.</span><br /><span>Гарантійний термін експлуатації &ndash; 2 роки.</span><br /><span>За бажанням Замовника ваги можуть бути виготовлені у наступних виконаннях:</span><br /><span>- у пиле-вологозахищеному;</span><br /><span>- у нержавіючому корозієстійкому;</span><br /><span>- у вибухозахищеному.&nbsp;</span><br /><span><br /></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (293, 'ru', 'Ваги фасовочні CERTUS Base СВС и СВСд', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (294, 'ru', 'Ваги торгові DIGI DS-788PM', '<p><span>Відмінною особливістю&nbsp;</span><strong>ваги Digi DS-788</strong><span>&nbsp;є те, що вона може працювати як від зовнішнього адаптеру мережі змінного струму, так і від акумулятора. Окрім цього,</span><strong>ваги</strong><span>&nbsp;мають таку додаткову опцію, як&nbsp;</span><strong>інтерфейс RS-232C</strong><span>, що робить можливим приєднання цих&nbsp;</span><strong>ваг</strong><span>&nbsp;до</span><strong>&nbsp;РРО</strong><span>, та до комп&rsquo;ютера. Поєднання цих характеристик з невисокою вартістю та ергономічним дизайном робить ці ваги вкрай зручними як для використання у магазинах різного типу, особливо у регіонах де можліві перепади з живленням, так і для торгівлі на вулицях або на ринках.</span></p>', '<p><span>Відмінною особливістю&nbsp;</span><strong>ваги Digi DS-788</strong><span>&nbsp;є те, що вона може працювати як від зовнішнього адаптеру мережі змінного струму, так і від акумулятора. Окрім цього,</span><strong>ваги</strong><span>&nbsp;мають таку додаткову опцію, як&nbsp;</span><strong>інтерфейс RS-232C</strong><span>, що робить можливим приєднання цих&nbsp;</span><strong>ваг</strong><span>&nbsp;до</span><strong>&nbsp;РРО</strong><span>, та до комп&rsquo;ютера. Поєднання цих характеристик з невисокою вартістю та ергономічним дизайном робить ці ваги вкрай зручними як для використання у магазинах різного типу, особливо у регіонах де можліві перепади з живленням, так і для торгівлі на вулицях або на ринках.</span></p>\n<p><span><strong>Модель ваг DS-788</strong>&nbsp;має усі необхідні для&nbsp;<strong>ваг</strong>&nbsp;подібного класу функції:</span></p>\n<ul>\n<li><span>&nbsp;Виклик з пам&rsquo;яті, заздалегідь запрограмованої для даного товару, ціни за кілограм</span></li>\n<li><span>&nbsp;Зважування, як без використання тари, так і з її використанням</span></li>\n<li><span>&nbsp;Визначення сумарної вартості декількох покупок з накопиченням підсумку</span></li>\n<li><span><span>&nbsp;Обчислення вартості товару</span></span>\n<p><span><strong>Переваги ваги Digi DS-788 :</strong><br /></span></p>\n<ul>\n<li>&nbsp;Яскравий світлодіодний дисплей, який привертає увагу покупців</li>\n<li>&nbsp;Великі цифри, які легко читаються</li>\n<li>&nbsp;Можливі варіанти живлення, як від мережі змінного струму, так і від акумулятора</li>\n<li>&nbsp;Заряду акумулятора при роботі в безперервному режимі вистачає на 12 годин</li>\n<li>&nbsp;Функція автоматичного відключення</li>\n<li>&nbsp;Вісім кнопок прямого доступу дозволяють виводити ціну за одиницю одним натисненням, тим самим, виключаючи можливість помилки</li>\n<li>&nbsp;Висока швидкість зважування\n<p><span><strong>Технічні характеристики:</strong></span></p>\n<table border=\"0\">\n<tbody>\n<tr>\n<td width=\"49%\"><span>Найбільша межа зважування і дискретність відліку<br /></span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>НГВ 3/6 кг d=е=1г/2 г, НГВ 6/15 кг d=е=2г/5г, НГВ 15/30 кг d=е=5г/10г<br /></span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Дисплей</span></td>\n<td valign=\"middle\">\n<p align=\"center\"><span>Світлодіодний</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Індикатор дисплея</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>Вага - 5 знаків<br />Ціна - 5 знаків<br />Вартість- 6 знаків</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Діапазон робочих температур</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>Від -10 до +40&deg;С</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Відносна вологість</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>до 85%</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"49%\"><span>Споживана потужність</span></td>\n<td width=\"51%\">\n<p align=\"center\"><span>Не більше 7,2 Вт</span></p>\n</td>\n</tr>\n</tbody>\n</table>\n</li>\n</ul>\n</li>\n</ul>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (295, 'ru', 'Ваги фасовочні DIGI DS-708 BM', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (296, 'ru', 'Ваги товарні JBS-700М', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (297, 'ru', 'Ваги товарні ВЕСТ', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (298, 'ru', 'Ваги товарні ЗЕВС ВПЕ', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (299, 'ru', 'Ваги фасовочні ВТЕ –Центровес -Т3Б', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (300, 'ru', 'Сканер штрихкодів Honeywell Voyager MS 9540', '<p><strong>Metrologic MS9540 Voyager</strong><span>&nbsp;-&nbsp;</span><strong>лазерний, ручний сканер</strong><span>&nbsp;з однією площиною сканування, є вдосконаленим аналогом&nbsp;</span><strong>сканера</strong><span>&nbsp;Metrologic MS 951.&nbsp;Стенд, який входить&nbsp;в комплект постачання, дозволяє використовувати&nbsp;</span><strong>сканер</strong><span>&nbsp;як стаціонарний пристрій.</span></p>', '<p><strong>Metrologic MS9540 Voyager</strong><span>&nbsp;-&nbsp;</span><strong>лазерний, ручний сканер</strong><span>&nbsp;з однією площиною сканування, є вдосконаленим аналогом&nbsp;</span><strong>сканера</strong><span>&nbsp;Metrologic MS 951.&nbsp;Стенд, який входить&nbsp;в комплект постачання, дозволяє використовувати&nbsp;</span><strong>сканер</strong><span>&nbsp;як стаціонарний пристрій.</span></p>\n<p><span><strong>Сканер має вбудований інфрачервоний сенсор</strong><span>, що забезпечує включення сканера при появі об&rsquo;єкта в області прочитування.</span><strong>Сканер Metrologic MS 9520 / 9540 Voyager</strong><span>&nbsp;може працювати як в стаціонарному, так і в переносному режимі,&nbsp;ним можна користуватися і як стаціонарним і як ручним сканером. Окрім безлічі функціональних можливостей, Voyager обладнаний знімними кабелями PowerLink, блоком живлення, утилітою&nbsp;</span><strong>штрих-кодового програмування</strong><span>&nbsp;MetroSelect&reg;, Windows-утилітою настройки MetroSet&reg;, утилітою редагування даних Bits n&rsquo; Pieces&reg; і функцією відстежування Electronic Article Surveillance (EAS).</span><br /><strong>Metrologic MS 9520 / 9540&nbsp;Voyager</strong><span>&nbsp;ідеально підходить для багатьох застосувань, таких як, наприклад, POS-системи, системи інвентаризації і управління складами, торгових підприємств. Завдяки продуктивності і зручності використання Voyager набагато перевершує навіть самі передові сканери на ринку.</span><br /><strong>Metrologic MS 9520 / 9540 Voyager</strong><span>&nbsp;здатний декодувати стандарт Reduced Space Symbology, що недавно з&rsquo;явився (RSS). Цей стандарт починають використовувати у сфері охорони здоров&rsquo;я і торгівлі медпрепаратами, а також в супермаркетах.</span></span></p>\n<p>&nbsp;</p>\n<p><span><strong>Інтерфейс підключення Metrologic MS9520 / 9540 Voyager:</strong><br /></span></p>\n<ul>\n<li><span>Metrologic MS 9540 Voyager RS-232 (COM-порт, послідовний порт, або RS-сканери)</span></li>\n<li><span>Metrologic MS 9540 Voyager KB (keyboard, &laquo;в розрив клавіатури&raquo;)</span></li>\n<li><span>Metrologic MS 9540 Voyager USB (сканери цього інтерфейсу бувають в 2-х варіантах виконання: POS emulation (це теж саме, що і RS-232) і KB emulation (це теж саме, що і в &ldquo;розрив клавіатури&rdquo;).</span></li>\n</ul>\n<p><span><strong>Технічні характеристики:</strong></span></p>\n<table border=\"1\" cellspacing=\"1\" cellpadding=\"1\">\n<tbody>\n<tr>\n<td width=\"262\">\n<p lang=\"uk-UA\"><span>Швидкість сканування</span></p>\n</td>\n<td width=\"271\">\n<p lang=\"uk-UA\" align=\"center\"><span>72 сканування в секунду</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"262\">\n<p lang=\"uk-UA\"><span>Площина сканування</span></p>\n</td>\n<td width=\"271\">\n<p lang=\"uk-UA\" align=\"center\"><span>1 площина</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"262\">\n<p lang=\"uk-UA\"><span>Максимальна ширина захоплення</span></p>\n</td>\n<td width=\"271\">\n<p align=\"center\"><span lang=\"uk-UA\">297 мм</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"262\">\n<p lang=\"uk-UA\"><span>Відстань читання</span></p>\n</td>\n<td width=\"271\">\n<p lang=\"uk-UA\" align=\"center\"><span>До 254 мм</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"262\">\n<p lang=\"uk-UA\"><span lang=\"uk-UA\">Роздільна здатність</span></p>\n</td>\n<td width=\"271\">\n<p align=\"center\"><span lang=\"uk-UA\">0,127 мм</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"262\">\n<p lang=\"uk-UA\"><span>Коди, які зчитуються</span></p>\n</td>\n<td width=\"271\">\n<p lang=\"uk-UA\" align=\"center\"><span><span lang=\"uk-UA\">Всі поширені&nbsp;</span><span lang=\"ru-RU\">штрих-коди</span></span></p>\n</td>\n</tr>\n<tr>\n<td width=\"262\"><span>Діапазон робочих температур</span></td>\n<td width=\"271\">\n<p align=\"center\"><span>0&deg;С ~ +40&deg;С</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"262\"><span lang=\"uk-UA\">Живлення</span></td>\n<td width=\"271\">\n<p lang=\"uk-UA\" align=\"center\"><span>5V<span lang=\"uk-UA\">&nbsp;</span><span lang=\"ru-RU\">DC</span></span></p>\n</td>\n</tr>\n<tr>\n<td width=\"262\"><span>Габаритні розміри<span lang=\"uk-UA\">,&nbsp;</span>мм</span></td>\n<td width=\"271\">\n<p lang=\"uk-UA\" align=\"center\"><span>78х198х40</span></p>\n</td>\n</tr>\n<tr>\n<td width=\"262\"><span>Вага</span></td>\n<td width=\"271\">\n<p align=\"center\"><span>149г</span></p>\n</td>\n</tr>\n</tbody>\n</table>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (301, 'ru', 'Лічильник банкнот SPEED LD 60A', '<p><span class=\"notranslate\"><strong>Лічильники банкнот SPEED LD-60А</strong>&nbsp;є точними, надійними, високошвидкісними автоматичними машинами.</span><span>&nbsp;</span><span class=\"notranslate\">Вони були розроблені для об\'єднання багатьох корисних якостей, для простоти використання і обслуговування.</span><span>&nbsp;</span><span class=\"notranslate\">Можливість підключення виносного дисплея, робить лічильник дуже зручним для роботи операторів з клієнтами.</span></p>', '<p><span class=\"notranslate\"><strong>Лічильники банкнот SPEED LD-60А</strong>&nbsp;є точними, надійними, високошвидкісними автоматичними машинами.</span><span>&nbsp;</span><span class=\"notranslate\">Вони були розроблені для об\'єднання багатьох корисних якостей, для простоти використання і обслуговування.</span><span>&nbsp;</span><span class=\"notranslate\">Можливість підключення виносного дисплея, робить лічильник дуже зручним для роботи операторів з клієнтами.</span></p>\n<h3><span><span class=\"notranslate\">Основні переваги SPEED LD-60А:</span></span></h3>\n<ul>\n<li><span><span class=\"notranslate\">Посилена механічна конструкція, вільна від мастила протягом тривалого часу.</span></span></li>\n<li><span><span class=\"notranslate\">Розширені підкидають ролики, що забезпечує рівномірне перегортання банкнот.</span></span></li>\n<li><span><span class=\"notranslate\">Використання в перегортає механізмі поліуретанових роликів і накладок, що забезпечує довгу роботу цих вузлів без обслуговування.</span></span></li>\n<li><span><span class=\"notranslate\">Використання високоякісної гуми на всіх транспортних роликах.</span></span></li>\n<li><span><span class=\"notranslate\">Використання високоякісної пластмаси для деталей корпусу.</span></span></li>\n<li><span><span class=\"notranslate\">Цифрове управління (FUZZY LOGIC).</span></span></li>\n<li><span><span class=\"notranslate\">Просте використання регулювання перегортає механізму за допомогою регулювального болта, що забезпечує додаткову зручність оператора без залучення сервісного інженера.</span></span></li>\n<li><span><span class=\"notranslate\">Налаштування всіх детекцій оператором, знаючи інструкцію налаштувань, досвідченим шляхом, без залучення сервісного інженера.</span></span></li>\n<li><span><span class=\"notranslate\">Вологостійка панель управління.</span></span></li>\n<li><span><span class=\"notranslate\">Можливість підключення виносного дисплея.</span></span></li>\n<li><span><span class=\"notranslate\">Саме тестування при включенні.</span></span></li>\n<li><span><span class=\"notranslate\"><strong>Перевірка достовірності купюри УФ детектором.</strong></span></span></li>\n<li><span><span class=\"notranslate\">Перевірка справжності купюри по оптичній щільності.</span></span></li>\n<li><span><span class=\"notranslate\">Перевірка справжності купюри по її розміром.</span></span></li>\n</ul>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (302, 'ru', 'Детектор валют ДЕКО-60', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (303, 'ru', 'Термоетикетка 40х25TECO/2000', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (304, 'ru', 'Ваги товарні BDU...30-150', '<p><span>Ваги складаються: з корпуса (з елементами захисту від перенавантаження), приймальної платформи (полірована&nbsp; нержавійка), стійки (опція, виконання BDU...C), 4 ніжок, одного високоточного тензометричного датчика сили з класом захисту IP67 (Іспанія) та вагопроцесора ME-01/A/18/RS/..(висота цифр 18мм, LED,IP65 ) \"AXIS\" Європа.</span></p>', '<p align=\"justify\"><span style=\"color: #000000;\">&nbsp;Ваги складаються: з корпуса (з елементами захисту від перенавантаження), приймальної платформи (полірована&nbsp; нержавійка), стійки (опція, виконання BDU...C), 4 ніжок, одного високоточного тензометричного датчика сили з класом захисту IP67 (Іспанія) та вагопроцесора ME-01/A/18/RS/..(висота цифр 18мм, LED,IP65 ) \"AXIS\" Європа.</span></p>\n<p align=\"justify\"><strong>ПЕРЕВАГИ:</strong></p>\n<div align=\"justify\">1. Висока точність та швидкість зважування;</div>\n<div align=\"justify\">2. Солідна, безвідказна конструкція з елементами захисту від перенавантаження;</div>\n<div align=\"justify\">3. Призначені для інтенсивного використання;</div>\n<div align=\"justify\">4. Розмір платформи 400*400мм;</div>\n<div align=\"justify\">5. Приймальна платформа виготовлена з харчової полірованої нержавіючої сталі;</div>\n<div align=\"justify\">6. Можливе виконня з кріпленням модуля: на платформі ваги (стандарт), на кабелі, на стійці;</div>\n<div align=\"justify\">7. Індикація LED, яка легко читається;</div>\n<div align=\"justify\">8. Високоякісні комплектуючі.&nbsp;</div>\n<div align=\"center\"><strong>Технічні характеристики</strong></div>\n<center>\n<table border=\"0\">\n<tbody>\n<tr class=\"head_red\">\n<td align=\"center\" width=\"150\">Модель</td>\n<td align=\"center\">BDU30-0,5-0404</td>\n<td align=\"center\">BDU60-1-0404</td>\n<td align=\"center\">BDU150-5-0404</td>\n</tr>\n<tr class=\"line_grey\">\n<td align=\"left\">НмГЗ, кг</td>\n<td align=\"center\">0,01</td>\n<td align=\"center\">0,02</td>\n<td align=\"center\">0,1</td>\n</tr>\n<tr class=\"line_grey\">\n<td align=\"left\">НГЗ, кг</td>\n<td align=\"center\">30</td>\n<td align=\"center\">60</td>\n<td align=\"center\">150</td>\n</tr>\n<tr class=\"line_grey\">\n<td align=\"left\">Дискретність відліку, г</td>\n<td align=\"center\">0,5</td>\n<td align=\"center\">1</td>\n<td align=\"center\">5</td>\n</tr>\n<tr class=\"line_grey\">\n<td align=\"left\">Вибирання маси тари, кг</td>\n<td align=\"center\">30</td>\n<td align=\"center\">60</td>\n<td align=\"center\">150</td>\n</tr>\n<tr class=\"line_grey\">\n<td align=\"left\">Діапазон температури, t</td>\n<td colspan=\"3\" align=\"center\">&nbsp; -10...40 &deg;С</td>\n</tr>\n<tr class=\"line_grey\">\n<td align=\"left\">Тип індикатора</td>\n<td colspan=\"3\" align=\"center\">&nbsp;світлодіодний (LED)</td>\n</tr>\n<tr class=\"line_grey\">\n<td align=\"left\">Габаритні розміри, мм</td>\n<td colspan=\"3\" align=\"center\">400&times;400&times;120</td>\n</tr>\n<tr class=\"line_grey\">\n<td align=\"left\">Живлення, В</td>\n<td colspan=\"3\" align=\"center\">&nbsp;220</td>\n</tr>\n<tr class=\"line_grey\">\n<td align=\"left\">Маса, кг</td>\n<td colspan=\"3\" align=\"center\">10,5 / 12</td>\n</tr>\n<tr class=\"line_grey\">\n<td><strong>ЦІНА (з ПДВ), грн.&nbsp;</strong></td>\n<td colspan=\"3\" align=\"center\"><span><span style=\"color: #ff0000;\"><strong>3590</strong></span></span></td>\n</tr>\n</tbody>\n</table>\n<p>&nbsp;</p>\n</center>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (305, 'ru', 'Ваги фасовочні Штрих-Слим', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (306, 'ru', 'Фіскальний реєстратор Марія 304Т', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (307, 'ru', 'Фіскальний реєстратор ІКС-Е810Т', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (308, 'ru', 'Ваги торгові Mettler Toledo NEW', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (309, 'ru', 'Фіскальний реєстратор Екселліо FP2000', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (310, 'ru', 'Сканер штрихкоду Proton IMS-3190', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (311, 'ru', 'Термоетикетка 58х30 TECO', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (312, 'ru', 'Термоетикетка 58х40 ECO', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (313, 'ru', 'Термоетикетка 58х40 пр ECO', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (314, 'ru', 'РРО NEON-W', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (315, 'ru', 'Фіскальний реєстратор Datecs FP-T88', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (316, 'ru', 'Етикет-пістолет Open C20', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (317, 'ru', 'Етикет-пістолет Blitz PH', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (318, 'ru', 'Етикет-пістолет Blitz M6', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (319, 'ru', 'Етикет-пістолет Blitz C20', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (320, 'ru', 'Фіскальний реєстратор Datecs FP-T320', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (321, 'ru', 'РРО Екселліо DP-25', '                                                                            ', '                                                                            ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (322, 'ru', 'РРО Екселліо DP-05', '                                                                            ', '                                                                            ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (323, 'ru', 'РРО Екселліо DP-35', '                                                                            ', '                                                                            ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (327, 'ru', 'РРО  Datecs МР-01', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (329, 'ru', 'Ваги торгові ВТД-ЕЛ', '', '', '', NULL, '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (324, 'ru', 'РРО Екселліо DP-45', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (325, 'ru', 'Фіскальний реєстратор Екселліо FPU 550ES', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: shop_products_rating
#

DROP TABLE IF EXISTS shop_products_rating;

CREATE TABLE `shop_products_rating` (
  `product_id` int(11) NOT NULL,
  `votes` int(11) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (71, 1, 2);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (81, 1, 5);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (88, 1, 1);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (76, 3, 11);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (82, 1, 4);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (77, 2, 7);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (73, 1, 2);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (108, 2, 6);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (72, 1, 5);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (74, 2, 8);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (75, 2, 9);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (94, 1, 4);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (87, 1, 5);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (79, 1, 5);


#
# TABLE STRUCTURE FOR: shop_rbac_group
#

DROP TABLE IF EXISTS shop_rbac_group;

CREATE TABLE `shop_rbac_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (1, 'shop', 'ShopAdminBanners', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (2, 'shop', 'ShopAdminBrands', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (3, 'shop', 'ShopAdminCallbacks', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (4, 'shop', 'ShopAdminCategories', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (5, 'shop', 'ShopAdminCharts', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (6, 'shop', 'ShopAdminComulativ', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (7, 'shop', 'ShopAdminCurrencies', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (8, 'shop', 'ShopAdminCustomfields', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (9, 'shop', 'ShopAdminDashboard', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (10, 'shop', 'ShopAdminDeliverymethods', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (11, 'shop', 'ShopAdminDiscounts', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (12, 'shop', 'ShopAdminGifts', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (13, 'shop', 'ShopAdminKits', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (14, 'shop', 'ShopAdminNotifications', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (15, 'shop', 'ShopAdminNotificationstatuses', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (16, 'shop', 'ShopAdminOrders', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (17, 'shop', 'ShopAdminOrderstatuses', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (18, 'shop', 'ShopAdminPaymentmethods', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (19, 'shop', 'ShopAdminProducts', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (20, 'shop', 'ShopAdminProductspy', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (21, 'shop', 'ShopAdminProperties', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (22, 'shop', 'ShopAdminRbac', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (23, 'shop', 'ShopAdminSearch', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (24, 'shop', 'ShopAdminSettings', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (25, 'shop', 'ShopAdminSystem', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (26, 'shop', 'ShopAdminUsers', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (27, 'shop', 'ShopAdminWarehouses', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (28, 'base', 'Admin', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (29, 'base', 'Admin_logs', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (30, 'base', 'Admin_search', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (31, 'base', 'Backup', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (32, 'base', 'Cache_all', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (33, 'base', 'Categories', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (34, 'base', 'Components', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (35, 'base', 'Dashboard', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (36, 'base', 'Languages', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (37, 'base', 'Login', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (39, 'base', 'Pages', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (40, 'base', 'Rbac', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (41, 'base', 'Settings', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (43, 'module', 'Cfcm', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (44, 'module', 'Comments', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (45, 'module', 'Feedback', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (46, 'module', 'Gallery', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (47, 'module', 'Group_mailer', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (48, 'module', 'Mailer', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (49, 'module', 'Menu', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (50, 'module', 'Rss', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (51, 'module', 'Sample_mail', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (53, 'module', 'Share', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (54, 'module', 'Sitemap', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (55, 'module', 'Social_servises', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (56, 'module', 'Template_editor', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (57, 'module', 'Trash', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (58, 'module', 'User_manager', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (59, 'base', 'Widgets_manager', NULL);


#
# TABLE STRUCTURE FOR: shop_rbac_group_i18n
#

DROP TABLE IF EXISTS shop_rbac_group_i18n;

CREATE TABLE `shop_rbac_group_i18n` (
  `id` int(11) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `locale` varchar(5) NOT NULL,
  KEY `id_idx` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (1, 'Управление баннерами', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (2, 'Управление брендами', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (3, 'Управление колбеками', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (4, 'Управление категориями товаров в магазине', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (5, 'Управление статистикой', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (6, 'Управление накопительными скидками', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (7, 'Управление валютами', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (8, 'Управление дополнительными полями для магазина', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (9, 'Главная страница панели управления магазином', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (10, 'Управление способами доставки', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (11, 'Управление скидками', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (12, 'Управление подарочными сертификатами', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (13, 'Управление наборами товаров', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (14, 'Управление уведомлениями', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (15, 'Управление статусами уведомлений', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (16, 'Управление заказами', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (17, 'Управление статусами заказов', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (18, 'Управление методами оплаты', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (19, 'Управление товарами', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (20, 'Управление слежением за товарами', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (21, 'Управление свойствами товаров', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (23, 'Управление поиском', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (24, 'Управление настройками магазина', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (25, 'Управление системой магазина (импорт\\экспорт)', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (26, 'Управление юзерами магазина', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (27, 'Управление складами', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (28, 'Доступ к админпанели', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (29, 'История событий', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (30, 'Управление поиском в базовой админ панели', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (31, 'Управление бекапами', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (32, 'Управление кэшем', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (33, 'Управление категориями сайта', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (34, 'Управление компонентами сайта', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (35, 'Управление главной станицой базовой админ панели', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (36, 'Управление языками', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (37, 'Вход в админпанель', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (38, 'Поиск модулей для установки', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (39, 'Управление страницами', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (40, 'Управление правами доступа', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (41, 'Управление базовыми настройками', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (42, 'Управление обновлением системы', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (43, 'Управление констуктором полей', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (44, 'Управление комментариями', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (45, 'Управление обратной связью', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (46, 'Управление галереей', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (47, 'Управление модулем рассылки', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (48, 'Управление модулем подписки и рассылки', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (49, 'Управление меню', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (50, 'Управление модулем RSS', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (51, 'Управление шаблонами писем', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (52, 'Шаблон модуля', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (53, 'Управление модулем кнопок соцсетей', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (54, 'Управление модулем карта сайта', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (55, 'Управление модулем интеграции с соцсетями', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (56, 'Управление модулем редактор шаблонов', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (57, 'Управление модулем перенаправления', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (58, 'Управление пользователями', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (59, 'Управление виджетами', 'ru');


#
# TABLE STRUCTURE FOR: shop_rbac_privileges
#

DROP TABLE IF EXISTS shop_rbac_privileges;

CREATE TABLE `shop_rbac_privileges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `group_id` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_rbac_privileges_I_1` (`name`),
  KEY `shop_rbac_privileges_FI_1` (`group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=485 DEFAULT CHARSET=utf8;

INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (1, 'ShopAdminBanners::index', 1, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (2, 'ShopAdminBanners::create', 1, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (3, 'ShopAdminBanners::edit', 1, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (4, 'ShopAdminBanners::deleteAll', 1, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (5, 'ShopAdminBanners::translate', 1, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (6, 'ShopAdminBanners::changeActive', 1, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (7, 'ShopAdminBrands::index', 2, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (8, 'ShopAdminBrands::create', 2, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (9, 'ShopAdminBrands::edit', 2, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (10, 'ShopAdminBrands::delete', 2, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (11, 'ShopAdminBrands::c_list', 2, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (12, 'ShopAdminBrands::translate', 2, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (13, 'ShopAdminCallbacks::index', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (14, 'ShopAdminCallbacks::update', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (15, 'ShopAdminCallbacks::statuses', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (16, 'ShopAdminCallbacks::createStatus', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (17, 'ShopAdminCallbacks::updateStatus', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (18, 'ShopAdminCallbacks::setDefaultStatus', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (19, 'ShopAdminCallbacks::changeStatus', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (20, 'ShopAdminCallbacks::reorderThemes', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (21, 'ShopAdminCallbacks::changeTheme', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (22, 'ShopAdminCallbacks::deleteCallback', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (23, 'ShopAdminCallbacks::deleteStatus', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (24, 'ShopAdminCallbacks::themes', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (25, 'ShopAdminCallbacks::createTheme', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (26, 'ShopAdminCallbacks::updateTheme', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (27, 'ShopAdminCallbacks::deleteTheme', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (28, 'ShopAdminCallbacks::search', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (29, 'ShopAdminCategories::index', 4, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (30, 'ShopAdminCategories::create', 4, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (31, 'ShopAdminCategories::edit', 4, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (32, 'ShopAdminCategories::delete', 4, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (33, 'ShopAdminCategories::c_list', 4, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (34, 'ShopAdminCategories::save_positions', 4, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (35, 'ShopAdminCategories::ajax_translit', 4, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (36, 'ShopAdminCategories::translate', 4, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (37, 'ShopAdminCategories::changeActive', 4, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (38, 'ShopAdminCategories::create_tpl', 4, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (39, 'ShopAdminCategories::get_tpl_names', 4, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (40, 'ShopAdminCharts::orders', 5, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (41, 'ShopAdminCharts::byDate', 5, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (42, 'ShopAdminCharts::_createDatesDropDown', 5, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (43, 'ShopAdminComulativ::index', 6, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (44, 'ShopAdminComulativ::create', 6, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (45, 'ShopAdminComulativ::edit', 6, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (46, 'ShopAdminComulativ::allUsers', 6, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (47, 'ShopAdminComulativ::user', 6, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (48, 'ShopAdminComulativ::deleteAll', 6, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (49, 'ShopAdminComulativ::change_comulativ_dis_status', 6, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (50, 'ShopAdminCurrencies::index', 7, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (51, 'ShopAdminCurrencies::create', 7, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (52, 'ShopAdminCurrencies::edit', 7, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (53, 'ShopAdminCurrencies::makeCurrencyDefault', 7, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (54, 'ShopAdminCurrencies::makeCurrencyMain', 7, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (55, 'ShopAdminCurrencies::delete', 7, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (56, 'ShopAdminCurrencies::recount', 7, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (57, 'ShopAdminCurrencies::checkPrices', 7, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (58, 'ShopAdminCustomfields::index', 8, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (59, 'ShopAdminCustomfields::create', 8, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (60, 'ShopAdminCustomfields::edit', 8, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (61, 'ShopAdminCustomfields::deleteAll', 8, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (62, 'ShopAdminCustomfields::change_status_activ', 8, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (63, 'ShopAdminCustomfields::change_status_private', 8, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (64, 'ShopAdminCustomfields::change_status_required', 8, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (65, 'ShopAdminDashboard::index', 9, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (66, 'ShopAdminDeliverymethods::index', 10, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (67, 'ShopAdminDeliverymethods::create', 10, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (68, 'ShopAdminDeliverymethods::change_delivery_status', 10, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (69, 'ShopAdminDeliverymethods::edit', 10, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (70, 'ShopAdminDeliverymethods::deleteAll', 10, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (71, 'ShopAdminDeliverymethods::c_list', 10, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (72, 'ShopAdminDiscounts::index', 11, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (73, 'ShopAdminDiscounts::create', 11, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (74, 'ShopAdminDiscounts::change_discount_status', 11, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (75, 'ShopAdminDiscounts::edit', 11, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (76, 'ShopAdminDiscounts::deleteAll', 11, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (77, 'ShopAdminGifts::index', 12, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (78, 'ShopAdminGifts::create', 12, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (79, 'ShopAdminGifts::generateKey', 12, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (80, 'ShopAdminGifts::delete', 12, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (81, 'ShopAdminGifts::edit', 12, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (82, 'ShopAdminGifts::ChangeActive', 12, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (83, 'ShopAdminGifts::settings', 12, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (84, 'ShopAdminGifts::save_settings', 12, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (85, 'ShopAdminKits::index', 13, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (86, 'ShopAdminKits::kit_create', 13, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (87, 'ShopAdminKits::kit_edit', 13, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (88, 'ShopAdminKits::kit_save_positions', 13, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (89, 'ShopAdminKits::kit_change_active', 13, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (90, 'ShopAdminKits::kit_list', 13, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (91, 'ShopAdminKits::kit_delete', 13, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (92, 'ShopAdminKits::get_products_list', 13, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (93, 'ShopAdminNotifications::index', 14, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (94, 'ShopAdminNotifications::edit', 14, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (95, 'ShopAdminNotifications::changeStatus', 14, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (96, 'ShopAdminNotifications::notifyByEmail', 14, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (97, 'ShopAdminNotifications::deleteAll', 14, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (98, 'ShopAdminNotifications::ajaxDeleteNotifications', 14, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (99, 'ShopAdminNotifications::ajaxChangeNotificationsStatus', 14, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (100, 'ShopAdminNotifications::search', 14, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (101, 'ShopAdminNotifications::getAvailableNotification', 14, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (102, 'ShopAdminNotificationstatuses::index', 15, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (103, 'ShopAdminNotificationstatuses::create', 15, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (104, 'ShopAdminNotificationstatuses::edit', 15, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (105, 'ShopAdminNotificationstatuses::deleteAll', 15, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (106, 'ShopAdminNotificationstatuses::savePositions', 15, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (107, 'ShopAdminOrders::index', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (108, 'ShopAdminOrders::edit', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (109, 'ShopAdminOrders::changeStatus', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (110, 'ShopAdminOrders::changePaid', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (111, 'ShopAdminOrders::delete', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (112, 'ShopAdminOrders::ajaxDeleteOrders', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (113, 'ShopAdminOrders::ajaxChangeOrdersStatus', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (114, 'ShopAdminOrders::ajaxChangeOrdersPaid', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (115, 'ShopAdminOrders::ajaxEditWindow', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (116, 'ShopAdminOrders::editKit', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (117, 'ShopAdminOrders::ajaxEditAddToCartWindow', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (118, 'ShopAdminOrders::ajaxDeleteProduct', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (119, 'ShopAdminOrders::ajaxGetProductList', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (120, 'ShopAdminOrders::ajaxEditOrderCart', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (121, 'ShopAdminOrders::ajaxEditOrderAddToCart', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (122, 'ShopAdminOrders::ajaxGetOrderCart', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (123, 'ShopAdminOrders::search', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (124, 'ShopAdminOrders::printChecks', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (125, 'ShopAdminOrders::createPDFPage', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (126, 'ShopAdminOrders::createPdf', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (127, 'ShopAdminOrders::create', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (128, 'ShopAdminOrderstatuses::index', 17, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (129, 'ShopAdminOrderstatuses::create', 17, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (130, 'ShopAdminOrderstatuses::edit', 17, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (131, 'ShopAdminOrderstatuses::delete', 17, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (132, 'ShopAdminOrderstatuses::ajaxDeleteWindow', 17, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (133, 'ShopAdminOrderstatuses::savePositions', 17, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (134, 'ShopAdminPaymentmethods::index', 18, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (135, 'ShopAdminPaymentmethods::create', 18, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (136, 'ShopAdminPaymentmethods::change_payment_status', 18, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (137, 'ShopAdminPaymentmethods::edit', 18, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (138, 'ShopAdminPaymentmethods::deleteAll', 18, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (139, 'ShopAdminPaymentmethods::savePositions', 18, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (140, 'ShopAdminPaymentmethods::getAdminForm', 18, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (141, 'ShopAdminProducts::index', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (142, 'ShopAdminProducts::create', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (143, 'ShopAdminProducts::edit', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (144, 'ShopAdminProducts::saveAdditionalImages', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (145, 'ShopAdminProducts::delete', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (146, 'ShopAdminProducts::processImage', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (147, 'ShopAdminProducts::deleteAddImage', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (148, 'ShopAdminProducts::ajaxChangeActive', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (149, 'ShopAdminProducts::ajaxChangeHit', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (150, 'ShopAdminProducts::ajaxChangeHot', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (151, 'ShopAdminProducts::ajaxChangeAction', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (152, 'ShopAdminProducts::ajaxUpdatePrice', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (153, 'ShopAdminProducts::ajaxCloneProducts', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (154, 'ShopAdminProducts::ajaxDeleteProducts', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (155, 'ShopAdminProducts::ajaxMoveWindow', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (156, 'ShopAdminProducts::ajaxMoveProducts', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (157, 'ShopAdminProducts::translate', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (158, 'ShopAdminProducts::get_ids', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (159, 'ShopAdminProducts::prev_next', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (160, 'ShopAdminProductspy::index', 20, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (161, 'ShopAdminProductspy::delete', 20, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (162, 'ShopAdminProductspy::settings', 20, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (163, 'ShopAdminProperties::index', 21, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (164, 'ShopAdminProperties::create', 21, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (165, 'ShopAdminProperties::edit', 21, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (166, 'ShopAdminProperties::renderForm', 21, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (167, 'ShopAdminProperties::save_positions', 21, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (168, 'ShopAdminProperties::delete', 21, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (169, 'ShopAdminProperties::changeActive', 21, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (184, 'ShopAdminSearch::index', 23, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (185, 'ShopAdminSearch::save_positions_variant', 23, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (186, 'ShopAdminSearch::autocomplete', 23, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (187, 'ShopAdminSearch::advanced', 23, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (188, 'ShopAdminSearch::renderCustomFields', 23, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (189, 'ShopAdminSettings::index', 24, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (190, 'ShopAdminSettings::update', 24, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (191, 'ShopAdminSettings::get_fsettings', 24, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (192, 'ShopAdminSettings::get_vsettings', 24, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (193, 'ShopAdminSettings::_get_templates', 24, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (194, 'ShopAdminSettings::_load_settings', 24, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (195, 'ShopAdminSettings::runResize', 24, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (196, 'ShopAdminSystem::import', 25, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (197, 'ShopAdminSystem::export', 25, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (198, 'ShopAdminSystem::getAttributes', 25, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (199, 'ShopAdminSystem::exportUsers', 25, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (200, 'ShopAdminUsers::index', 26, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (201, 'ShopAdminUsers::search', 26, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (202, 'ShopAdminUsers::create', 26, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (203, 'ShopAdminUsers::edit', 26, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (204, 'ShopAdminUsers::deleteAll', 26, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (205, 'ShopAdminUsers::auto_complite', 26, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (206, 'ShopAdminWarehouses::index', 27, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (207, 'ShopAdminWarehouses::create', 27, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (208, 'ShopAdminWarehouses::edit', 27, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (209, 'ShopAdminWarehouses::deleteAll', 27, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (210, 'Admin::__construct', 28, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (211, 'Admin::init', 28, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (212, 'Admin::index', 28, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (213, 'Admin::sys_info', 28, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (214, 'Admin::delete_cache', 28, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (215, 'Admin::elfinder_init', 28, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (216, 'Admin::get_csrf', 28, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (217, 'Admin::sidebar_cats', 28, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (218, 'Admin::logout', 28, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (219, 'Admin::report_bug', 28, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (220, 'Admin_logs::__construct', 29, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (221, 'Admin_logs::index', 29, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (222, 'Admin_search::__construct', 30, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (223, 'Admin_search::index', 30, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (224, 'Admin_search::advanced_search', 30, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (225, 'Admin_search::do_advanced_search', 30, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (226, 'Admin_search::validate_advanced_search', 30, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (227, 'Admin_search::form_from_group', 30, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (228, 'Admin_search::_filter_pages', 30, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (229, 'Admin_search::autocomplete', 30, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (230, 'Backup::__construct', 31, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (231, 'Backup::index', 31, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (232, 'Backup::create', 31, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (233, 'Backup::force_download', 31, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (234, 'Cache_all::__construct', 32, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (235, 'Cache_all::index', 32, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (236, 'Categories::__construct', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (237, 'Categories::index', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (238, 'Categories::create_form', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (239, 'Categories::update_block', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (240, 'Categories::save_positions', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (241, 'Categories::cat_list', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (242, 'Categories::sub_cats', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (243, 'Categories::create', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (244, 'Categories::update_urls', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (245, 'Categories::category_exists', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (246, 'Categories::fast_add', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (247, 'Categories::update_fast_block', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (248, 'Categories::edit', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (249, 'Categories::translate', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (250, 'Categories::delete', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (251, 'Categories::_get_sub_cats', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (252, 'Categories::get_comments_status', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (253, 'Components::__construct', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (254, 'Components::index', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (255, 'Components::modules_table', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (256, 'Components::is_installed', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (257, 'Components::install', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (258, 'Components::deinstall', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (259, 'Components::find_components', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (260, 'Components::component_settings', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (261, 'Components::save_settings', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (262, 'Components::init_window', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (263, 'Components::cp', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (264, 'Components::run', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (265, 'Components::com_info', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (266, 'Components::get_module_info', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (267, 'Components::change_autoload', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (268, 'Components::change_url_access', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (269, 'Components::save_components_positions', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (270, 'Components::change_show_in_menu', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (271, 'Dashboard::__construct', 35, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (272, 'Dashboard::index', 35, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (273, 'Languages::__construct', 36, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (274, 'Languages::index', 36, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (275, 'Languages::create_form', 36, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (276, 'Languages::insert', 36, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (277, 'Languages::edit', 36, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (278, 'Languages::update', 36, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (279, 'Languages::delete', 36, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (280, 'Languages::set_default', 36, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (281, 'Login::__construct', 37, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (282, 'Login::index', 37, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (283, 'Login::user_browser', 37, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (284, 'Login::do_login', 37, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (285, 'Login::forgot_password', 37, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (286, 'Login::update_captcha', 37, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (287, 'Login::captcha_check', 37, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (288, 'Mod_search::__construct', 38, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (289, 'Mod_search::index', 38, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (290, 'Mod_search::category', 38, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (291, 'Mod_search::display_install_window', 38, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (292, 'Mod_search::connect_ftp', 38, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (293, 'Pages::__construct', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (294, 'Pages::index', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (295, 'Pages::add', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (296, 'Pages::_set_page_roles', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (297, 'Pages::edit', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (298, 'Pages::update', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (299, 'Pages::delete', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (300, 'Pages::ajax_translit', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (301, 'Pages::save_positions', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (302, 'Pages::delete_pages', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (303, 'Pages::move_pages', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (304, 'Pages::show_move_window', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (305, 'Pages::json_tags', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (306, 'Pages::ajax_create_keywords', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (307, 'Pages::ajax_create_description', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (308, 'Pages::ajax_change_status', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (309, 'Pages::GetPagesByCategory', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (310, 'Rbac::__construct', 40, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (311, 'Settings::__construct', 41, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (312, 'Settings::index', 41, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (313, 'Settings::main_page', 41, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (314, 'Settings::_get_templates', 41, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (315, 'Settings::save', 41, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (316, 'Settings::switch_admin_lang', 41, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (317, 'Settings::save_main', 41, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (318, 'Sys_upgrade::__construct', 42, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (319, 'Sys_upgrade::index', 42, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (320, 'Sys_upgrade::make_upgrade', 42, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (321, 'Sys_upgrade::_check_status', 42, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (322, 'cfcm::__construct', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (323, 'cfcm::_set_forms_config', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (324, 'cfcm::index', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (325, 'cfcm::create_field', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (326, 'cfcm::edit_field_data_type', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (327, 'cfcm::delete_field', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (328, 'cfcm::edit_field', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (329, 'cfcm::create_group', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (330, 'cfcm::edit_group', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (331, 'cfcm::delete_group', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (332, 'cfcm::form_from_category_group', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (333, 'cfcm::get_form_attributes', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (334, 'cfcm::save_weight', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (335, 'cfcm::render', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (336, 'cfcm::get_url', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (337, 'cfcm::get_form', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (338, 'comments::__construct', 44, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (339, 'comments::index', 44, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (340, 'comments::proccess_child_comments', 44, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (341, 'comments::render', 44, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (342, 'comments::edit', 44, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (343, 'comments::update', 44, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (344, 'comments::update_status', 44, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (345, 'comments::delete', 44, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (346, 'comments::delete_many', 44, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (347, 'comments::show_settings', 44, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (348, 'comments::update_settings', 44, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (349, 'feedback::__construct', 45, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (350, 'feedback::index', 45, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (351, 'feedback::settings', 45, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (352, 'gallery::__construct', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (353, 'gallery::index', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (354, 'gallery::category', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (355, 'gallery::settings', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (356, 'gallery::create_album', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (357, 'gallery::update_album', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (358, 'gallery::edit_album_params', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (359, 'gallery::delete_album', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (360, 'gallery::show_crate_album', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (361, 'gallery::edit_album', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (362, 'gallery::edit_image', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (363, 'gallery::rename_image', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (364, 'gallery::delete_image', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (365, 'gallery::update_info', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (366, 'gallery::update_positions', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (367, 'gallery::update_album_positions', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (368, 'gallery::update_img_positions', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (369, 'gallery::show_create_category', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (370, 'gallery::create_category', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (371, 'gallery::edit_category', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (372, 'gallery::update_category', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (373, 'gallery::delete_category', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (374, 'gallery::upload_image', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (375, 'gallery::upload_archive', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (376, 'group_mailer::__construct', 47, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (377, 'group_mailer::index', 47, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (378, 'group_mailer::send_email', 47, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (379, 'mailer::__construct', 48, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (380, 'mailer::index', 48, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (381, 'mailer::send_email', 48, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (382, 'mailer::delete', 48, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (383, 'menu::__construct', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (384, 'menu::index', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (385, 'menu::menu_item', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (386, 'menu::list_menu_items', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (387, 'menu::create_item', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (388, 'menu::display_selector', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (389, 'menu::get_name_by_id', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (390, 'menu::delete_item', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (391, 'menu::edit_item', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (392, 'menu::process_root', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (393, 'menu::insert_menu_item', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (394, 'menu::save_positions', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (395, 'menu::create_menu', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (396, 'menu::edit_menu', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (397, 'menu::update_menu', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (398, 'menu::check_menu_data', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (399, 'menu::delete_menu', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (400, 'menu::create_tpl', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (401, 'menu::get_pages', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (402, 'menu::search_pages', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (403, 'menu::get_item', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (404, 'menu::display_tpl', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (405, 'menu::fetch_tpl', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (406, 'menu::translate_window', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (407, 'menu::translate_item', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (408, 'menu::_get_langs', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (409, 'menu::render', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (410, 'menu::change_hidden', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (411, 'menu::get_children_items', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (412, 'rss::__construct', 50, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (413, 'rss::index', 50, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (414, 'rss::render', 50, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (415, 'rss::settings_update', 50, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (416, 'rss::display_tpl', 50, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (417, 'rss::fetch_tpl', 50, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (418, 'sample_mail::__construct', 51, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (419, 'sample_mail::create', 51, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (420, 'sample_mail::edit', 51, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (421, 'sample_mail::render', 51, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (422, 'sample_mail::index', 51, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (423, 'sample_mail::delete', 51, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (424, 'sample_module::__construct', 52, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (425, 'sample_module::index', 52, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (426, 'share::__construct', 53, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (427, 'share::index', 53, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (428, 'share::update_settings', 53, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (429, 'share::get_settings', 53, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (430, 'share::render', 53, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (431, 'sitemap::__construct', 54, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (432, 'sitemap::index', 54, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (433, 'sitemap::_load_settings', 54, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (434, 'sitemap::update_settings', 54, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (435, 'sitemap::display_tpl', 54, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (436, 'sitemap::fetch_tpl', 54, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (437, 'sitemap::render', 54, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (438, 'social_servises::__construct', 55, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (439, 'social_servises::index', 55, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (440, 'social_servises::update_settings', 55, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (441, 'social_servises::get_fsettings', 55, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (442, 'social_servises::get_vsettings', 55, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (443, 'social_servises::_get_templates', 55, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (444, 'social_servises::render', 55, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (445, 'template_editor::index', 56, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (446, 'template_editor::render', 56, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (447, 'trash::__construct', 57, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (448, 'trash::index', 57, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (449, 'trash::create_trash', 57, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (450, 'trash::edit_trash', 57, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (451, 'trash::delete_trash', 57, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (452, 'user_manager::__construct', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (453, 'user_manager::index', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (454, 'user_manager::set_tpl_roles', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (455, 'user_manager::getRolesTable', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (456, 'user_manager::genre_user_table', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (457, 'user_manager::auto_complit', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (458, 'user_manager::create_user', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (459, 'user_manager::actions', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (460, 'user_manager::search', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (461, 'user_manager::edit_user', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (462, 'user_manager::update_user', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (463, 'user_manager::groups_index', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (464, 'user_manager::create', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (465, 'user_manager::edit', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (466, 'user_manager::save', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (467, 'user_manager::delete', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (468, 'user_manager::deleteAll', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (469, 'user_manager::update_role_perms', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (470, 'user_manager::show_edit_prems_tpl', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (471, 'user_manager::get_permissions_table', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (472, 'user_manager::get_group_names', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (473, 'Widgets_manager::__construct', 59, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (474, 'Widgets_manager::index', 59, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (475, 'Widgets_manager::create', 59, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (476, 'Widgets_manager::create_tpl', 59, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (477, 'Widgets_manager::edit', 59, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (478, 'Widgets_manager::update_widget', 59, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (479, 'Widgets_manager::update_config', 59, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (480, 'Widgets_manager::delete', 59, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (481, 'Widgets_manager::get', 59, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (482, 'Widgets_manager::edit_html_widget', 59, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (483, 'Widgets_manager::edit_module_widget', 59, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (484, 'Widgets_manager::display_create_tpl', 59, NULL);


#
# TABLE STRUCTURE FOR: shop_rbac_privileges_i18n
#

DROP TABLE IF EXISTS shop_rbac_privileges_i18n;

CREATE TABLE `shop_rbac_privileges_i18n` (
  `id` int(11) NOT NULL,
  `title` varchar(45) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `locale` varchar(45) NOT NULL,
  KEY `id_idx` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (473, 'Управление виджетами', 'Доступ к управлению виджетами', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (1, 'Список баннеров', 'Доступ к списку баннеров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (2, 'Создание баннера', 'Доступ к созданию баннера', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (3, 'Редактирование баннера', 'Доступ к редактированию баннера', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (4, 'Удаление баннера', 'Доступ к удалению баннера', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (5, 'Перевод баннера', 'Доступ к переводу баннера', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (6, 'Активность баннера', 'Управление активностью баннера', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (7, 'Список брендов', 'Доступ к списку брендов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (8, 'Создание бренда', 'Доступ к созданию бренда', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (9, 'Редактирование бренда', 'Доступ к редактированию бренда', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (10, 'Удаление бренда', 'Доступ к удалению бренда', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (11, 'Список брендов', 'Доступ к списку брендов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (12, 'Перевод бренда', 'Доступ к переводу бренда', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (13, 'Список колбеков', 'Доступ к просмотру колбеков', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (14, 'Редактирование колбека', 'Доступ к редактированию колбеков', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (15, 'Статусы колбеков', 'Просмотр статусов колбеков', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (16, 'Создание статуса колбеков', 'Доступ к созданию статусов колбеков', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (17, 'Редактирование статуса колбека', 'Доступ к редактированию статуса колбека', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (18, 'Установка статуса колбека по-умолчанию', 'Доступ к установке статуса колбека по-умолчанию', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (19, 'Изменение статуса колбека', 'Доступ к изменению статуса колбека', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (20, 'Смена порядка статусов колбеков', 'Доступ к изменению порядка статусов колбеков', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (21, 'Изменение темы колбека', 'Доступ к изменению статуса колбека', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (22, 'Удаление колбека', 'Доступ к удалению колбека', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (23, 'Удаление статуса', 'Доступ к удалению статуса колбека', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (24, 'Просмотр тем колбеков', 'Доступ к просмотру тем колбеков', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (25, 'Создание тем колбеков', 'Доступ к созданию тем колбеков', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (26, 'Редактирование темы колбека', 'Доступ к редактированию темы колбека', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (27, 'Удаление темы колбека', 'Доступ к удалению темы колбека', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (28, 'Поиск колбеков', 'Доступ к поиску колбеков', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (29, 'Просмотр категорий магазина', 'Доступ к просмотру категорий магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (30, 'Создание категории магазина', 'Доступ к созданию категории магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (31, 'Редактирование категории магазина', 'Доступ к редактированию категории магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (32, 'Удаление категории магазина', 'Доступ к удалению категории магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (33, 'Просмотр списка категорий магазина', 'Доступ к просмотру списка категорий магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (34, 'Изменение порядка категорий магазина', 'Доступ к изменению порядка категорий магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (35, 'Транслитерация строки', 'Доступ к транслитерации строки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (36, 'Перевод категории магазина', 'Доступ к переводу категории магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (37, 'Смена активности категории магазина', 'Доступ к изменению активности категории магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (38, 'Создание шаблона категории', 'Доступ к созданию шаблона категории магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (39, 'Список доступных шаблонов для категорий магаз', 'Доступ к списку доступных шаблонов для категорий магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (40, 'Просмотр статистики заказов', 'Доступ к просмотру статистики заказов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (41, 'Фильтр заказов по дате', 'Доступ к фильтру заказов по дате', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (42, 'ShopAdminCharts::_createDatesDropDown', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (43, 'Просмотр списка накопительных скидок', 'Доступ к просмотру списка накопительных скидок', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (44, 'Создание накопительной скидки', 'Доступ к созданию накопительной скидки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (45, 'Редактирование накопительной скидки', 'Доступ к редактированию накопительной скидки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (46, 'Просмотр списка пользовательских скидок', 'Доступ к просмотру списка пользовательских скидок', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (47, 'Просмотр скидки пользователя', 'Доступ к просмотру скидки пользователя', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (48, 'Удаление всех скидок', 'Доступ к удалению всех скидок', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (49, 'Смена статуса скидки', 'Доступ к смене статуса скидки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (50, 'Просмотр списка валют', 'Доступ к просмотру списка валют', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (51, 'Создание валюты', 'Доступ к созданию валюты', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (52, 'Редактирование валюты', 'Доступ к редактированию валюты', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (53, 'Установка валюты по-умолчанию', 'Доступ к установке валюты по-умолчанию', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (54, 'Установка главной валюты', 'Доступ к установке главной валюты', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (55, 'Удаление валюты', 'Доступ к удалению валюты', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (56, 'Пересчет цен', 'Доступ к пересчету цен', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (57, 'Проверка цен в базе данных', 'Доступ к проверке цен в базе данных и их исправление', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (58, 'Просмотр списка дополнительных полей для мага', 'Доступ к просмотру списка дополнительных полей магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (59, 'Создание дополнительного поля для магазина', 'Доступ к созданию дополнительного поля для магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (60, 'Редактирование дополнительного поля для магаз', 'Доступ к редактированию дополнительного поля для магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (61, 'Удаление всех дополнительных полей для магази', 'Доступ к удалению всех дополнительных полей для магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (62, 'Смена активности дополнительного поля для маг', 'Доступ к смене активности дополнительного поля для магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (63, 'Смена приватности дополнительного полю', 'Доступ к изменению приватности дополнительного поля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (64, 'Смена необходимости дополнительного поля для ', 'Доступ к изменению необходимости дополнительного поля для магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (65, 'Просмотр дашборда админ панели магазина', 'Доступ к просмотру дашборда админ панели магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (66, 'Просмотр списка способов доставки', 'Доступ к просмотру списка способов доставки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (67, 'Создание способа доставки', 'Доступ к созданию способа доставки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (68, 'Смена статуса способа доставки', 'Доступ к смене статуса способа доставки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (69, 'Редактирование способа доставки', 'Доступ к редактированию способа доставки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (70, 'Удаление способа доставки', 'Доступ к удалению способа доставки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (71, 'ShopAdminDeliverymethods::c_list', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (72, 'Просмотр списка постоянных скидок', 'Доступ к просмотру списка постоянных скидок', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (73, 'Создание постоянной скидки', 'Доступ к созданию постоянной скидки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (74, 'Смена статуса постоянной скидки', 'Доступ к смене статуса постоянной скидки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (75, 'Редактирование постоянной скидки', 'Доступ к редактированию постоянной скидки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (76, 'Удаление постоянной скидки', 'Доступ к удалению постоянной скидки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (77, 'Просмотр списка подарочных сертификатов', 'Доступ к просмотру списка подарочных сертификатов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (78, 'Создание подарочного сертификата', 'Доступ к созданию подарочного сертификата', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (79, 'Создание кода для подарочного сертификата', 'Доступ к соданию кода для подарочного сертификата', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (80, 'Удаление подарочного сертификата', 'Доступ к удалению подарочного сертификата', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (81, 'Редактирование подарочного сертификата', 'Доступ к редактированию подарочного сертификата', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (82, 'Смена активности подарочного сертификата', 'Доступ к смене активности подарочного сертификата', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (83, 'Настройки подарочных сертификатов', 'Доступ к настройкам подарочных сертификатов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (84, 'Сохранение настроек подарочных сертификатов', 'Доступ к сохранению настроек подарочных сертификатов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (85, 'Просмотр списка наборов товаров', 'Доступ к просмотру списка наборов товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (86, 'Создание набора товаров', 'Доступ к созданию набора товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (87, 'Редактирование набора товаров', 'Доступ к редактированию набора товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (88, 'Смена порядка наборов товаров', 'Доступ к смене порядка наборо товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (89, 'Смена активности набора товаров', 'Доступ к смене активности набора товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (90, 'ShopAdminKits::kit_list', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (91, 'Удаление набора товаров', 'Доступ к удалению набора товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (92, 'Получение списка товаров', 'Доступ к получению списка товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (93, 'Просмотр списка уведовлений', 'Доступ к просмотру списка уведомлений', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (94, 'Редактирование уведомления', 'Доступ к редактированию уведомления', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (95, 'Смена статуса уведомления', 'Доступ к смене статуса уведомления', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (96, 'Уведомление по почте', 'Доступ к уведомлению по почте', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (97, 'Удаление уведомления', 'Доступ к удалению уведомления', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (98, 'Удаление уведомления', 'Доступ к удалению уведомления', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (99, 'Смена статуса уведомления', 'Доступ к смене статуса уведомления', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (100, 'Поиск уведомления', 'Доступ к поиску уведомления', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (101, 'Поиск новых событий', 'Доступ к поиску новых событий', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (102, 'Просмотр статусов уведомлений', 'Доступ к просмотру статусов уведомлений', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (103, 'Создание статуса уведомления', 'Доступ к созданию статуса уведомления', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (104, 'Редактирование статуса уведомления', 'Доступ к редактированию статуса увдеомления', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (105, 'Удаление статуса уведомления', 'Доступ к удалению статуса уведомления', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (106, 'Смена порядка статусов уведомлений', 'Доступ к смене порядка статусов уведомлений', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (107, 'Просмотр списка заказов', 'Доступ к просмотру списка заказов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (108, 'Редактирование заказа', 'Доступ к редактированию заказа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (109, 'Смена статуса заказа', 'Доступ к смене статуса заказа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (110, 'Смена статуса оплаты заказа', 'Доступ к смене  статуса оплаты заказа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (111, 'Удаление заказа', 'Доступ к удалению статуса заказа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (112, 'Удаление статуса заказа', 'Доступ к удалению статуса заказа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (113, 'Смена статусов заказов', 'Доступ к смене статусов заказов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (114, 'Смена статуса оплаты заказов', 'Доступ к смене статусов оплаты заказов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (115, 'Отображение окна редактирования', 'Доступ к окну редактирования', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (116, 'Окно редактирования набора товаров', 'Доступ к окну редактирования набора товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (117, 'Окно добавления товара к заказу', 'Доступ к окну добавления товаров к заказу', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (118, 'Удаление товара из заказа', 'Доступ к удалению товара из заказа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (119, 'Получение списка товаров', 'Доступ к получению списка товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (120, 'Редактирование товара в заказе', 'Доступ к редактированию товара в заказе', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (121, 'Добавление товара к заказу', 'Доступ к добавлению товара к заказу', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (122, 'Получение списка товаров в заказе', 'Доступ к получению списка товаров в заказе', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (123, 'Поиск заказа', 'Доступ к поиску заказа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (124, 'Создание чеков', 'Доступ созданию чека', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (125, 'Создание pdf чека', 'Доступ созданию pdf чека', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (126, 'Создание чека', 'Доступ к созданию чека', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (127, 'Создание заказа', 'Доступ к созданию заказа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (128, 'Просмотр списка статусов заказов', 'Доступ к просмотру списка статусов заказов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (129, 'Создание статуса заказа', 'Доступ к созданию статуса заказа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (130, 'Редактирование статуса заказа', 'Доступ к редактированию статуса заказа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (131, 'Удаление статуса заказа', 'Доступ к удалению статуса заказа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (132, 'Отображение окна удаления', 'Доступ к отображению окна удаления', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (133, 'Смена порядка статусов заказов', 'Доступ к смене порядка статусов заказов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (134, 'Просмотр списка методов оплаты', 'Доступ к просмотру списка методов оплаты', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (135, 'Создание метода оплаты', 'Доступ к созданию метода оплаты', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (136, 'Смена статуса способа оплаты', 'Доступ к смене статуса способа оплаты', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (137, 'Редактирование способа оплаты', 'Доступ к редактированию способа оплаты', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (138, 'Удаление способа оплаты', 'Доступ к удалению способа оплаты', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (139, 'Смена порядка способов оплаты', 'Доступ к смене порядка способов оплаты', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (140, 'Отображение настроек способа оплаты', 'Доступ к отображению настроек способа оплаты', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (141, 'ShopAdminProducts::index', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (142, 'Создание продукта', 'Доступ к созданию продукта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (143, 'Редактирование товара', 'Доступ к редактированию товара', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (144, 'Сохранение дополнительных изображений', 'Доступ к сохренению дополнительных изображений', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (145, 'Удаление товара', 'Доступ к удалению товара', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (146, 'Обработка изображений', 'Доступ к обработке изображений', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (147, 'Удаление дополнительных изображений', 'Доступ к удалению дополнительных изображений', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (148, 'Смена активности товара', 'Доступ к смене активности товара', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (149, 'Смена пункта \"Хит\" для товара', 'Доступ к смене пункта \"Хит\" для товара', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (150, 'Смена пункта \"Новинка\" для товара', 'Доступ к смене пункта \"Новинка\" для товара', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (151, 'Смена пункта \"Акция\" для товара', 'Доступ к смене пункта \"Акция\" для товара', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (152, 'Обновление цены', 'Доступ к обновлению цены товара', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (153, 'Копирование товаров', 'Доступ к копированию товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (154, 'Удаление товаров', 'Доступ к удалению товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (155, 'Просмотр окна перемещения товаров', 'Доступ к окну перемещения товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (156, 'Перемещение товаров', 'Доступ к перемещению товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (157, 'Перевод товара', 'Доступ к переводу товара', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (158, 'Получение списка id товаров', 'Доступ к получению списка id товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (159, 'Переключение товаров', 'Доступ к переключению товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (160, 'Просмотр списка слежения', 'Доступ к просмотру списка слежения', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (161, 'Удаления слежения', 'Доступ к удалению слежения', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (162, 'Настройки слежения за товарами', 'Доступ к настройкам слежения за товаром', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (163, 'Просмотр списка свойств', 'Доступ к просмотру списка свойств', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (164, 'Создание свойства товара', 'Доступ к созданию свойства товара', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (165, 'Редактирование свойства товара', 'Доступ к редактированию свойства товара', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (166, 'ShopAdminProperties::renderForm', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (167, 'Смена порядка свойств', 'Доступ к смене порядка свойств', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (168, 'Удаление свойств', 'Доступ к удалению свойств', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (169, 'Смена активности свойства', 'Доступ к смене активности свойства', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (180, 'ShopAdminRbac::group_create', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (181, 'ShopAdminRbac::group_edit', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (182, 'ShopAdminRbac::group_list', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (183, 'ShopAdminRbac::group_delete', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (184, 'Просмотр списка товаров', 'Доступ к просмотру списка товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (185, 'Смена порядка вариантов товаров', 'Доступ к смене порядка вариантов товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (186, 'Автодополнение к поиску', 'Доступ к автодополнению к поиску', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (187, 'Продвинутый поиск', 'Доступ к продвинутому поиску', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (188, 'ShopAdminSearch::renderCustomFields', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (189, 'Свойства магазина', 'Доступ к свойствам магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (190, 'Изменение свойств магазина', 'Доступ к изменению свойств магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (191, 'Получение настроек для интеграции с фейсбуком', 'Доступ к настройкам интеграции с фейсбуком', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (192, 'Получение настроек интеграции с вк', 'Доступ к настройкам интеграции с вк', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (193, 'Получение списка шаблонов', 'Доступ к получению списка шаблонов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (194, 'Загрузка настроек', 'Доступ к загрузке настроек', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (195, 'Запуск ресайза изображений', 'Доступ к запуску ресайза изображений', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (196, 'Импорт товаров', 'Доступ к импорту товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (197, 'Экспорт товаров', 'Доступ к экспорту товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (198, 'Получение атрибутов', 'Доступ к получению атрибутов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (199, 'Экспорт пользователей', 'Доступ к экспорту пользователей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (200, 'Просмотр списка пользователей', 'Доступ к просмотру списка пользователей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (201, 'Поиск пользователей', 'Доступ к поиску пользователей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (202, 'Создание пользователя', 'Доступ к созданию пользователя', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (203, 'Редактирование пользователя', 'Доступ к редактированию пользователя', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (204, 'Удаление пользователя', 'Доступ к удалению пользователя', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (205, 'Автодополнение списка пользователей', 'Достпу к автодополнению списка пользователей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (206, 'Просмотр списка складов', 'Доступ к просмотру списка складов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (207, 'Создание склада', 'Доступ к созданию склада', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (208, 'Редактирование склада', 'Доступ к редактированию склада', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (209, 'Удаление склада', 'Доступ к удалению склада', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (210, 'Доступ к админпанели', 'Доступ к админпанели', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (211, 'Инициализация настроек', 'Доступ к инициализации настроек', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (212, 'Просмотр дашборда базовой админки', 'Доступ к просмотру дашборда базовой админки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (213, 'Просмотр информации о системе', 'Доступ к просмотру информации о системе', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (214, 'Очистка кеша', 'Доступ к очистке кеша', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (215, 'Инициализация elfinder', 'Доступ к инициализации elfinder', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (216, 'Получение защитного токена', 'Доступ к получению токена', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (217, 'Admin::sidebar_cats', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (218, 'Выход с админки', 'Доступ к выходу с админки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (219, 'Сообщить о ошибке', 'Доступ к сообщению о ошибке', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (220, 'История событий', 'Доступ к истории событий', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (221, 'Просмотр истории событий', 'Доступ к просмотру истории событий', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (222, 'Поиск в базовой версии', 'Доступ к поиску в базовой версии', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (223, 'Admin_search::index', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (224, 'Продвинутый поиск в базовой версии', 'Доступ к продвинутому поиску в базовой версии', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (225, 'Произвести поиск в базовой версии', 'Произвести поиск в базовой версии', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (226, 'Валидация поиска в базовой версии', 'Доступ к валидации поиска в базовой версии', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (227, 'Admin_search::form_from_group', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (228, 'Фильтрация страниц', 'Доступ к фильтрации страниц', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (229, 'Автодополнение поиска', 'Доступ к автодополнению поиска', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (230, 'Управление бекапами', 'Доступ к управлению бекапами', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (231, 'Подготовка резервного копирования', 'Доступ к подготовке резервного копирования', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (232, 'Создание бекапа', 'Доступ к созданию бекапа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (233, 'Закачка резервной копии', 'Доступ к созданию резервной копии', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (234, 'Управление кешем', 'Достпу к управлению кешем', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (235, 'Управление кешем', 'Доступ к управлению кешем', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (236, 'Управление категориями сайта', 'Доступ к управлению категориями сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (237, 'Просмотр списка категорий сайта', 'Доступ к просмотру списка категорий сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (238, 'Отображение формы создания категории', 'Доступ к отображению формы создания категории', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (239, 'Обноление категории', 'Доступ к обновлению категорий', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (240, 'Смена порядка категорий сайта', 'Доступ к смене порядка категорий сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (241, 'Просмотр списка категорий сайта', 'Доступ к просмотру списка категорий сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (242, 'Подкатегории', 'Доступ к подкатегориям', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (243, 'Создание категории сайта', 'Доступ к категории сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (244, 'Обновление урлов', 'Доступ к обновлению урлов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (245, 'Проверка сушествования категории сайта', 'Доступ к проверке сушествования категории сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (246, 'Быстрое добавление категории', 'Доступ к быстрому добавлению категории', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (247, 'Быстрое обновление блока', 'Доступ к быстрому обновлению блока', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (248, 'Редактирование категорий сайта', 'Доступ к редактированию категории сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (249, 'Перевод категории сайта', 'Доступ к переводу категории сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (250, 'Удаление категории сайта', 'Доступ к удалению категории сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (251, 'Получение подкатегорий', 'Доступ к получению подкатегорий', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (252, 'Получение статуса комментариев', 'Доступ к получению статусув комментариев', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (253, 'Доступ к компонентам', 'Доступ к компонентам', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (254, 'Управление компонентами системы', 'Доступ к управлению компонентами системы', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (255, 'Просмотр списка компонентов сайта', 'Доступ к просмотру списка компонентов сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (256, 'Проверка установки компонента', 'Доступ к проверке установки компонента', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (257, 'Установка модуля', 'Доступ к установке модуля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (258, 'Удаление модуля', 'Доступ к удалению модуля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (259, 'Поиск компонентов', 'Доступ к поиску компонентов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (260, 'Настройки модуля', 'Доступ к настройкам модуля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (261, 'Сохранение настроек модулей', 'Доступ к сохранению настроек модулей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (262, 'Переход к админчасти модуля', 'Доступ к админчасти модуля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (263, 'Запук модулей', 'Доступ к запуску модулей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (264, 'Запук методов модулей', 'Доступ к запуску методов модулей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (265, 'Получение информации о компонентах', 'Доступ к получению информации о компонентах', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (266, 'Получение информации о модуле', 'Доступ к получению информации о модуле', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (267, 'Смена статуса автозагрузки модуля', 'Доступ к смене статуса автозагрузки модуля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (268, 'Смена доступа по url к модулю', 'Смена доступа по url к модулю', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (269, 'Смена порядка компонентов в списке', 'Доступ к смене порядка компонентов в списке', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (270, 'Включение\\отключение отображения модуля в мен', 'Доступ к включению\\отключению отображения модуля в меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (271, 'Отображение дашборда админки', 'Доступ к отображению дашборда админки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (272, 'Отображение дашборда админки', 'Доступ к отображению дашборда админки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (273, 'Управление языками', 'Доступ к управлению языками', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (274, 'Просмотр списка языков', 'Достпу к просмотру списка языков', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (275, 'Отображение формы создания языка', 'Доступ к отображению формы создания языка', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (276, 'Создание языка', 'Доступ к созданию языка', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (277, 'Редактирование языка', 'Доступ к редактированию языка', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (278, 'Обновление языка', 'Доступ к обновлению языка', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (279, 'Удаление языка', 'Доступ к удалению языка', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (280, 'Установка языка по-умолчанию', 'Доступ к установке языка по-умолчанию', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (281, 'Вход в админ панель', 'Доступ к входу в админ панель', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (282, 'Вход в админ панель', 'Доступ к входу в админ панель', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (283, 'Проверка браузера пользователя', 'Доступ к проверке браузера пользователя', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (284, 'Вход', 'Вход', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (285, 'Восстановление пароля', 'Восстановление пароля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (286, 'Обновление капчи', 'Доступ к обновлению капчи', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (287, 'Проверка капчи', 'Доступ к проверке капчи', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (288, 'Mod_search::__construct', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (289, 'Mod_search::index', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (290, 'Mod_search::category', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (291, 'Mod_search::display_install_window', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (292, 'Mod_search::connect_ftp', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (293, 'Управление страницами', 'Доступ к управлению страницами', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (294, 'Просмотр списка страниц', 'Доступ к просмотру списка страниц', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (295, 'Добавление страницы', 'Доступ к добавлению страницы', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (296, 'Pages::_set_page_roles', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (297, 'Редактирование страницы', 'Доступ к редактированию страницы', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (298, 'Обновление страницы', 'Доступ к редактированию страницы', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (299, 'Удаление страницы', 'Доступ к удалению страницы', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (300, 'Транслит слов', 'Доступ к транслиту слов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (301, 'Смена порядка страниц', 'Доступ к смене порядка страниц', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (302, 'Удаление страниц', 'Доступ к удалению страниц', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (303, 'Перемещение страниц', 'Доступ к перемещению страниц', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (304, 'Отображение страницы перемещения', 'Доступ к отображению страницы перемещения', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (305, 'Теги', 'Теги', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (306, 'Создание ключевых слов', 'Доступ к созданию ключевых слов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (307, 'Создание описания', 'Доступ к созданию описания', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (308, 'Смена статуса', 'Доступ к смене статуса', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (309, 'Фильтр страниц по категории', 'Доступ к фильтру страниц по категории', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (310, 'Управление доступом', 'Управление доступом', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (311, 'Настройки сайта', 'Доступ к настройкам сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (312, 'Настройки сайта', 'Доступ к настройкам сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (313, 'Settings::main_page', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (314, 'Список папок с шаблонами', 'Список папок с шаблонами', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (315, 'Сохранение настроек', 'Доступ к сохранению настроек сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (316, 'Переключение языка в админке', 'Доступ к переключению языка в админке', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (317, 'Settings::save_main', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (318, 'Обновление системы', 'Доступ к обновлению системы', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (319, 'Обновление системы', 'Доступ к обновлению системы', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (320, 'Запуск обновления системы', 'Доступ к запуску обновления системы', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (321, 'Проверка статуса обновления системы', 'Доступ к проверке статуса обновления системы', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (322, 'Управление дополнительными полями', 'Доступ к управлению дополнительными полями', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (323, 'Настройки форм', 'Доступ к настройкам форм', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (324, 'Управление дополнительными полями', 'Доступ к управлению дополнительными полями', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (325, 'Создание дополнительного поля', 'Доступ к созданию дополнительного поля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (326, 'Редактирование типа дополнительного поля', 'Доступ к редактированию типа дополнительного поля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (327, 'Удаление дополнительного поля', 'Доступ к удалению дополнительного поля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (328, 'Редактирование дополнительного поля', 'Доступ к редактированию дополнительного поля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (329, 'Создание групы полей', 'Доступ к созданию групы полей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (330, 'Редактирование групы полей', 'Доступ к редактированию групы полей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (331, 'Удаление групы полей', 'Доступ к удалению групы полей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (332, 'cfcm::form_from_category_group', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (333, 'Получение атрибутов формы', 'Доступ к получению атрибутов формы', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (334, 'Сохранение важности', 'Доступ к сохранению важности', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (335, 'Отображение поля', 'Доступ к отображению поля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (336, 'Получение адреса', 'Доступ к получению адреса', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (337, 'Получение формы', 'Доступ к форме', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (338, 'Управление комментариями', 'Доступ к управлению комментариями', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (339, 'Отображения списка комментариев', 'Доступ к отображению списка комментариев', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (340, 'Обработка подкомментариев', 'Доступ к обработке подкомментариев', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (341, 'comments::render', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (342, 'Редактирование комментария', 'Доступ к редактированию комментария', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (343, 'Обновление комментария', 'Доступ к обновлению комментария', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (344, 'Обновление статуса комментария', 'Доступ к обновлению статуса комментария', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (345, 'Удаление комментария', 'Доступ к удалению комментария', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (346, 'Множественное удаление комментариев', 'Доступ к множественному удалению комментариев', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (347, 'Отображение настроек модуля комментарии', 'Доступ к отображению настроек модуля комментарии', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (348, 'Обновление настроек комментариев', 'Доступ к обновлению настроек комментариев', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (349, 'Управление обратноей связью', 'Доступ к управлению обратной связью', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (350, 'Настройки модуля обратная связь', 'Доступ к настройкам модуля обратная связь', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (351, 'Получение настроек модуля обратная связь', 'Доступ к получению настроек модуля обратная связь', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (352, 'Управление галереей', 'Доступ к галерее', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (353, 'Список категорий галереи', 'Доступ к списку категорий галереи', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (354, 'Категория галереи', 'Доступ к категории галереи', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (355, 'Настройки галереи', 'Доступ к настройкам галереи', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (356, 'Создание альбома', 'Доступ к созданию альбома', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (357, 'Редактирование альбома', 'Доступ к редактированию альбома', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (358, 'Редактирование настроек альбома', 'Доступ к редактированию настроек альбома', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (359, 'Удаление альбома', 'Доступ к удалению альбома', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (360, 'Отображение формы содания альбома', 'Доступ к форме создания альбома', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (361, 'Редактирование альбома', 'Доступ к редактированию альбома', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (362, 'Редактирование изображения', 'Доступ к редактированию изображения', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (363, 'Переименование изображения', 'Доступ к переименованию изображения', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (364, 'Удаление изображения', 'Доступ к удалению изображения', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (365, 'Обновление информации', 'Доступ к обновлению информации', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (366, 'Смена порядка категорий', 'Доступ к смене порядка категорий', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (367, 'Смена порядка альбомов', 'Доступ к смене порядка альбомов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (368, 'Смена порядка изображений', 'Доступ к смене порядка изображений', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (369, 'Отображение формы создания категории', 'Доступ к отображению формы создания категории', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (370, 'Создание категории', 'Доступ к созданию категории', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (371, 'Редактирование категории', 'Доступ к редактированию категории', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (372, 'Обновление категории', 'Доступ к обновлению категории', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (373, 'Удаление категории', 'Доступ к удалению категории', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (374, 'Загрузка изображений', 'Доступ к загрузке изображений', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (375, 'Загрузка архива', 'Доступ к загрузке архива', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (376, 'Управление модулем рассылки', 'Управление модулем рассылки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (377, 'Отправка писем групам', 'Доступ к отправке писем групам', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (378, 'Отправка писем групам', 'Доступ к отправке писем групам', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (379, 'Отправка писем подписчикам', 'Доступк отправке писем подписчикам', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (380, 'Отправка писем подписчикам', 'Доступк отправке писем подписчикам', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (381, 'Отправка писем подписчикам', 'Доступк отправке писем подписчикам', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (382, 'Удаление подписчиков', 'Доступ к удалению подписчиков', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (383, 'Управление меню', 'Доступ к управлению меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (384, 'Список меню сайта', 'Доступ к списку меню сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (385, 'Отображение меню', 'Доступ к отображению меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (386, 'menu::list_menu_items', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (387, 'Создание пункта меню', 'Доступ к созданию пункта меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (388, 'menu::display_selector', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (389, 'menu::get_name_by_id', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (390, 'Удаление пункта меню', 'Доступ к удалению пункта меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (391, 'Редактирование пункта меню', 'Доступ к редактированию пункта меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (392, 'menu::process_root', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (393, 'menu::insert_menu_item', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (394, 'Смена порядка меню', 'Доступ к смене порядка меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (395, 'Создание меню', 'Доступ к созданию меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (396, 'Редактирование меню', 'Доступ к редактированию меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (397, 'Обновление меню', 'Доступ к обновлению меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (398, 'Проверка данных меню', 'Доступ к проверке данных меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (399, 'Удаление меню', 'Доступ к удалению меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (400, 'Отображение формы создания меню', 'Доступ к отображению формы создания меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (401, 'Получение списка страниц', 'Доступ к получению списка страниц', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (402, 'Поиск страниц', 'Доступ к поиску страниц', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (403, 'menu::get_item', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (404, 'menu::display_tpl', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (405, 'menu::fetch_tpl', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (406, 'Отображение окна перевода пункта меню', 'Доступ к отображению окна перевода пункта меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (407, 'Перевод пункта меню', 'Доступ к переводу пункта меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (408, 'Получение списка языков', 'Доступ к получению списка языков', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (409, 'menu::render', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (410, 'Смена активности меню', 'Доступ к смене активности меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (411, 'Получение дочерних елементов', 'Доступ к получению дочерних елементов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (412, 'Управление rss', 'Управление rss', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (413, 'Управление rss', 'Управление rss', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (414, 'rss::render', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (415, 'rss::settings_update', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (416, 'rss::display_tpl', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (417, 'rss::fetch_tpl', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (418, 'Управление шаблонами писем', 'Доступ к управлению шаблонами писем', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (419, 'Создание шаблона письма', 'Доступ к созданию шаблона письма', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (420, 'Редактирование шаблона письма', 'Доступ к редактированию шаблона письма', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (421, 'sample_mail::render', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (422, 'Список шаблонов писем', 'Доступ к списку шаблонов писем', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (423, 'Удаление шаблона письма', 'Доступ к удалению шаблона письма', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (424, 'sample_module::__construct', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (425, 'sample_module::index', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (426, 'Управление кнопками соцсетей', 'Доступ к управлению кнопками соцсетей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (427, 'Управление кнопками соцсетей', 'Доступ к управлению кнопками соцсетей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (428, 'Обновление настроек модуля кнопок соцсетей', 'Доступ к обновлению настроек модуля кнопок соцсетей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (429, 'Получение настроек модуля кнопок соцсетей', 'Доступ к настройкам модуля кнопок соцсетей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (430, 'share::render', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (431, 'Управление картой сайта', 'Доступ к управлению картой сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (432, 'Настройки карты сайта', 'Доступ к настройкам карты сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (433, 'sitemap::_load_settings', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (434, 'Обновление настроек катры сайта', 'Доступ к обновлению настроек карты сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (435, 'sitemap::display_tpl', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (436, 'sitemap::fetch_tpl', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (437, 'sitemap::render', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (438, 'Управление интеграцией с соцсетями', 'Доступ к управлению интеграцией с соцсетями', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (439, 'Настройки модуля интеграции с соцсетями', 'Достпу к настройкам модуля интеграции с соцсетями', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (440, 'Обновление настроек модуля', 'Доступ к обновлению настроек модуля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (441, 'social_servises::get_fsettings', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (442, 'social_servises::get_vsettings', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (443, 'social_servises::_get_templates', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (444, 'social_servises::render', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (445, 'Редактор шаблонов', 'Доступ к редактору шаблонов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (446, 'template_editor::render', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (447, 'Управление редиректами с удаленнных товаров', 'Управление редиректами с удаленнных товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (448, 'Список редиректов', 'Доступ к списку редиректов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (449, 'Создание редиректа', 'Доступ к созданию редиректа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (450, 'Редактирование редиректа', 'Доступ к редактированию редиректа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (451, 'Удаление редаректа', 'Доступ к удалению редиректа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (452, 'Управление пользователями', 'Доступ к управлению пользователями', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (453, 'Список пользователей', 'Доступ к списку пользователей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (454, 'user_manager::set_tpl_roles', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (455, 'user_manager::getRolesTable', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (456, 'Создание списка юзеров', 'Доступ к созданию списка юзеров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (457, 'user_manager::auto_complit', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (458, 'Создание юзера', 'Доступ к созданию юзера', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (459, 'user_manager::actions', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (460, 'Поиск пользователей', 'Доступ к поиску пользователей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (461, 'Редактирование юзера', 'Доступ к редактированию юзера', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (462, 'Обновление информации о пользователе', 'Доступ к обновлению информации о пользователе', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (463, 'user_manager::groups_index', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (464, 'user_manager::create', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (465, 'user_manager::edit', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (466, 'user_manager::save', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (467, 'user_manager::delete', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (468, 'Удаление пользователя', 'Доступ к удалению пользвателя', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (469, 'user_manager::update_role_perms', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (470, 'user_manager::show_edit_prems_tpl', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (471, 'user_manager::get_permissions_table', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (472, 'user_manager::get_group_names', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (474, 'Список виджетов', 'Доступ к списку виджетов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (475, 'Создание виджета', 'Доступ к созданию виджета', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (476, 'Отображение формы создания виджета', 'Доступ к отображению формы создания виджета', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (477, 'Редактирование виджетов', 'Доступ к отображению формы создания виджета', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (478, 'Обновление виджета', 'Доступ к обновлению виджетов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (479, 'Обновление настроек виджета', 'Доступ к обновлению настроек виджета', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (480, 'Удаление виджета', 'Доступ к удалению виджета', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (482, 'Редактирование html виджета', 'Доступ к редактированию html виджета', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (483, 'Редактирование модульного виджета', 'Доступ к редактированию модульного виджета', 'ru');


#
# TABLE STRUCTURE FOR: shop_rbac_roles
#

DROP TABLE IF EXISTS shop_rbac_roles;

CREATE TABLE `shop_rbac_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `importance` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO shop_rbac_roles (`id`, `name`, `importance`, `description`) VALUES (1, 'Administrator', 1, NULL);
INSERT INTO shop_rbac_roles (`id`, `name`, `importance`, `description`) VALUES (2, 'Sales_manager', 2, NULL);
INSERT INTO shop_rbac_roles (`id`, `name`, `importance`, `description`) VALUES (3, 'Content_manager', 1, NULL);


#
# TABLE STRUCTURE FOR: shop_rbac_roles_i18n
#

DROP TABLE IF EXISTS shop_rbac_roles_i18n;

CREATE TABLE `shop_rbac_roles_i18n` (
  `id` int(11) NOT NULL,
  `alt_name` varchar(45) DEFAULT NULL,
  `locale` varchar(5) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  KEY `role_id_idx` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_rbac_roles_i18n (`id`, `alt_name`, `locale`, `description`) VALUES (1, 'Администратор', 'ru', 'Доступны все елементы управления админкой');
INSERT INTO shop_rbac_roles_i18n (`id`, `alt_name`, `locale`, `description`) VALUES (2, 'Продавец', 'ru', 'Имеет доступ только к заказам и пользователям');
INSERT INTO shop_rbac_roles_i18n (`id`, `alt_name`, `locale`, `description`) VALUES (3, 'Контент-менеджер', 'ru', 'Доступ к вкладке товары, наполнитель контента');


#
# TABLE STRUCTURE FOR: shop_rbac_roles_privileges
#

DROP TABLE IF EXISTS shop_rbac_roles_privileges;

CREATE TABLE `shop_rbac_roles_privileges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `privilege_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rolepriv` (`role_id`,`privilege_id`),
  KEY `shop_rbac_roles_privileges_FK_2` (`privilege_id`)
) ENGINE=MyISAM AUTO_INCREMENT=706 DEFAULT CHARSET=utf8;

INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (1, 1, 1);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (2, 1, 2);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (3, 1, 3);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (4, 1, 4);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (5, 1, 5);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (6, 1, 6);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (7, 1, 7);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (8, 1, 8);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (9, 1, 9);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (10, 1, 10);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (11, 1, 11);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (12, 1, 12);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (13, 1, 13);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (14, 1, 14);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (15, 1, 15);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (16, 1, 16);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (17, 1, 17);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (18, 1, 18);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (19, 1, 19);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (20, 1, 20);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (21, 1, 21);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (22, 1, 22);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (23, 1, 23);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (24, 1, 24);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (25, 1, 25);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (26, 1, 26);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (27, 1, 27);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (28, 1, 28);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (29, 1, 29);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (30, 1, 30);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (31, 1, 31);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (32, 1, 32);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (33, 1, 33);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (34, 1, 34);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (35, 1, 35);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (36, 1, 36);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (37, 1, 37);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (38, 1, 38);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (39, 1, 39);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (40, 1, 40);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (41, 1, 41);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (42, 1, 42);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (43, 1, 43);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (44, 1, 44);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (45, 1, 45);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (46, 1, 46);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (47, 1, 47);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (48, 1, 48);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (49, 1, 49);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (50, 1, 50);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (51, 1, 51);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (52, 1, 52);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (53, 1, 53);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (54, 1, 54);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (55, 1, 55);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (56, 1, 56);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (57, 1, 57);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (58, 1, 58);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (59, 1, 59);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (60, 1, 60);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (61, 1, 61);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (62, 1, 62);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (63, 1, 63);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (64, 1, 64);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (65, 1, 65);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (66, 1, 66);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (67, 1, 67);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (68, 1, 68);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (69, 1, 69);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (70, 1, 70);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (71, 1, 71);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (72, 1, 72);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (73, 1, 73);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (74, 1, 74);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (75, 1, 75);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (76, 1, 76);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (77, 1, 77);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (78, 1, 78);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (79, 1, 79);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (80, 1, 80);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (81, 1, 81);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (82, 1, 82);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (83, 1, 83);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (84, 1, 84);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (85, 1, 85);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (86, 1, 86);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (87, 1, 87);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (88, 1, 88);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (89, 1, 89);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (90, 1, 90);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (91, 1, 91);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (92, 1, 92);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (93, 1, 93);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (94, 1, 94);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (95, 1, 95);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (96, 1, 96);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (97, 1, 97);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (98, 1, 98);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (99, 1, 99);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (100, 1, 100);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (101, 1, 101);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (102, 1, 102);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (103, 1, 103);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (104, 1, 104);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (105, 1, 105);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (106, 1, 106);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (107, 1, 107);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (108, 1, 108);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (109, 1, 109);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (110, 1, 110);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (111, 1, 111);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (112, 1, 112);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (113, 1, 113);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (114, 1, 114);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (115, 1, 115);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (116, 1, 116);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (117, 1, 117);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (118, 1, 118);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (119, 1, 119);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (120, 1, 120);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (121, 1, 121);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (122, 1, 122);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (123, 1, 123);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (124, 1, 124);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (125, 1, 125);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (126, 1, 126);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (127, 1, 127);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (128, 1, 128);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (129, 1, 129);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (130, 1, 130);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (131, 1, 131);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (132, 1, 132);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (133, 1, 133);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (134, 1, 134);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (135, 1, 135);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (136, 1, 136);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (137, 1, 137);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (138, 1, 138);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (139, 1, 139);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (140, 1, 140);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (141, 1, 141);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (142, 1, 142);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (143, 1, 143);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (144, 1, 144);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (145, 1, 145);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (146, 1, 146);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (147, 1, 147);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (148, 1, 148);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (149, 1, 149);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (150, 1, 150);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (151, 1, 151);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (152, 1, 152);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (153, 1, 153);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (154, 1, 154);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (155, 1, 155);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (156, 1, 156);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (157, 1, 157);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (158, 1, 158);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (159, 1, 159);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (160, 1, 160);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (161, 1, 161);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (162, 1, 162);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (163, 1, 163);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (164, 1, 164);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (165, 1, 165);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (166, 1, 166);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (167, 1, 167);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (168, 1, 168);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (169, 1, 169);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (170, 1, 170);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (171, 1, 171);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (172, 1, 172);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (173, 1, 173);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (174, 1, 174);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (175, 1, 175);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (176, 1, 176);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (177, 1, 177);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (178, 1, 178);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (179, 1, 179);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (180, 1, 180);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (181, 1, 181);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (182, 1, 182);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (183, 1, 183);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (184, 1, 184);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (185, 1, 185);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (186, 1, 186);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (187, 1, 187);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (188, 1, 188);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (189, 1, 189);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (190, 1, 190);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (191, 1, 191);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (192, 1, 192);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (193, 1, 193);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (194, 1, 194);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (195, 1, 195);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (196, 1, 196);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (197, 1, 197);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (198, 1, 198);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (199, 1, 199);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (200, 1, 200);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (201, 1, 201);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (202, 1, 202);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (203, 1, 203);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (204, 1, 204);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (205, 1, 205);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (206, 1, 206);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (207, 1, 207);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (208, 1, 208);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (209, 1, 209);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (210, 1, 210);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (211, 1, 211);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (212, 1, 212);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (213, 1, 213);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (214, 1, 214);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (215, 1, 215);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (216, 1, 216);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (217, 1, 217);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (218, 1, 218);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (219, 1, 219);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (220, 1, 220);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (221, 1, 221);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (222, 1, 222);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (223, 1, 223);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (224, 1, 224);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (225, 1, 225);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (226, 1, 226);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (227, 1, 227);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (228, 1, 228);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (229, 1, 229);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (230, 1, 230);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (231, 1, 231);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (232, 1, 232);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (233, 1, 233);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (234, 1, 234);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (235, 1, 235);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (236, 1, 236);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (237, 1, 237);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (238, 1, 238);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (239, 1, 239);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (240, 1, 240);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (241, 1, 241);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (242, 1, 242);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (243, 1, 243);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (244, 1, 244);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (245, 1, 245);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (246, 1, 246);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (247, 1, 247);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (248, 1, 248);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (249, 1, 249);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (250, 1, 250);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (251, 1, 251);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (252, 1, 252);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (253, 1, 253);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (254, 1, 254);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (255, 1, 255);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (256, 1, 256);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (257, 1, 257);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (258, 1, 258);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (259, 1, 259);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (260, 1, 260);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (261, 1, 261);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (262, 1, 262);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (263, 1, 263);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (264, 1, 264);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (265, 1, 265);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (266, 1, 266);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (267, 1, 267);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (268, 1, 268);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (269, 1, 269);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (270, 1, 270);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (271, 1, 271);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (272, 1, 272);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (273, 1, 273);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (274, 1, 274);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (275, 1, 275);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (276, 1, 276);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (277, 1, 277);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (278, 1, 278);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (279, 1, 279);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (280, 1, 280);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (281, 1, 281);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (282, 1, 282);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (283, 1, 283);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (284, 1, 284);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (285, 1, 285);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (286, 1, 286);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (287, 1, 287);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (288, 1, 288);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (289, 1, 289);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (290, 1, 290);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (291, 1, 291);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (292, 1, 292);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (293, 1, 293);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (294, 1, 294);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (295, 1, 295);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (296, 1, 296);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (297, 1, 297);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (298, 1, 298);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (299, 1, 299);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (300, 1, 300);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (301, 1, 301);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (302, 1, 302);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (303, 1, 303);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (304, 1, 304);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (305, 1, 305);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (306, 1, 306);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (307, 1, 307);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (308, 1, 308);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (309, 1, 309);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (310, 1, 310);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (311, 1, 311);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (312, 1, 312);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (313, 1, 313);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (314, 1, 314);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (315, 1, 315);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (316, 1, 316);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (317, 1, 317);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (318, 1, 318);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (319, 1, 319);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (320, 1, 320);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (321, 1, 321);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (322, 1, 322);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (323, 1, 323);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (324, 1, 324);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (325, 1, 325);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (326, 1, 326);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (327, 1, 327);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (328, 1, 328);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (329, 1, 329);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (330, 1, 330);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (331, 1, 331);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (332, 1, 332);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (333, 1, 333);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (334, 1, 334);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (335, 1, 335);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (336, 1, 336);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (337, 1, 337);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (338, 1, 338);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (339, 1, 339);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (340, 1, 340);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (341, 1, 341);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (342, 1, 342);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (343, 1, 343);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (344, 1, 344);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (345, 1, 345);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (346, 1, 346);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (347, 1, 347);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (348, 1, 348);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (349, 1, 349);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (350, 1, 350);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (351, 1, 351);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (352, 1, 352);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (353, 1, 353);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (354, 1, 354);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (355, 1, 355);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (356, 1, 356);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (357, 1, 357);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (358, 1, 358);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (359, 1, 359);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (360, 1, 360);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (361, 1, 361);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (362, 1, 362);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (363, 1, 363);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (364, 1, 364);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (365, 1, 365);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (366, 1, 366);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (367, 1, 367);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (368, 1, 368);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (369, 1, 369);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (370, 1, 370);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (371, 1, 371);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (372, 1, 372);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (373, 1, 373);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (374, 1, 374);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (375, 1, 375);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (376, 1, 376);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (377, 1, 377);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (378, 1, 378);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (379, 1, 379);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (380, 1, 380);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (381, 1, 381);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (382, 1, 382);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (383, 1, 383);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (384, 1, 384);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (385, 1, 385);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (386, 1, 386);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (387, 1, 387);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (388, 1, 388);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (389, 1, 389);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (390, 1, 390);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (391, 1, 391);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (392, 1, 392);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (393, 1, 393);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (394, 1, 394);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (395, 1, 395);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (396, 1, 396);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (397, 1, 397);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (398, 1, 398);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (399, 1, 399);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (400, 1, 400);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (401, 1, 401);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (402, 1, 402);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (403, 1, 403);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (404, 1, 404);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (405, 1, 405);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (406, 1, 406);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (407, 1, 407);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (408, 1, 408);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (409, 1, 409);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (410, 1, 410);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (411, 1, 411);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (412, 1, 412);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (413, 1, 413);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (414, 1, 414);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (415, 1, 415);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (416, 1, 416);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (417, 1, 417);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (418, 1, 418);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (419, 1, 419);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (420, 1, 420);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (421, 1, 421);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (422, 1, 422);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (423, 1, 423);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (424, 1, 424);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (425, 1, 425);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (426, 1, 426);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (427, 1, 427);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (428, 1, 428);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (429, 1, 429);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (430, 1, 430);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (431, 1, 431);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (432, 1, 432);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (433, 1, 433);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (434, 1, 434);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (435, 1, 435);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (436, 1, 436);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (437, 1, 437);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (438, 1, 438);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (439, 1, 439);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (440, 1, 440);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (441, 1, 441);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (442, 1, 442);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (443, 1, 443);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (444, 1, 444);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (445, 1, 445);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (446, 1, 446);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (447, 1, 447);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (448, 1, 448);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (449, 1, 449);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (450, 1, 450);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (451, 1, 451);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (452, 1, 452);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (453, 1, 453);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (454, 1, 454);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (455, 1, 455);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (456, 1, 456);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (457, 1, 457);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (458, 1, 458);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (459, 1, 459);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (460, 1, 460);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (461, 1, 461);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (462, 1, 462);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (463, 1, 463);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (464, 1, 464);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (465, 1, 465);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (466, 1, 466);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (467, 1, 467);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (468, 1, 468);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (469, 1, 469);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (470, 1, 470);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (471, 1, 471);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (472, 1, 472);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (473, 1, 473);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (474, 1, 474);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (475, 1, 475);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (476, 1, 476);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (477, 1, 477);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (478, 1, 478);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (479, 1, 479);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (480, 1, 480);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (481, 1, 481);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (482, 1, 482);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (483, 1, 483);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (484, 1, 484);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (485, 2, 200);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (486, 2, 201);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (487, 2, 202);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (488, 2, 203);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (489, 2, 204);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (490, 2, 205);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (491, 2, 107);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (492, 2, 108);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (493, 2, 109);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (494, 2, 110);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (495, 2, 111);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (496, 2, 112);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (497, 2, 113);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (498, 2, 114);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (499, 2, 115);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (500, 2, 116);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (501, 2, 117);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (502, 2, 118);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (503, 2, 119);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (504, 2, 120);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (505, 2, 121);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (506, 2, 122);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (507, 2, 123);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (508, 2, 124);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (509, 2, 125);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (510, 2, 126);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (511, 2, 127);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (512, 2, 281);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (513, 2, 282);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (514, 2, 283);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (515, 2, 284);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (516, 2, 285);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (517, 2, 286);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (518, 2, 287);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (519, 2, 210);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (520, 2, 211);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (521, 2, 212);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (522, 2, 213);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (523, 2, 214);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (524, 2, 215);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (525, 2, 216);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (526, 2, 217);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (527, 2, 218);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (528, 2, 219);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (529, 2, 65);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (651, 3, 238);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (616, 3, 311);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (615, 3, 233);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (614, 3, 232);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (613, 3, 231);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (612, 3, 230);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (674, 3, 301);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (673, 3, 300);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (672, 3, 299);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (671, 3, 298);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (670, 3, 297);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (669, 3, 296);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (668, 3, 295);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (667, 3, 294);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (666, 3, 293);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (665, 3, 252);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (664, 3, 251);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (663, 3, 250);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (623, 3, 222);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (622, 3, 317);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (621, 3, 316);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (620, 3, 315);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (619, 3, 314);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (618, 3, 313);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (617, 3, 312);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (650, 3, 237);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (649, 3, 236);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (648, 3, 483);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (647, 3, 482);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (646, 3, 480);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (645, 3, 479);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (644, 3, 478);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (643, 3, 477);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (662, 3, 249);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (661, 3, 248);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (660, 3, 247);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (659, 3, 246);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (658, 3, 245);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (657, 3, 244);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (656, 3, 243);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (655, 3, 242);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (654, 3, 241);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (653, 3, 240);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (652, 3, 239);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (642, 3, 476);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (641, 3, 475);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (640, 3, 474);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (639, 3, 473);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (638, 3, 280);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (637, 3, 279);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (636, 3, 278);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (635, 3, 277);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (634, 3, 276);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (633, 3, 275);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (632, 3, 274);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (631, 3, 273);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (630, 3, 229);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (629, 3, 228);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (628, 3, 227);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (627, 3, 226);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (626, 3, 225);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (625, 3, 224);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (624, 3, 223);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (593, 3, 271);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (594, 3, 272);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (595, 3, 281);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (596, 3, 282);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (597, 3, 283);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (598, 3, 284);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (599, 3, 285);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (600, 3, 286);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (601, 3, 287);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (602, 3, 210);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (603, 3, 211);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (604, 3, 212);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (605, 3, 213);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (606, 3, 214);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (607, 3, 215);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (608, 3, 216);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (609, 3, 217);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (610, 3, 218);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (611, 3, 219);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (675, 3, 302);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (676, 3, 303);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (677, 3, 304);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (678, 3, 305);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (679, 3, 306);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (680, 3, 307);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (681, 3, 308);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (682, 3, 309);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (683, 3, 253);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (684, 3, 254);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (685, 3, 255);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (686, 3, 256);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (687, 3, 257);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (688, 3, 258);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (689, 3, 259);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (690, 3, 260);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (691, 3, 261);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (692, 3, 262);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (693, 3, 263);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (694, 3, 264);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (695, 3, 265);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (696, 3, 266);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (697, 3, 267);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (698, 3, 268);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (699, 3, 269);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (700, 3, 270);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (701, 3, 310);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (702, 3, 220);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (703, 3, 221);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (704, 3, 234);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (705, 3, 235);


#
# TABLE STRUCTURE FOR: shop_settings
#

DROP TABLE IF EXISTS shop_settings;

CREATE TABLE `shop_settings` (
  `name` varchar(255) NOT NULL,
  `value` text,
  `locale` varchar(5) NOT NULL,
  PRIMARY KEY (`name`,`locale`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('mainImageWidth', '320', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('mainImageHeight', '320', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('smallImageWidth', '140', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('smallImageHeight', '140', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('addImageWidth', '800', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('addImageHeight', '600', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('imagesQuality', '99', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('systemTemplatePath', './templates/newLevel/shop/', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('frontProductsPerPage', '12', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('adminProductsPerPage', '24', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersMessageFormat', NULL, '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersMessageText', 'Здравствуйте, %userName%.  \n\nМы благодарны Вам за то, что совершили заказ в нашем магазине \"ImageCMS Shop\" \nВы указали следующие контактные данные: \n\nEmail адрес: %userEmail% \nНомер телефона: %userPhone% \nАдрес доставки: %userDeliver%  \n\nМенеджеры нашего магазина вскоре свяжутся с Вами и помогут с оформлением и оплатой товара.  \n\nТакже, Вы можете всегда посмотреть за статусом Вашего заказа, перейдя по ссылке:  %orderLink%.  \n\nСпасибо за ваш заказ, искренне Ваши, сотрудники ImageCMS Shop.  \n\nПри возникновении любых вопросов, обращайтесь за телефонами:  \n+7 (095) 222-33-22 +38 (098) 222-33-22', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersSendMessage', NULL, '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersSenderEmail', NULL, '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersSenderName', 'DemoShop ImageCms.net', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersMessageTheme', 'Данные для просмотра совершенной покупки', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('2_LMI_SECRET_KEY', 'bank', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('2_LMI_PAYEE_PURSE', 'bank', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('1_LMI_SECRET_KEY', 'cur', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('1_LMI_PAYEE_PURSE', 'cur', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('2_OschadBankData', 'a:5:{s:8:\"receiver\";s:41:\"ТЗОВ \"Екзампл Магазин\" \";s:4:\"code\";s:9:\"123456789\";s:7:\"account\";s:12:\"123456789123\";s:3:\"mfo\";s:6:\"123456\";s:8:\"banknote\";s:7:\"грн.\";}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('3_SberBankData', 'a:8:{s:12:\"receiverName\";s:45:\"Наименование получателя\";s:8:\"bankName\";s:29:\"Банк получателя\";s:11:\"receiverInn\";s:10:\"1231231231\";s:7:\"account\";s:20:\"15412398123312341237\";s:3:\"BIK\";s:9:\"123123123\";s:11:\"cor_account\";s:20:\"12312312334012340123\";s:8:\"bankNote\";s:7:\"руб.\";s:9:\"bankNote2\";s:7:\"коп.\";}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('4_RobokassaData', 'a:3:{s:5:\"login\";s:5:\"login\";s:9:\"password1\";s:9:\"password1\";s:9:\"password2\";s:9:\"password2\";}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusMessageFormat', NULL, '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusMessageText', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusSenderEmail', NULL, '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusSenderName', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusMessageTheme', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('wishListsMessageFormat', 'text', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('wishListsMessageText', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('wishListsSenderEmail', 'noreply@example.com', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('wishListsSenderName', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('wishListsMessageTheme', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notificationsMessageFormat', 'text', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notificationsMessageText', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notificationsSenderEmail', 'noreply@example.com', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notificationsSenderName', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notificationsMessageTheme', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksSendNotification', '0', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksMessageFormat', 'text', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksMessageText', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksSendEmailTo', 'manager@example.com', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksSenderEmail', 'noreply@example.com', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksSenderName', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksMessageTheme', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoRegister', '1', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoMessageFormat', 'text', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoMessageText', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoSenderEmail', 'noreply@example.com', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoSenderName', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoMessageTheme', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('topSalesBlockFormulaCoef', '1', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('pricePrecision', '2', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('smallAddImageWidth', '90', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('smallAddImageHeight', '90', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('forgotPasswordMessageText', 'Здравствуйте!\n\nНа сайте %webSiteName% создан запрос на восстановление пароля для Вашего аккаунта.\n\nДля завершения процедуры восстановления пароля перейдите по ссылке %resetPasswordUri% \n\nВаш новый пароль для входа: %password%\n\nЕсли это письмо попало к Вам по ошибке просто проигнорируйте его.\n\n\nПри возникновении любых вопросов, обращайтесь по телефонам:  \n(012)  345-67-89 , (012)  345-67-89 \n---\n\nС уважением, \nсотрудники службы продаж %webSiteName%', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_wm_hor_alignment', 'left', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_wm_vrt_alignment', 'bottom', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_watermark_type', 'text', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_watermark_image', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_watermark_image_opacity', '50', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_watermark_padding', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_watermark_text', 'inpromservice.com.ua', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_watermark_font_size', '10', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_watermark_color', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_watermark_font_path', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_active', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('forgotPasswordMessageText', NULL, 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersMessageText', NULL, 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersSenderName', NULL, 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersMessageTheme', NULL, 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusMessageText', NULL, 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusSenderName', NULL, 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusMessageTheme', NULL, 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('wishListsMessageText', '', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('wishListsSenderName', 'admin', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('wishListsMessageTheme', '', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notificationsMessageText', '', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notificationsSenderName', '', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notificationsMessageTheme', '', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksMessageText', '', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksSenderName', '', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksMessageTheme', '', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoMessageText', '', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoSenderName', '', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoMessageTheme', '', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('adminMessageCallback', '<h1>Спасибо за заказ звонка</h1>\n<div>В ближайшее время наши менеджеры свяжутся с Вами</div>  ', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('adminMessages', 'a:3:{s:8:\"incoming\";s:0:\"\";s:8:\"callback\";s:27:\"вфы вфыв фыв фы\";s:5:\"order\";s:0:\"\";}', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('selectedProductCats', 'N;', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('adminMessageIncoming', '<h1>Спасибо</h1>\n<div>В ближайшее время наши менеджеры свяжутся с Вами</div>  ', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('adminMessageOrderPage', '<h1>Спасибо</h1>\n<div>В ближайшее время наши менеджеры свяжутся с Вами</div>  ', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('mainModImageWidth', '640', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('mainModImageHeight', '480', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('smallModImageWidth', '90', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('smallModImageHeight', '90', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('order_method', NULL, '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('forgotPasswordMessageText', 'Здравствуйте!\n\nНа сайте %webSiteName% создан запрос на восстановление пароля для Вашего аккаунта.\n\nДля завершения процедуры восстановления пароля перейдите по ссылке %resetPasswordUri% \n\nВаш новый пароль для входа: %password%\n\nЕсли это письмо попало к Вам по ошибке просто проигнорируйте его.\n\n\nПри возникновении любых вопросов, обращайтесь по телефонам:  \n(012)  345-67-89 , (012)  345-67-89 \n---\n\nС уважением, \nсотрудники службы продаж %webSiteName%', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersMessageText', 'Здравствуйте, %userName%.  \n\nМы благодарны Вам за то, что совершили заказ в нашем магазине \"ImageCMS Shop\" \nВы указали следующие контактные данные: \n\nEmail адрес: %userEmail% \nНомер телефона: %userPhone% \nАдрес доставки: %userDeliver%  \n\nМенеджеры нашего магазина вскоре свяжутся с Вами и помогут с оформлением и оплатой товара.  \n\nТакже, Вы можете всегда посмотреть за статусом Вашего заказа, перейдя по ссылке:  %orderLink%.  \n\nСпасибо за ваш заказ, искренне Ваши, сотрудники ImageCMS Shop.  \n\nПри возникновении любых вопросов, обращайтесь за телефонами:  \n+7 (095) 222-33-22 +38 (098) 222-33-22', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersSenderName', 'DemoShop ImageCms.net', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersMessageTheme', 'Данные для просмотра совершенной покупки', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersManagerEmail', NULL, '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersSendManagerMessage', NULL, '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusMessageText', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusSenderName', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusMessageTheme', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('wishListsMessageText', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('wishListsSenderName', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('wishListsMessageTheme', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notificationsMessageText', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notificationsSenderName', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notificationsMessageTheme', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksMessageText', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksSenderName', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksMessageTheme', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoMessageText', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoSenderName', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoMessageTheme', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('MemcachedSettings', 'a:1:{s:11:\"MEMCACHE_ON\";b:0;}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('adminMessageMonkey', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('adminMessageMonkeylist', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('MobileVersionSettings', 'a:1:{s:15:\"MobileVersionON\";b:0;}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('facebook_int', 'a:3:{s:9:\"secretkey\";s:0:\"\";s:9:\"appnumber\";s:0:\"\";s:8:\"template\";s:20:\"commerce_mobiles_new\";}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('vk_int', 'a:3:{s:7:\"protkey\";s:0:\"\";s:9:\"appnumber\";s:0:\"\";s:8:\"template\";s:20:\"commerce_mobiles_new\";}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('xmlSiteMap', 'a:6:{s:18:\"main_page_priority\";b:0;s:13:\"cats_priority\";b:0;s:14:\"pages_priority\";b:0;s:20:\"main_page_changefreq\";b:0;s:21:\"categories_changefreq\";b:0;s:16:\"pages_changefreq\";b:0;}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('mobileTemplatePath', './templates/commerce_mobiles/shop/PIE', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersRecountGoods', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersuserInfoRegister', NULL, '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusStatusEmail', NULL, '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('8_LMI_PAYEE_PURSE', '6456456456464', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('8_LMI_SECRET_KEY', '456', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_watermark_interest', '25', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('9_OschadBankData', 'a:5:{s:8:\"receiver\";s:0:\"\";s:4:\"code\";s:10:\"1234567890\";s:7:\"account\";s:0:\"\";s:3:\"mfo\";s:0:\"\";s:8:\"banknote\";s:0:\"\";}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ss', 'a:9:{s:4:\"yaru\";s:1:\"1\";s:5:\"vkcom\";s:1:\"1\";s:8:\"facebook\";s:1:\"1\";s:7:\"twitter\";s:1:\"1\";s:9:\"odnoclass\";s:1:\"1\";s:7:\"myworld\";s:1:\"1\";s:2:\"lj\";s:1:\"1\";s:4:\"type\";s:6:\"button\";s:8:\"vk_apiid\";s:0:\"\";}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('1CCatSettings', 'a:1:{s:8:\"filesize\";s:11:\"file_limit=\";}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('1CSettingsOS', 'N;', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('usegifts', '0;', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersCheckStocks', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('imageSizesBlock', 'a:4:{s:5:\"small\";a:3:{s:4:\"name\";s:5:\"small\";s:6:\"height\";s:2:\"65\";s:5:\"width\";s:2:\"63\";}s:6:\"medium\";a:3:{s:4:\"name\";s:6:\"medium\";s:6:\"height\";s:3:\"260\";s:5:\"width\";s:3:\"149\";}s:4:\"main\";a:3:{s:4:\"name\";s:4:\"main\";s:6:\"height\";s:3:\"452\";s:5:\"width\";s:3:\"288\";}s:5:\"large\";a:3:{s:4:\"name\";s:5:\"large\";s:6:\"height\";s:3:\"600\";s:5:\"width\";s:3:\"384\";}}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('imagesMainSize', 'auto', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('additionalImageWidth', '600', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('additionalImageHeight', '384', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('arrayFrontProductsPerPage', 'a:3:{i:0;s:2:\"12\";i:1;s:2:\"24\";i:2;s:2:\"48\";}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('thumbImageWidth', '62', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('thumbImageHeight', '62', '');


#
# TABLE STRUCTURE FOR: shop_sorting
#

DROP TABLE IF EXISTS shop_sorting;

CREATE TABLE `shop_sorting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pos` int(11) DEFAULT NULL,
  `get` varchar(25) NOT NULL,
  `active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO shop_sorting (`id`, `pos`, `get`, `active`) VALUES (1, 4, 'rating', 1);
INSERT INTO shop_sorting (`id`, `pos`, `get`, `active`) VALUES (2, 1, 'price', 1);
INSERT INTO shop_sorting (`id`, `pos`, `get`, `active`) VALUES (3, 2, 'price_desc', 1);
INSERT INTO shop_sorting (`id`, `pos`, `get`, `active`) VALUES (4, 3, 'hit', 1);
INSERT INTO shop_sorting (`id`, `pos`, `get`, `active`) VALUES (5, 5, 'hot', 1);
INSERT INTO shop_sorting (`id`, `pos`, `get`, `active`) VALUES (6, 0, 'action', 1);
INSERT INTO shop_sorting (`id`, `pos`, `get`, `active`) VALUES (7, 8, 'name', 0);
INSERT INTO shop_sorting (`id`, `pos`, `get`, `active`) VALUES (8, 9, 'name_desc', 0);
INSERT INTO shop_sorting (`id`, `pos`, `get`, `active`) VALUES (9, 6, 'views', 0);
INSERT INTO shop_sorting (`id`, `pos`, `get`, `active`) VALUES (10, 7, 'topsales', 1);


#
# TABLE STRUCTURE FOR: shop_sorting_i18n
#

DROP TABLE IF EXISTS shop_sorting_i18n;

CREATE TABLE `shop_sorting_i18n` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `locale` varchar(11) NOT NULL DEFAULT 'ru',
  `name` varchar(50) NOT NULL,
  `name_front` varchar(50) DEFAULT NULL,
  `tooltip` varchar(256) NOT NULL,
  PRIMARY KEY (`id`,`locale`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO shop_sorting_i18n (`id`, `locale`, `name`, `name_front`, `tooltip`) VALUES (1, 'ru', 'По рейтингу', 'Рейтинг', '');
INSERT INTO shop_sorting_i18n (`id`, `locale`, `name`, `name_front`, `tooltip`) VALUES (2, 'ru', 'От дешевых к дорогим', 'От дешевых к дорогим', '');
INSERT INTO shop_sorting_i18n (`id`, `locale`, `name`, `name_front`, `tooltip`) VALUES (3, 'ru', 'От дорогих к дешевым', 'От дорогих к дешевым', '');
INSERT INTO shop_sorting_i18n (`id`, `locale`, `name`, `name_front`, `tooltip`) VALUES (4, 'ru', 'Популярные', 'Популярные', '');
INSERT INTO shop_sorting_i18n (`id`, `locale`, `name`, `name_front`, `tooltip`) VALUES (5, 'ru', 'Новинки', 'Новинки', '');
INSERT INTO shop_sorting_i18n (`id`, `locale`, `name`, `name_front`, `tooltip`) VALUES (6, 'ru', 'Акции', 'Акции', '');
INSERT INTO shop_sorting_i18n (`id`, `locale`, `name`, `name_front`, `tooltip`) VALUES (6, 'ua', '', '', '');
INSERT INTO shop_sorting_i18n (`id`, `locale`, `name`, `name_front`, `tooltip`) VALUES (7, 'ru', 'А-Я', 'Имени', '');
INSERT INTO shop_sorting_i18n (`id`, `locale`, `name`, `name_front`, `tooltip`) VALUES (8, 'ru', 'Я-А', 'Имени(Я-А)', '');
INSERT INTO shop_sorting_i18n (`id`, `locale`, `name`, `name_front`, `tooltip`) VALUES (9, 'ru', 'Просмотров', 'Количеству просмотров', '');
INSERT INTO shop_sorting_i18n (`id`, `locale`, `name`, `name_front`, `tooltip`) VALUES (10, 'ru', 'Топ продаж', 'Топ продаж', '');


#
# TABLE STRUCTURE FOR: shop_spy
#

DROP TABLE IF EXISTS shop_spy;

CREATE TABLE `shop_spy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `key` varchar(500) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `old_price` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO shop_spy (`id`, `user_id`, `product_id`, `price`, `variant_id`, `key`, `email`, `old_price`) VALUES (3, 69, 102, 550, 113, 'IPrMlWydoeP9Cmex30upNOUsdTa4bIrg', NULL, 549);


#
# TABLE STRUCTURE FOR: shop_warehouse
#

DROP TABLE IF EXISTS shop_warehouse;

CREATE TABLE `shop_warehouse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `shop_warehouse_I_1` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO shop_warehouse (`id`, `name`, `address`, `phone`, `description`) VALUES (1, 'warehouse 1', 'address', 'phone', '');
INSERT INTO shop_warehouse (`id`, `name`, `address`, `phone`, `description`) VALUES (2, 'warehouse 2', 'address 2', '', '');


#
# TABLE STRUCTURE FOR: shop_warehouse_data
#

DROP TABLE IF EXISTS shop_warehouse_data;

CREATE TABLE `shop_warehouse_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `count` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_warehouse_data_FI_1` (`product_id`),
  KEY `shop_warehouse_data_FI_2` (`warehouse_id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

INSERT INTO shop_warehouse_data (`id`, `product_id`, `warehouse_id`, `count`) VALUES (37, 132, 2, 3);
INSERT INTO shop_warehouse_data (`id`, `product_id`, `warehouse_id`, `count`) VALUES (36, 132, 1, 2);
INSERT INTO shop_warehouse_data (`id`, `product_id`, `warehouse_id`, `count`) VALUES (35, 132, 1, 1);


#
# TABLE STRUCTURE FOR: support_comments
#

DROP TABLE IF EXISTS support_comments;

CREATE TABLE `support_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_status` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `text` varchar(500) NOT NULL,
  `date` int(11) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO support_comments (`id`, `ticket_id`, `user_id`, `user_status`, `user_name`, `text`, `date`) VALUES (1, 3, 1, 1, 'admin', 'Вы можете оплатить услуги безналичным переводом и наличными.', 1353064129);


#
# TABLE STRUCTURE FOR: support_departments
#

DROP TABLE IF EXISTS support_departments;

CREATE TABLE `support_departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO support_departments (`id`, `name`) VALUES (1, 'Техническая поддержка');
INSERT INTO support_departments (`id`, `name`) VALUES (2, 'Финансовый отдел');
INSERT INTO support_departments (`id`, `name`) VALUES (3, 'Отдел консультаций');


#
# TABLE STRUCTURE FOR: support_tickets
#

DROP TABLE IF EXISTS support_tickets;

CREATE TABLE `support_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `last_comment_author` varchar(50) NOT NULL,
  `text` text,
  `theme` varchar(100) NOT NULL,
  `department` int(11) NOT NULL,
  `status` smallint(1) DEFAULT NULL,
  `priority` varchar(15) DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `updated` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO support_tickets (`id`, `user_id`, `last_comment_author`, `text`, `theme`, `department`, `status`, `priority`, `date`, `updated`) VALUES (1, 1, '', 'Не могу настроить на сайте переадресации. На локалке все работает. Помогите пожалуйста.', 'htaccess', 1, 0, '2', 1353061322, 1353061322);
INSERT INTO support_tickets (`id`, `user_id`, `last_comment_author`, `text`, `theme`, `department`, `status`, `priority`, `date`, `updated`) VALUES (2, 1, '', 'Какой тарифный план лучше подходит для моего сайта?', 'хостинг', 3, 0, '1', 1353061376, 1353061376);
INSERT INTO support_tickets (`id`, `user_id`, `last_comment_author`, `text`, `theme`, `department`, `status`, `priority`, `date`, `updated`) VALUES (3, 1, 'admin', 'Как я могу полатить хостинг?', 'Оплата услуг', 2, 0, '0', 1353061402, 1353064130);


#
# TABLE STRUCTURE FOR: tags
#

DROP TABLE IF EXISTS tags;

CREATE TABLE `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `value` (`value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: trash
#

DROP TABLE IF EXISTS trash;

CREATE TABLE `trash` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trash_id` varchar(255) DEFAULT NULL,
  `trash_url` varchar(255) DEFAULT NULL,
  `trash_redirect_type` varchar(20) DEFAULT NULL,
  `trash_redirect` varchar(255) DEFAULT NULL,
  `trash_type` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

INSERT INTO trash (`id`, `trash_id`, `trash_url`, `trash_redirect_type`, `trash_redirect`, `trash_type`) VALUES (1, '79', 'shop/product/rro-mimi-t400me', 'category', 'http://inpromservice.com.ua/shop/category/kasove-obladnannia', '301');
INSERT INTO trash (`id`, `trash_id`, `trash_url`, `trash_redirect_type`, `trash_redirect`, `trash_type`) VALUES (3, '79', 'shop/product/rro-datecs-mp-50-junior', 'category', 'http://inpromservice.com.ua/shop/category/kasove-obladnannia', '301');
INSERT INTO trash (`id`, `trash_id`, `trash_url`, `trash_redirect_type`, `trash_redirect`, `trash_type`) VALUES (4, '79', 'shop/product/rro-eksellio-dmp-55l', 'category', 'http://inpromservice.com.ua/shop/category/kasove-obladnannia', '301');
INSERT INTO trash (`id`, `trash_id`, `trash_url`, `trash_redirect_type`, `trash_redirect`, `trash_type`) VALUES (5, '79', 'shop/product/rro-eksellio-dmp-55b', 'category', 'http://inpromservice.com.ua/shop/category/kasove-obladnannia', '301');
INSERT INTO trash (`id`, `trash_id`, `trash_url`, `trash_redirect_type`, `trash_redirect`, `trash_type`) VALUES (6, '79', 'shop/product/rro-datecs-mp-550t', 'category', 'http://inpromservice.com.ua/shop/category/kasove-obladnannia', '301');
INSERT INTO trash (`id`, `trash_id`, `trash_url`, `trash_redirect_type`, `trash_redirect`, `trash_type`) VALUES (7, '79', 'shop/product/rro-neon', 'category', 'http://inpromservice.com.ua/shop/category/kasove-obladnannia', '301');
INSERT INTO trash (`id`, `trash_id`, `trash_url`, `trash_redirect_type`, `trash_redirect`, `trash_type`) VALUES (11, '79', 'shop/product/rro-eksellio-dp-35', 'category', 'http://www.inpromservice.com.ua/shop/category/kasove-obladnannia', '301');
INSERT INTO trash (`id`, `trash_id`, `trash_url`, `trash_redirect_type`, `trash_redirect`, `trash_type`) VALUES (14, '79', 'shop/product/rro-eksellio-dp-45', 'category', 'http://www.inpromservice.com.ua/shop/category/kasove-obladnannia', '301');
INSERT INTO trash (`id`, `trash_id`, `trash_url`, `trash_redirect_type`, `trash_redirect`, `trash_type`) VALUES (17, '79', 'shop/product/fiskalnii-reestrator-mg-n707ts', 'category', 'http://www.inpromservice.com.ua/shop/category/kasove-obladnannia', '301');
INSERT INTO trash (`id`, `trash_id`, `trash_url`, `trash_redirect_type`, `trash_redirect`, `trash_type`) VALUES (18, '78', 'shop/product/vagi-torgovi-cas-er-junior', 'category', 'http://www.inpromservice.com.ua/shop/category/vagove-obladnannia', '301');
INSERT INTO trash (`id`, `trash_id`, `trash_url`, `trash_redirect_type`, `trash_redirect`, `trash_type`) VALUES (19, '78', 'shop/product/vagi-torgovi-digi-ds-788pm', 'category', 'http://www.inpromservice.com.ua/shop/category/vagove-obladnannia', '301');
INSERT INTO trash (`id`, `trash_id`, `trash_url`, `trash_redirect_type`, `trash_redirect`, `trash_type`) VALUES (20, '79', 'shop/product/rro-mini-50002me', 'category', 'http://inpromservice.com.ua/shop/category/kasove-obladnannia', '301');
INSERT INTO trash (`id`, `trash_id`, `trash_url`, `trash_redirect_type`, `trash_redirect`, `trash_type`) VALUES (21, '78', 'shop/product/vagi-tovarni-jbs-700m', 'category', 'http://www.inpromservice.com.ua/shop/category/vagove-obladnannia', '301');
INSERT INTO trash (`id`, `trash_id`, `trash_url`, `trash_redirect_type`, `trash_redirect`, `trash_type`) VALUES (22, '78', 'shop/product/vagi-fasovochni-digi-ds-708-bm', 'category', 'http://www.inpromservice.com.ua/shop/category/vagove-obladnannia', '301');
INSERT INTO trash (`id`, `trash_id`, `trash_url`, `trash_redirect_type`, `trash_redirect`, `trash_type`) VALUES (23, '78', 'shop/product/vagi-fasovochni-vte-tsentroves-t3b', 'category', 'http://www.inpromservice.com.ua/shop/category/vagove-obladnannia', '301');
INSERT INTO trash (`id`, `trash_id`, `trash_url`, `trash_redirect_type`, `trash_redirect`, `trash_type`) VALUES (24, '81', 'shop/product/218', 'category', 'http://www.inpromservice.com.ua/shop/category/pos-obladnannia', '301');


#
# TABLE STRUCTURE FOR: user_autologin
#

DROP TABLE IF EXISTS user_autologin;

CREATE TABLE `user_autologin` (
  `key_id` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `user_id` mediumint(8) NOT NULL DEFAULT '0',
  `user_agent` varchar(150) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `last_ip` varchar(40) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`key_id`,`user_id`),
  KEY `last_ip` (`last_ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO user_autologin (`key_id`, `user_id`, `user_agent`, `last_ip`, `last_login`) VALUES ('37d21073e0b617c057ffb6321cb2fa78', 48, 'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 YaBrowser/13.10.1500.9323 Safari/537.36', '37.229.234.69', '2014-01-27 20:37:40');
INSERT INTO user_autologin (`key_id`, `user_id`, `user_agent`, `last_ip`, `last_login`) VALUES ('77517d65ddf3df5e7b7cf7754cae98f9', 48, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.12785 YaBrowser/13.12.1599.12785 Safari/537.36', '37.115.234.179', '2014-01-28 13:35:43');
INSERT INTO user_autologin (`key_id`, `user_id`, `user_agent`, `last_ip`, `last_login`) VALUES ('23171d7c9c4017e532794e54d780a221', 48, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.13014 YaBrowser/13.12.1599.13014 Safari/537.36', '37.229.233.216', '2014-02-17 09:45:06');
INSERT INTO user_autologin (`key_id`, `user_id`, `user_agent`, `last_ip`, `last_login`) VALUES ('cd434d41b9ce03ed4f88629a588c4dd2', 48, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.122 YaBrowser/14.12.2125.10034 Safari/537.36', '46.211.225.65', '2015-03-05 10:31:52');
INSERT INTO user_autologin (`key_id`, `user_id`, `user_agent`, `last_ip`, `last_login`) VALUES ('fef82e61b82a8c364897303a830243bc', 52, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.116 Safari/537.36', '176.8.215.172', '2016-03-12 08:12:31');
INSERT INTO user_autologin (`key_id`, `user_id`, `user_agent`, `last_ip`, `last_login`) VALUES ('5d7c19bfc770bf2bc609467c99a34049', 52, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.116 Safari/537.36', '176.8.215.172', '2016-03-11 16:48:23');
INSERT INTO user_autologin (`key_id`, `user_id`, `user_agent`, `last_ip`, `last_login`) VALUES ('ca48a2f3906c808144782a8f760fb04f', 52, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 YaBrowser/15.9.2403.3043 Safari/537.36', '37.229.227.113', '2016-03-16 08:11:33');


#
# TABLE STRUCTURE FOR: user_temp
#

DROP TABLE IF EXISTS user_temp;

CREATE TABLE `user_temp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(34) NOT NULL,
  `email` varchar(100) NOT NULL,
  `activation_key` varchar(50) NOT NULL,
  `last_ip` varchar(40) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `banned` tinyint(1) DEFAULT NULL,
  `ban_reason` varchar(255) DEFAULT NULL,
  `newpass` varchar(255) DEFAULT NULL,
  `newpass_key` varchar(255) DEFAULT NULL,
  `newpass_time` int(11) DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` int(11) DEFAULT NULL,
  `created` int(11) DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `cart_data` text,
  `wish_list_data` text,
  `key` varchar(255) NOT NULL,
  `amout` float(10,2) NOT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `phone` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_I_1` (`key`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

INSERT INTO users (`id`, `role_id`, `username`, `password`, `email`, `banned`, `ban_reason`, `newpass`, `newpass_key`, `newpass_time`, `last_ip`, `last_login`, `created`, `modified`, `address`, `cart_data`, `wish_list_data`, `key`, `amout`, `discount`, `phone`) VALUES (1, 1, 'Administrator', '$1$PZ/WKcKq$DbnsgLPX0CWbIsF8YLomS0', 'office@artexgroup.com.ua', 0, NULL, NULL, NULL, NULL, '37.57.177.192', 2016, 2013, '0000-00-00 00:00:00', '', NULL, NULL, '', '0.00', NULL, '');
INSERT INTO users (`id`, `role_id`, `username`, `password`, `email`, `banned`, `ban_reason`, `newpass`, `newpass_key`, `newpass_time`, `last_ip`, `last_login`, `created`, `modified`, `address`, `cart_data`, `wish_list_data`, `key`, `amout`, `discount`, `phone`) VALUES (48, 1, 'admin', '$1$WEGlb260$/i7MoaDXeFZUDjmLT6pyv0', 'admin@mail.com', NULL, NULL, '$1$sXbNuXUe$fzcmhRcTMpPsGGY5nlWO61', 'bebe70ba3d06f7e6df15e19b3c644340', 2016, '37.229.235.161', 2015, 1386334280, NULL, '', NULL, NULL, 'rY6QG', '0.00', NULL, '');
INSERT INTO users (`id`, `role_id`, `username`, `password`, `email`, `banned`, `ban_reason`, `newpass`, `newpass_key`, `newpass_time`, `last_ip`, `last_login`, `created`, `modified`, `address`, `cart_data`, `wish_list_data`, `key`, `amout`, `discount`, `phone`) VALUES (49, 1, 'Igor', '$1$1tzyLm3q$Zp/KvdCot28aLrBwrEXHp/', 'inprom2000@yandex.ru', NULL, NULL, NULL, NULL, NULL, '176.8.215.172', 2016, 1427530395, NULL, '', NULL, NULL, 'M1DKH', '0.00', NULL, '');
INSERT INTO users (`id`, `role_id`, `username`, `password`, `email`, `banned`, `ban_reason`, `newpass`, `newpass_key`, `newpass_time`, `last_ip`, `last_login`, `created`, `modified`, `address`, `cart_data`, `wish_list_data`, `key`, `amout`, `discount`, `phone`) VALUES (51, 1, 'Админ', '$1$A7SkHlRq$g1bu77wiVZ7fa0smq8kzI/', 'office@inpromservice.com.ua', NULL, NULL, NULL, NULL, NULL, '37.229.227.141', NULL, 1456491564, NULL, '', NULL, NULL, 'mwo6r', '0.00', NULL, '');
INSERT INTO users (`id`, `role_id`, `username`, `password`, `email`, `banned`, `ban_reason`, `newpass`, `newpass_key`, `newpass_time`, `last_ip`, `last_login`, `created`, `modified`, `address`, `cart_data`, `wish_list_data`, `key`, `amout`, `discount`, `phone`) VALUES (52, 1, 'inpromservice', '$1$qE3ATxC4$VHJPYAtO2wQnSKBwrcMIu.', 'inprom2000@mail.ru', NULL, NULL, NULL, NULL, NULL, '134.249.219.219', 2016, 1457707702, NULL, '', 'a:0:{}', NULL, 'xbTb4', '0.00', NULL, '');


#
# TABLE STRUCTURE FOR: widget_i18n
#

DROP TABLE IF EXISTS widget_i18n;

CREATE TABLE `widget_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(11) NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`id`,`locale`),
  KEY `locale` (`locale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO widget_i18n (`id`, `locale`, `data`) VALUES (16, 'ru', '<div class=\"container\">\n<ul class=\"items items-benefits\">\n<li>\n<div class=\"frame-icon-benefit\"><span class=\"helper\">&nbsp;</span> <span class=\"icon-benefits_1\">&nbsp;</span></div>\n<div class=\"frame-description-benefit f-s_0\"><span class=\"helper\">&nbsp;</span>\n<div>\n<div class=\"title\">Бесплатная</div>\n<p>доставка</p>\n</div>\n</div>\n</li>\n<li>\n<div class=\"frame-icon-benefit\"><span class=\"helper\">&nbsp;</span> <span class=\"icon-benefits_2\">&nbsp;</span></div>\n<div class=\"frame-description-benefit f-s_0\"><span class=\"helper\">&nbsp;</span>\n<div>\n<div class=\"title\">Гибкая система</div>\n<p>скидок</p>\n</div>\n</div>\n</li>\n<li>\n<div class=\"frame-icon-benefit\"><span class=\"helper\">&nbsp;</span> <span class=\"icon-benefits_3\">&nbsp;</span></div>\n<div class=\"frame-description-benefit f-s_0\"><span class=\"helper\">&nbsp;</span>\n<div>\n<div class=\"title\">Индивидуальный</div>\n<p>подход</p>\n</div>\n</div>\n</li>\n<li>\n<div class=\"frame-icon-benefit\"><span class=\"helper\">&nbsp;</span> <span class=\"icon-benefits_4\">&nbsp;</span></div>\n<div class=\"frame-description-benefit f-s_0\"><span class=\"helper\">&nbsp;</span>\n<div>\n<div class=\"title\">высокий уровень</div>\n<p>сервиса</p>\n</div>\n</div>\n</li>\n</ul>\n</div>');
INSERT INTO widget_i18n (`id`, `locale`, `data`) VALUES (17, 'ru', '<div class=\"frame-delivery-payment\"><dl><dt class=\"title f-s_0\"><span class=\"icon_delivery\">&nbsp;</span><span class=\"text-el\">Доставка</span></dt><dd class=\"frame-list-delivery\">\n<ul class=\"list-style-1\">\n<li>Нова Пошта</li>\n<li>Інші транспортні компанії</li>\n</ul>\n</dd><dt class=\"title f-s_0\"><span class=\"icon_payment\">&nbsp;</span><span class=\"text-el\">Оплата</span></dt><dd class=\"frame-list-payment\">\n<ul class=\"list-style-1\">\n<li>Готівка при отриманні</li>\n<li>Безготівковий переказ</li>\n<li>Приват 24</li>\n</ul>\n</dd></dl></div>\n<div class=\"frame-phone-product\">\n<div class=\"title f-s_0\"><span class=\"icon_phone_product\">&nbsp;</span><span class=\"icon_phone_product\">Закази за телефонами</span></div>\n<ul class=\"list-style-1\">\n<li>(0532) <span class=\"d_n\">&minus;</span>544420, 544427, 544429</li>\n<li>(095) <span class=\"d_n\">&minus; 8163587</span></li>\n</ul>\n</div>');
INSERT INTO widget_i18n (`id`, `locale`, `data`) VALUES (20, 'ru', '<p>ТОВ &nbsp;\"інпром-Сервіс\" (Полтава).</p>\n<p>Торгівельне обладнання / Фіскальне устаткування / POS-устаткування / Сканери штрих-кодів / Принтери штрих-кодів / Термінали збору даних / Ваговимірювальне устаткування / Пристрої для перевірки цін / Банківське устаткування / Wi-Fi устаткування / Системи відеоспостереження / Маркувальне устаткування / Пакувальне устаткування / Витратні матеріали / Комплексне оснащення об\'єктів високотехнологічним устаткуванням і рішеннями для автоматизації різних галузей бізнесу / Повний комплекс сервісного обслуговування</p>');


#
# TABLE STRUCTURE FOR: widgets
#

DROP TABLE IF EXISTS widgets;

CREATE TABLE `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `type` varchar(15) NOT NULL,
  `data` text NOT NULL,
  `method` varchar(50) NOT NULL,
  `settings` text NOT NULL,
  `description` varchar(300) NOT NULL,
  `roles` text NOT NULL,
  `created` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (3, 'latest_news', 'module', 'core', 'recent_news', 'a:4:{s:10:\"news_count\";s:1:\"2\";s:11:\"max_symdols\";s:3:\"150\";s:10:\"categories\";a:1:{i:0;s:2:\"56\";}s:7:\"display\";s:6:\"recent\";}', 'Последние новости', '', 1291632457);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (4, 'recent_product_comments', 'module', 'comments', 'recent_product_comments', 'a:2:{s:14:\"comments_count\";s:1:\"5\";s:13:\"symbols_count\";s:1:\"0\";}', 'Последние комментарии продукта', '', 1308300371);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (5, 'tags', 'module', 'tags', 'tags_cloud', '', 'Теги', '', 1312362714);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (6, 'path', 'module', 'navigation', 'widget_navigation', '', 'Виджет навигации', '', 1328631622);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (10, 'popular_products', 'module', 'shop', 'products', 'a:4:{s:12:\"productsType\";s:11:\"popular,hit\";s:5:\"title\";s:33:\"Популярные товары\";s:13:\"productsCount\";s:2:\"10\";s:7:\"subpath\";s:7:\"widgets\";}', 'Популярные товары', '', 1363606273);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (11, 'new_products', 'module', 'shop', 'products', 'a:4:{s:12:\"productsType\";s:11:\"popular,hot\";s:5:\"title\";s:14:\"Новинки\";s:13:\"productsCount\";s:2:\"10\";s:7:\"subpath\";s:7:\"widgets\";}', 'Новые товары', '', 1363606324);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (12, 'action_products', 'module', 'shop', 'products', 'a:4:{s:12:\"productsType\";s:14:\"popular,action\";s:5:\"title\";s:31:\"Акционные товары\";s:13:\"productsCount\";s:2:\"10\";s:7:\"subpath\";s:7:\"widgets\";}', 'Акционные товары', '', 1363606361);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (13, 'brands', 'module', 'shop', 'brands', 'a:4:{s:10:\"withImages\";b:1;s:11:\"brandsCount\";s:2:\"15\";s:7:\"subpath\";s:7:\"widgets\";s:5:\"title\";s:39:\"Лучшие производители\";}', 'Бренды', '', 1363606422);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (14, 'view_product', 'module', 'shop', 'view_product', 'a:4:{s:12:\"productsType\";b:0;s:5:\"title\";s:54:\"Недавно просмотренные товары\";s:13:\"productsCount\";s:2:\"10\";s:7:\"subpath\";s:7:\"widgets\";}', 'Недавно просмотренные товары', '', 1363606497);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (15, 'similar', 'module', 'shop', 'similar_products', 'a:3:{s:5:\"title\";s:27:\"Похожие товары\";s:13:\"productsCount\";s:1:\"5\";s:7:\"subpath\";s:7:\"widgets\";}', 'Похожие товары', '', 1363606582);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (28, 'popular_products_category', 'module', 'shop', 'products', 'a:4:{s:12:\"productsType\";s:17:\"date,hit,category\";s:5:\"title\";s:16:\"Popular products\";s:13:\"productsCount\";s:2:\"10\";s:7:\"subpath\";s:7:\"widgets\";}', 'Популярная категория товара', '', 1374575193);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (27, 'ViewedProducts', 'module', 'shop', 'view_product', 'a:4:{s:12:\"productsType\";b:0;s:5:\"title\";s:14:\"ViewedProducts\";s:13:\"productsCount\";s:2:\"10\";s:7:\"subpath\";s:7:\"widgets\";}', 'Просмотренные товары', '', 1374575092);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (17, 'payments_delivery_methods_info', 'html', '<div class=\"frame-delivery-payment\"><dl><dt class=\"title f-s_0\"><span class=\"icon_delivery\">&nbsp;</span><span class=\"text-el\">Доставка</span></dt><dd class=\"frame-list-delivery\">\n<ul class=\"list-style-1\">\n<li>Новая Почта</li>\n<li>Другие транспортные службы</li>\n<li>Курьером по Киеву</li>\n<li>Самовывоз</li>\n</ul>\n</dd><dt class=\"title f-s_0\"><span class=\"icon_payment\">&nbsp;</span><span class=\"text-el\">Оплата</span></dt><dd class=\"frame-list-payment\">\n<ul class=\"list-style-1\">\n<li>Наличными при получении</li>\n<li>Безналичный перевод</li>\n<li>Приват 24</li>\n<li>WebMoney</li>\n</ul>\n</dd></dl></div>\n<div class=\"frame-phone-product\">\n<div class=\"title f-s_0\"><span class=\"icon_phone_product\">&nbsp;</span><span class=\"text-el\">Заказы по телефонах</span></div>\n<ul class=\"list-style-1\">\n<li>(097) <span class=\"d_n\">&minus;</span>567-43-21</li>\n<li>(097) <span class=\"d_n\">&minus;</span>567-43-22</li>\n</ul>\n</div>', '', '', 'Информация о способах доставки', '', 1371821417);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (20, 'start_page_seo_text', 'html', '', '', '', '', '', 1378821714);


